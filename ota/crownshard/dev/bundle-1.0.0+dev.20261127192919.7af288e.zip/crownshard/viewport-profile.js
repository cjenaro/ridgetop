/**
 * Crownshard unified ViewportProfile, live iOS safe-area inset reader,
 * input-modality detection & live tracker (touch vs keyboard/mouse), and
 * modality-aware UI copy helper.
 *
 * Pure and dependency-free so it runs identically in browser and Node tests.
 */
const DEFAULT_MIN_MARGIN = 8;
const EMULATED_MOUSE_GUARD_MS = 800;
const MODIFIER_ONLY_KEYS = new Set([
    '',
    'Shift',
    'Control',
    'Alt',
    'Meta',
    'CapsLock',
    'NumLock',
    'ScrollLock',
    'AltGraph',
    'OS',
    'Fn',
    'FnLock',
    'Process',
    'Unidentified'
]);
function clampSafeInset(raw, minMargin) {
    const value = typeof raw === 'number' && Number.isFinite(raw) && raw > 0 ? raw : 0;
    return Math.max(minMargin, value);
}
/**
 * Pure computation of Crownshard's unified viewport profile.
 *
 * Breakpoints are calibrated for:
 * - Portrait phones: iPhone SE (375x667), iPhone 14/15/16 (390x844, 393x852), Pro Max (430x932)
 * - Landscape phones: 667x375, 844x390, 852x393, 932x430 (height < 500 && width < 960)
 * - Tablets: iPad portrait/landscape (768x1024, 1024x768) and small windows (width < 1100 || height < 720)
 * - Desktop: >= 1100x720
 */
export function computeViewportProfile(width, height, opts = {}) {
    const safeW = Number.isFinite(width) && width > 0 ? width : 1280;
    const safeH = Number.isFinite(height) && height > 0 ? height : 720;
    const orientation = safeH > safeW ? 'portrait' : 'landscape';
    const isPortraitPhone = (safeW < 660 && safeH >= safeW) || safeW < 600;
    const isLandscapePhone = !isPortraitPhone && safeH < 500 && safeW < 960;
    const isTablet = !isPortraitPhone && !isLandscapePhone && (safeW < 1100 || safeH < 720);
    const deviceClass = isPortraitPhone
        ? 'portraitPhone'
        : isLandscapePhone
            ? 'landscapePhone'
            : isTablet
                ? 'tablet'
                : 'desktop';
    const isPhone = isPortraitPhone || isLandscapePhone;
    const isCompact = isPhone || safeW < 900 || safeH < 600;
    const modality = opts.modality ?? 'keyboard_mouse';
    const isTouchPrimary = modality === 'touch';
    const showKeycaps = !isTouchPrimary;
    const minTouchTarget = isTouchPrimary || isPhone ? 44 : 28;
    const minMargin = typeof opts.minMargin === 'number' && Number.isFinite(opts.minMargin) && opts.minMargin >= 0
        ? opts.minMargin
        : DEFAULT_MIN_MARGIN;
    const safeArea = {
        top: clampSafeInset(opts.safeArea?.top, minMargin),
        right: clampSafeInset(opts.safeArea?.right, minMargin),
        bottom: clampSafeInset(opts.safeArea?.bottom, minMargin),
        left: clampSafeInset(opts.safeArea?.left, minMargin)
    };
    return {
        width: safeW,
        height: safeH,
        orientation,
        deviceClass,
        isPhone,
        isPortraitPhone,
        isLandscapePhone,
        isTablet,
        isCompact,
        isTouchPrimary,
        showKeycaps,
        minTouchTarget,
        safeArea
    };
}
function parseCssPx(raw) {
    if (!raw)
        return 0;
    const parsed = Number.parseFloat(raw);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
}
/**
 * Reads live iOS/browser safe-area insets from `:root` custom properties
 * (`--sat`, `--sar`, `--sab`, `--sal`) defined in `game-ui.css`.
 * Safe in SSR/Node where `document` or `getComputedStyle` are absent.
 */
export function readDomSafeAreaInsets() {
    if (typeof document === 'undefined' || typeof getComputedStyle !== 'function' || !document.documentElement) {
        return { top: 0, right: 0, bottom: 0, left: 0 };
    }
    try {
        const style = getComputedStyle(document.documentElement);
        return {
            top: parseCssPx(style.getPropertyValue('--sat')),
            right: parseCssPx(style.getPropertyValue('--sar')),
            bottom: parseCssPx(style.getPropertyValue('--sab')),
            left: parseCssPx(style.getPropertyValue('--sal'))
        };
    }
    catch {
        return { top: 0, right: 0, bottom: 0, left: 0 };
    }
}
/**
 * Detects initial input modality from browser pointer/hover media queries and touch capabilities.
 * Safely defaults to `'keyboard_mouse'` in Node/SSR environments.
 */
export function detectInitialInputModality() {
    if (typeof window === 'undefined')
        return 'keyboard_mouse';
    try {
        const coarse = Boolean(window.matchMedia?.('(pointer: coarse)')?.matches);
        const noHover = Boolean(window.matchMedia?.('(hover: none)')?.matches);
        const touchCapableCompact = typeof navigator !== 'undefined' &&
            typeof navigator.maxTouchPoints === 'number' &&
            navigator.maxTouchPoints > 0 &&
            window.innerWidth < 1100;
        return coarse || noHover || touchCapableCompact ? 'touch' : 'keyboard_mouse';
    }
    catch {
        return 'keyboard_mouse';
    }
}
/**
 * Tracks live input modality transitions between `'touch'` and `'keyboard_mouse'`.
 *
 * - Switches to `'touch'` on `pointerType === 'touch'`.
 * - Switches to `'keyboard_mouse'` on non-modifier physical `keydown` or `pointerType === 'mouse'`.
 * - Guards against synthetic/emulated mouse events fired shortly after touch input.
 */
export function createInputModalityTracker(initial) {
    let current = initial ?? detectInitialInputModality();
    let lastTouchAtMs = current === 'touch' ? 0 : -Infinity;
    const listeners = new Set();
    function setModality(next) {
        if (next === current)
            return false;
        current = next;
        for (const listener of listeners) {
            listener(current);
        }
        return true;
    }
    function onPointerEvent(e, nowMs = Date.now()) {
        const pt = e?.pointerType;
        if (pt === 'touch') {
            lastTouchAtMs = nowMs;
            return setModality('touch');
        }
        if (pt === 'mouse') {
            if (nowMs - lastTouchAtMs < EMULATED_MOUSE_GUARD_MS) {
                return false;
            }
            return setModality('keyboard_mouse');
        }
        return false;
    }
    function onKeyDown(e, _nowMs = Date.now()) {
        const key = typeof e?.key === 'string' ? e.key : '';
        if (MODIFIER_ONLY_KEYS.has(key))
            return false;
        return setModality('keyboard_mouse');
    }
    function subscribe(listener) {
        listeners.add(listener);
        return () => {
            listeners.delete(listener);
        };
    }
    function attach(target) {
        const host = target ?? (typeof window !== 'undefined' ? window : undefined);
        if (!host || typeof host.addEventListener !== 'function') {
            return () => { };
        }
        const handlePointer = (ev) => {
            onPointerEvent(ev);
        };
        const handleKeyDown = (ev) => {
            onKeyDown(ev);
        };
        host.addEventListener('pointerdown', handlePointer, { passive: true, capture: true });
        host.addEventListener('keydown', handleKeyDown, { passive: true, capture: true });
        return () => {
            host.removeEventListener('pointerdown', handlePointer, true);
            host.removeEventListener('keydown', handleKeyDown, true);
        };
    }
    return {
        get modality() {
            return current;
        },
        getModality() {
            return current;
        },
        onPointerEvent,
        onKeyDown,
        setModality,
        subscribe,
        attach
    };
}
/** Picks modality-appropriate UI copy (touch vs desktop). */
export function uiCopy(isTouch, desktopText, touchText) {
    return isTouch ? touchText : desktopText;
}
