import { EQUIPMENT_BY_ID, EQUIPMENT_LIST } from "./data.js";
export const GEAR_SET_ORDER = [
    'solis',
    'frostguard',
    'windrunner',
    'shadowfang',
    'astral'
];
export const GEAR_SET_SPECS = {
    solis: {
        id: 'solis',
        name: 'Solis Vanguard',
        shortName: 'Solis',
        tag: 'SOLIS',
        perkName: 'Solar Resonance',
        shortPerk: '+4 ATK, +14 HP, +8 SHD · +10% Skill DMG',
        desc: '2pc: +4 ATK, +14 HP, +8 Start Shield & +10% Skill DMG.',
        piecesRequired: 2,
        accentHex: '#ffd257',
        bgHex: '#382a12',
        statBonus: {
            atk: 4,
            def: 0,
            hp: 14,
            speed: 0,
            move: 0,
            crit: 0,
            lifesteal: 0,
            shieldStart: 8
        },
        combatRule: {
            skillDamageMul: 1.10
        }
    },
    frostguard: {
        id: 'frostguard',
        name: 'Frostguard Bastion',
        shortName: 'Frostguard',
        tag: 'FROST',
        perkName: 'Permafrost Bulwark',
        shortPerk: '+3 DEF, +16 HP, +10 SHD · +15% vs Slow/Stun',
        desc: '2pc: +3 DEF, +16 HP, +10 Start Shield & +15% DMG vs Slowed or Stunned foes.',
        piecesRequired: 2,
        accentHex: '#72dcff',
        bgHex: '#122c44',
        statBonus: {
            atk: 0,
            def: 3,
            hp: 16,
            speed: 0,
            move: 0,
            crit: 0,
            lifesteal: 0,
            shieldStart: 10
        },
        combatRule: {
            vsSlowOrStunDamageMul: 1.15
        }
    },
    windrunner: {
        id: 'windrunner',
        name: 'Windrunner Stride',
        shortName: 'Windrunner',
        tag: 'WIND',
        perkName: 'Gale Momentum',
        shortPerk: '+2 SPD, +12% Crit · +10% Flank/Back DMG',
        desc: '2pc: +2 SPD, +12% Crit & +10% Flank or Backstab DMG.',
        piecesRequired: 2,
        accentHex: '#5ef0aa',
        bgHex: '#123428',
        statBonus: {
            atk: 0,
            def: 0,
            hp: 0,
            speed: 2,
            move: 0,
            crit: 0.12,
            lifesteal: 0,
            shieldStart: 0
        },
        combatRule: {
            flankOrBackDamageMul: 1.10
        }
    },
    shadowfang: {
        id: 'shadowfang',
        name: 'Shadowfang Syndicate',
        shortName: 'Shadowfang',
        tag: 'SHDW',
        perkName: 'Venom Fang',
        shortPerk: '+3 ATK, +10% Crit/Leech · +12% vs Psn/Burn',
        desc: '2pc: +3 ATK, +10% Crit, +10% Lifesteal & +12% DMG vs Poisoned or Burning foes.',
        piecesRequired: 2,
        accentHex: '#d27dff',
        bgHex: '#2c1642',
        statBonus: {
            atk: 3,
            def: 0,
            hp: 0,
            speed: 0,
            move: 0,
            crit: 0.10,
            lifesteal: 0.10,
            shieldStart: 0
        },
        combatRule: {
            vsPoisonOrBurnDamageMul: 1.12
        }
    },
    astral: {
        id: 'astral',
        name: 'Astral Conclave',
        shortName: 'Astral',
        tag: 'ASTRAL',
        perkName: 'Starlight Conduit',
        shortPerk: '+4 ATK, +2 SPD · +15% Skill DMG',
        desc: '2pc: +4 ATK, +2 SPD & +15% Skill DMG.',
        piecesRequired: 2,
        accentHex: '#84c2ff',
        bgHex: '#16264a',
        statBonus: {
            atk: 4,
            def: 0,
            hp: 0,
            speed: 2,
            move: 0,
            crit: 0,
            lifesteal: 0,
            shieldStart: 0
        },
        combatRule: {
            skillDamageMul: 1.15
        }
    }
};
/** Return the full metadata & bonuses for a given GearSetId. */
export function getGearSetSpec(setId) {
    return GEAR_SET_SPECS[setId];
}
/** Return the GearSetId for an equipment item, or `null` if it does not belong to a set. */
export function getEquipSetId(equipId) {
    if (!equipId)
        return null;
    return EQUIPMENT_BY_ID[equipId]?.setId ?? null;
}
/** Return the GearSetSpec for an equipment item, or `null` if untagged. */
export function getEquipSetSpec(equipId) {
    const setId = getEquipSetId(equipId);
    return setId ? GEAR_SET_SPECS[setId] : null;
}
/** List all equipment specs belonging to a given set. */
export function getItemsInGearSet(setId) {
    return EQUIPMENT_LIST.filter(item => item.setId === setId);
}
function resolveHeroEquipIds(campaign, hero) {
    let weaponId;
    let armorId;
    let relicId;
    if (hero.weaponUid || hero.armorUid || hero.relicUid) {
        for (const eq of campaign.equipment) {
            if (hero.weaponUid && eq.uid === hero.weaponUid)
                weaponId = eq.equipId;
            if (hero.armorUid && eq.uid === hero.armorUid)
                armorId = eq.equipId;
            if (hero.relicUid && eq.uid === hero.relicUid)
                relicId = eq.equipId;
        }
    }
    return [weaponId, armorId, relicId];
}
/** Compute sorted gear set progress (`2/2` active sets first, then `1/2` partial sets) for a 3-slot loadout. */
export function getLoadoutGearSetProgress(weaponId, armorId, relicId) {
    const itemsBySet = new Map();
    for (const eqId of [weaponId, armorId, relicId]) {
        if (!eqId)
            continue;
        const setId = getEquipSetId(eqId);
        if (!setId)
            continue;
        const list = itemsBySet.get(setId);
        if (list)
            list.push(eqId);
        else
            itemsBySet.set(setId, [eqId]);
    }
    const out = [];
    for (const setId of GEAR_SET_ORDER) {
        const itemIds = itemsBySet.get(setId);
        if (!itemIds || itemIds.length === 0)
            continue;
        const spec = GEAR_SET_SPECS[setId];
        out.push({
            setId,
            spec,
            equippedCount: itemIds.length,
            requiredCount: spec.piecesRequired,
            active: itemIds.length >= spec.piecesRequired,
            itemIds
        });
    }
    out.sort((a, b) => {
        if (a.active !== b.active)
            return a.active ? -1 : 1;
        return b.equippedCount - a.equippedCount;
    });
    return out;
}
/** Return gear set progress (both `2/2` active and `1/2` partial) for a BattleUnit. */
export function getUnitGearSetProgress(unit) {
    if (!unit)
        return [];
    return getLoadoutGearSetProgress(unit.weaponId, unit.armorId, unit.relicId);
}
/** Return active 2-piece gear sets for a BattleUnit. */
export function getUnitActiveGearSets(unit) {
    if (!unit)
        return [];
    const progress = getLoadoutGearSetProgress(unit.weaponId, unit.armorId, unit.relicId);
    const active = [];
    for (const entry of progress) {
        if (entry.active) {
            active.push({
                setId: entry.setId,
                spec: entry.spec,
                equippedCount: entry.equippedCount,
                itemIds: entry.itemIds
            });
        }
    }
    return active;
}
/** Return gear set progress (both `2/2` active and `1/2` partial) for a campaign hero. */
export function getHeroGearSetProgress(campaign, hero) {
    const [weaponId, armorId, relicId] = resolveHeroEquipIds(campaign, hero);
    return getLoadoutGearSetProgress(weaponId, armorId, relicId);
}
export function getHeroActiveGearSets(campaignOrUnit, hero) {
    if (!campaignOrUnit)
        return [];
    if (hero && 'equipment' in campaignOrUnit) {
        const [weaponId, armorId, relicId] = resolveHeroEquipIds(campaignOrUnit, hero);
        return getUnitActiveGearSets({ weaponId, armorId, relicId });
    }
    if ('equipment' in campaignOrUnit)
        return [];
    return getUnitActiveGearSets(campaignOrUnit);
}
/** Convenience list of active GearSetIds for a campaign hero (useful for UI state & telemetry). */
export function getHeroActiveGearSetIds(campaign, hero) {
    return getHeroActiveGearSets(campaign, hero).map(entry => entry.setId);
}
/** Aggregate flat stat bonuses granted by all active 2-piece gear sets in a 3-slot loadout. */
export function computeGearSetStatBonuses(weaponId, armorId, relicId) {
    const active = getUnitActiveGearSets({ weaponId, armorId, relicId });
    if (active.length === 0) {
        return { atk: 0, def: 0, hp: 0, speed: 0, move: 0, crit: 0, lifesteal: 0, shieldStart: 0 };
    }
    let atk = 0;
    let def = 0;
    let hp = 0;
    let speed = 0;
    let move = 0;
    let crit = 0;
    let lifesteal = 0;
    let shieldStart = 0;
    for (const entry of active) {
        const b = entry.spec.statBonus;
        atk += b.atk;
        def += b.def;
        hp += b.hp;
        speed += b.speed;
        move += b.move;
        crit += b.crit;
        lifesteal += b.lifesteal;
        shieldStart += b.shieldStart;
    }
    return { atk, def, hp, speed, move, crit, lifesteal, shieldStart };
}
/**
 * Compute live combat damage multipliers & bonus armor pierce granted by active 2-piece gear sets.
 * Wired into both `previewDamageMath` (`CombatForecast`) and `applyDamageDetailed` for exact parity.
 */
export function computeGearSetCombatBonuses(unit, target, isSkill, attackArc = 'front') {
    if (!unit) {
        return { damageMul: 1.0, bonusIgnoreArmor: 0, triggeredSets: [] };
    }
    const active = getUnitActiveGearSets(unit);
    if (active.length === 0) {
        return { damageMul: 1.0, bonusIgnoreArmor: 0, triggeredSets: [] };
    }
    let damageMul = 1.0;
    let bonusIgnoreArmor = 0;
    const triggeredSets = [];
    const targetSlowOrStun = Boolean(target && ((target.slowTurns ?? 0) > 0 || (target.stunTurns ?? 0) > 0));
    const targetPoisonOrBurn = Boolean(target && ((target.poisonStacks ?? 0) > 0 || (target.burnTurns ?? 0) > 0));
    const isFlankOrBack = attackArc === 'flank' || attackArc === 'back';
    for (const entry of active) {
        const rule = entry.spec.combatRule;
        let triggered = false;
        if (isSkill && rule.skillDamageMul && rule.skillDamageMul !== 1) {
            damageMul *= rule.skillDamageMul;
            triggered = true;
        }
        if (isSkill && rule.skillIgnoreArmorBonus && rule.skillIgnoreArmorBonus > 0) {
            bonusIgnoreArmor += rule.skillIgnoreArmorBonus;
            triggered = true;
        }
        if (targetSlowOrStun && rule.vsSlowOrStunDamageMul && rule.vsSlowOrStunDamageMul !== 1) {
            damageMul *= rule.vsSlowOrStunDamageMul;
            triggered = true;
        }
        if (isFlankOrBack && rule.flankOrBackDamageMul && rule.flankOrBackDamageMul !== 1) {
            damageMul *= rule.flankOrBackDamageMul;
            triggered = true;
        }
        if (targetPoisonOrBurn && rule.vsPoisonOrBurnDamageMul && rule.vsPoisonOrBurnDamageMul !== 1) {
            damageMul *= rule.vsPoisonOrBurnDamageMul;
            triggered = true;
        }
        if (triggered) {
            triggeredSets.push(entry.setId);
        }
    }
    return { damageMul, bonusIgnoreArmor, triggeredSets };
}
