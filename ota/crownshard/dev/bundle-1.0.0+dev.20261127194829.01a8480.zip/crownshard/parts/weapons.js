import { bakeVertexAO, bakeZoneColors, bevelBox, extrudeMesh, mixColor, octahedron, quaternionFromEuler, rotateVec3, sculptLoft, shadeColor, tubeMesh } from '../../framework/index.js';
// ---------------------------------------------------------------------------
// Palette & Mesh Transform Helpers
// ---------------------------------------------------------------------------
const WHITE = [1, 1, 1, 1];
const ZERO_ROT = [0, 0, 0];
const C_SUN_GOLD = [0.96, 0.78, 0.26, 1];
const C_SUN_GLOW = [1.0, 0.89, 0.36, 1];
const C_CRIMSON = [0.72, 0.14, 0.19, 1];
const C_CRIMSON_DARK = [0.46, 0.09, 0.14, 1];
const C_ARCANE_CYAN = [0.26, 0.90, 1.0, 1];
const C_FROST_ICE = [0.64, 0.88, 1.0, 1];
const C_FROST_GLOW = [0.84, 0.98, 1.0, 1];
const C_FROST_SHAFT = [0.34, 0.44, 0.56, 1];
const C_BONE = [0.88, 0.83, 0.72, 1];
const C_BONE_SHADE = [0.66, 0.60, 0.50, 1];
const C_OBSIDIAN = [0.20, 0.19, 0.27, 1];
const C_OBSIDIAN_EDGE = [0.44, 0.46, 0.56, 1];
const C_VIOLET_GLOW = [0.78, 0.34, 1.0, 1];
const C_PALADIN_COBALT = [0.18, 0.38, 0.78, 1];
const C_PALADIN_IVORY = [0.95, 0.92, 0.84, 1];
const C_PARCHMENT = [0.93, 0.88, 0.74, 1];
const C_HORN_IVORY = [0.91, 0.86, 0.73, 1];
const C_GOBLIN_IRON = [0.35, 0.37, 0.40, 1];
const C_GOBLIN_RUST = [0.44, 0.31, 0.24, 1];
const C_TOME_COVER = [0.44, 0.16, 0.22, 1];
const C_DARK_STEEL = [0.32, 0.35, 0.44, 1];
const C_BRIGHT_STEEL = [0.80, 0.85, 0.91, 1];
const C_DARK_WOOD = [0.36, 0.22, 0.15, 1];
const C_BOW_WOOD = [0.64, 0.40, 0.21, 1];
const C_YEW_GOLD = [0.78, 0.54, 0.24, 1];
const C_FOREST_GREEN = [0.22, 0.58, 0.36, 1];
const C_EMBER_CORE = [1.0, 0.52, 0.14, 1];
const C_EMBER_TIP = [1.0, 0.88, 0.38, 1];
const C_BRONZE = [0.76, 0.48, 0.26, 1];
const C_IRON_STEEL = [0.68, 0.75, 0.82, 1];
const C_IRON_GUARD = [0.36, 0.42, 0.50, 1];
const C_DRAGON_AMETHYST = [0.84, 0.42, 1.0, 1];
const C_DRAGON_DARK = [0.24, 0.18, 0.32, 1];
/**
 * Bake a local scale, rotation, and translation directly into a mesh so multi-part
 * weapons can share a single clean grip-pivot rotation without Euler gimbal drift.
 */
function transformMesh(source, offset = [0, 0, 0], rotation = ZERO_ROT, scale = [1, 1, 1]) {
    const n = source.vertexCount;
    const src = source.data;
    const out = new Float32Array(src.length);
    const q = quaternionFromEuler(rotation[0], rotation[1], rotation[2]);
    const sx = scale[0];
    const sy = scale[1];
    const sz = scale[2];
    const ox = offset[0];
    const oy = offset[1];
    const oz = offset[2];
    const invSx = Math.abs(sx) > 1e-6 ? 1 / sx : 1;
    const invSy = Math.abs(sy) > 1e-6 ? 1 / sy : 1;
    const invSz = Math.abs(sz) > 1e-6 ? 1 / sz : 1;
    let maxRadiusSq = 0;
    for (let i = 0; i < n; i++) {
        const o = i * 6;
        const p = rotateVec3(q, [src[o] * sx, src[o + 1] * sy, src[o + 2] * sz]);
        const px = p[0] + ox;
        const py = p[1] + oy;
        const pz = p[2] + oz;
        out[o] = px;
        out[o + 1] = py;
        out[o + 2] = pz;
        const rSq = px * px + py * py + pz * pz;
        if (rSq > maxRadiusSq)
            maxRadiusSq = rSq;
        const nr = rotateVec3(q, [src[o + 3] * invSx, src[o + 4] * invSy, src[o + 5] * invSz]);
        const len = Math.hypot(nr[0], nr[1], nr[2]) || 1;
        out[o + 3] = nr[0] / len;
        out[o + 4] = nr[1] / len;
        out[o + 5] = nr[2] / len;
    }
    return source.colors
        ? { data: out, colors: source.colors.slice(), vertexCount: n, radius: Math.sqrt(maxRadiusSq) }
        : { data: out, vertexCount: n, radius: Math.sqrt(maxRadiusSq) };
}
/** Merge an array of already-oriented sub-meshes into a single batched mesh (optional AO). */
function mergeMeshes(sources) {
    let totalVerts = 0;
    let hasColors = false;
    for (let i = 0; i < sources.length; i++) {
        totalVerts += sources[i].vertexCount;
        if (sources[i].colors)
            hasColors = true;
    }
    const data = new Float32Array(totalVerts * 6);
    const colors = hasColors ? new Float32Array(totalVerts * 3) : undefined;
    let vCursor = 0;
    let maxRadiusSq = 0;
    for (let s = 0; s < sources.length; s++) {
        const m = sources[s];
        data.set(m.data, vCursor * 6);
        if (colors) {
            if (m.colors) {
                colors.set(m.colors, vCursor * 3);
            }
            else {
                colors.fill(1, vCursor * 3, (vCursor + m.vertexCount) * 3);
            }
        }
        const rSq = m.radius * m.radius;
        if (rSq > maxRadiusSq)
            maxRadiusSq = rSq;
        vCursor += m.vertexCount;
    }
    return colors
        ? { data, colors, vertexCount: totalVerts, radius: Math.sqrt(maxRadiusSq) }
        : { data, vertexCount: totalVerts, radius: Math.sqrt(maxRadiusSq) };
}
/**
 * Orient a whole multi-part weapon cleanly around its grip `[0, 0, 0]` so every sub-part
 * shares the exact same socket-space tilt and seats firmly inside the mannequin palm.
 */
function orientParts(parts, rotation, offset = [0, 0, 0]) {
    const q = quaternionFromEuler(rotation[0], rotation[1], rotation[2]);
    const out = [];
    for (let i = 0; i < parts.length; i++) {
        const p = parts[i];
        const lp = p.position ?? [0, 0, 0];
        const rp = rotateVec3(q, lp);
        out.push({
            name: p.name,
            mesh: p.mesh,
            position: [rp[0] + offset[0], rp[1] + offset[1], rp[2] + offset[2]],
            rotation,
            color: p.color,
            unlit: p.unlit
        });
    }
    return out;
}
/** Build a diamond-section faceted blade lofted along +Y (width along Z, bevel thickness along X). */
function diamondBladeLoft(stations, aoStrength = 0.14) {
    const rings = [];
    for (let i = 0; i < stations.length; i++) {
        const [y, hx, hz, zOff = 0] = stations[i];
        const tx = Math.max(0.0025, hx);
        const tz = Math.max(0.003, hz);
        rings.push({
            y,
            points: [
                [tx, zOff],
                [0, tz + zOff],
                [-tx, zOff],
                [0, -tz + zOff]
            ]
        });
    }
    return sculptLoft(rings, { aoStrength, aoGradient: 0.08 });
}
/** Build an extruded 2D silhouette oriented in the YZ plane (weapon edge along +/-Z, thickness along X). */
function extrudeYZ(pointsZY, thicknessX, ao = 0.16) {
    // extrudeMesh puts polygon in XY with depth along Z; rotating yaw = -PI/2 maps +X -> +Z, +Z -> -X.
    const raw = extrudeMesh(pointsZY, thicknessX);
    const oriented = transformMesh(raw, [0, 0, 0], [0, -Math.PI * 0.5, 0]);
    return ao > 0 ? bakeVertexAO(oriented, { strength: ao, verticalGradient: 0.08 }) : oriented;
}
/** Build a closed polygonal ring lying in the XZ plane using tubeMesh. */
function ringTube(radius, tubeRadius, segments = 12, sides = 5) {
    const pts = [];
    for (let i = 0; i <= segments; i++) {
        const a = (i / segments) * Math.PI * 2;
        pts.push([Math.cos(a) * radius, 0, Math.sin(a) * radius]);
    }
    return bakeVertexAO(tubeMesh(pts, tubeRadius, sides), { strength: 0.14, verticalGradient: 0.06 });
}
let cachedMeshes;
function getWeaponMeshes() {
    if (cachedMeshes)
        return cachedMeshes;
    // --- 1. Broadsword ---
    const broadswordGrip = sculptLoft([
        { y: -0.088, rx: 0.024, rz: 0.030 },
        { y: -0.030, rx: 0.027, rz: 0.034 },
        { y: 0.030, rx: 0.027, rz: 0.034 },
        { y: 0.088, rx: 0.025, rz: 0.031 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.08 });
    const broadswordPommel = sculptLoft([
        { y: -0.155, rx: 0.016, rz: 0.020 },
        { y: -0.122, rx: 0.044, rz: 0.048 },
        { y: -0.086, rx: 0.030, rz: 0.034 }
    ], { sides: 6, aoStrength: 0.15, aoGradient: 0.08 });
    const broadswordGuard = extrudeYZ([
        [-0.148, 0.095], [-0.122, 0.142], [-0.048, 0.138], [0, 0.158],
        [0.048, 0.138], [0.122, 0.142], [0.148, 0.095], [0.068, 0.082],
        [-0.068, 0.082]
    ], 0.056, 0.16);
    const broadswordBlade = diamondBladeLoft([
        [0.140, 0.028, 0.068],
        [0.420, 0.026, 0.064],
        [0.640, 0.022, 0.056],
        [0.790, 0.004, 0.005]
    ], 0.14);
    const broadswordFuller = sculptLoft([
        { y: 0.155, rx: 0.033, rz: 0.024 },
        { y: 0.570, rx: 0.029, rz: 0.017 },
        { y: 0.625, rx: 0.016, rz: 0.007 }
    ], { sides: 4, aoStrength: 0.10, aoGradient: 0.05 });
    // --- 2. Sunblade (Grand Gilded Greatsword) ---
    const sunbladeGrip = sculptLoft([
        { y: -0.110, rx: 0.027, rz: 0.032 },
        { y: 0.000, rx: 0.030, rz: 0.036 },
        { y: 0.110, rx: 0.028, rz: 0.033 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.08 });
    const sunbladePommel = sculptLoft([
        { y: -0.195, rx: 0.012, rz: 0.014 },
        { y: -0.152, rx: 0.054, rz: 0.060 },
        { y: -0.106, rx: 0.034, rz: 0.038 }
    ], { sides: 6, aoStrength: 0.14, aoGradient: 0.08 });
    const sunbladeGuard = mergeMeshes([
        extrudeYZ([
            [-0.242, 0.236], [-0.192, 0.258], [-0.074, 0.184], [0, 0.228],
            [0.074, 0.184], [0.192, 0.258], [0.242, 0.236], [0.172, 0.128],
            [0.068, 0.098], [-0.068, 0.098], [-0.172, 0.128]
        ], 0.070, 0.16),
        transformMesh(sculptLoft([
            { y: -0.022, rx: 0.038, rz: 0.044 },
            { y: 0.022, rx: 0.038, rz: 0.044 }
        ], { sides: 6, aoStrength: 0.12 }), [0, 0, 0])
    ]);
    const sunbladeGem = transformMesh(octahedron, [0, 0.158, 0], [0, 0, 0], [0.054, 0.062, 0.062]);
    const sunbladeBlade = diamondBladeLoft([
        [0.185, 0.032, 0.098],
        [0.340, 0.032, 0.090],
        [0.750, 0.027, 0.082],
        [0.970, 0.005, 0.006]
    ], 0.14);
    const sunbladeCore = diamondBladeLoft([
        [0.205, 0.040, 0.038],
        [0.765, 0.034, 0.030],
        [0.885, 0.008, 0.006]
    ], 0);
    // --- 3. Arrow Nocked ---
    const arrowShaft = sculptLoft([
        { y: -0.22, rx: 0.017, rz: 0.017 },
        { y: 0.44, rx: 0.017, rz: 0.017 }
    ], { sides: 6, aoStrength: 0.14, aoGradient: 0.06 });
    const arrowNock = sculptLoft([
        { y: -0.260, rx: 0.022, rz: 0.022 },
        { y: -0.215, rx: 0.020, rz: 0.020 }
    ], { sides: 6, aoStrength: 0.12 });
    const vaneBase = extrudeMesh([
        [0.012, -0.232], [0.086, -0.248], [0.078, -0.105], [0.014, -0.062]
    ], 0.014);
    const arrowFletching = bakeVertexAO(mergeMeshes([
        transformMesh(vaneBase, [0, 0, 0], [0, 0, 0]),
        transformMesh(vaneBase, [0, 0, 0], [0, (Math.PI * 2) / 3, 0]),
        transformMesh(vaneBase, [0, 0, 0], [0, (Math.PI * 4) / 3, 0])
    ]), { strength: 0.12, verticalGradient: 0.06 });
    const arrowHead = diamondBladeLoft([
        [0.420, 0.022, 0.052],
        [0.455, 0.028, 0.066],
        [0.620, 0.004, 0.004]
    ], 0.14);
    // --- 4. Staff Arcane ---
    const staffArcaneShaft = sculptLoft([
        { y: -0.36, rx: 0.026, rz: 0.026 },
        { y: -0.10, rx: 0.029, rz: 0.029 },
        { y: 0.14, rx: 0.030, rz: 0.030 },
        { y: 0.46, rx: 0.032, rz: 0.032, zOffset: 0.008 },
        { y: 0.64, rx: 0.038, rz: 0.038, zOffset: 0.010 }
    ], { sides: 6, aoStrength: 0.18, aoGradient: 0.10 });
    const staffArcaneGrip = sculptLoft([
        { y: -0.095, rx: 0.034, rz: 0.034 },
        { y: 0.000, rx: 0.036, rz: 0.036 },
        { y: 0.095, rx: 0.034, rz: 0.034 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.08 });
    const arcaneProng0 = tubeMesh([
        [0.036, 0.68, 0.010],
        [0.108, 0.77, 0.010],
        [0.116, 0.90, 0.010],
        [0.072, 0.99, 0.010]
    ], [0.024, 0.022, 0.018, 0.011], 5);
    const arcaneProng1 = transformMesh(arcaneProng0, [0, 0, 0], [0, Math.PI, 0]);
    const arcaneProng2 = tubeMesh([
        [0, 0.68, 0.044],
        [0, 0.77, 0.114],
        [0, 0.88, 0.110],
        [0, 0.96, 0.068]
    ], [0.022, 0.020, 0.016, 0.010], 5);
    const arcaneProng3 = tubeMesh([
        [0, 0.68, -0.026],
        [0, 0.77, -0.096],
        [0, 0.88, -0.092],
        [0, 0.96, -0.052]
    ], [0.022, 0.020, 0.016, 0.010], 5);
    const staffArcaneGold = bakeVertexAO(mergeMeshes([
        // Butt ferrule cap (bottom at -0.415 -> safely above ground -0.47!)
        sculptLoft([
            { y: -0.415, rx: 0.016, rz: 0.016 },
            { y: -0.355, rx: 0.033, rz: 0.033 },
            { y: -0.320, rx: 0.030, rz: 0.030 }
        ], { sides: 6 }),
        // Upper collar below crystal cradle
        sculptLoft([
            { y: 0.60, rx: 0.042, rz: 0.042, zOffset: 0.010 },
            { y: 0.66, rx: 0.066, rz: 0.066, zOffset: 0.010 },
            { y: 0.71, rx: 0.054, rz: 0.054, zOffset: 0.010 }
        ], { sides: 6 }),
        arcaneProng0,
        arcaneProng1,
        arcaneProng2,
        arcaneProng3
    ]), { strength: 0.16, verticalGradient: 0.08 });
    const staffArcaneCrystal = sculptLoft([
        { y: 0.74, rx: 0.008, rz: 0.008, zOffset: 0.010 },
        { y: 0.84, rx: 0.078, rz: 0.078, zOffset: 0.010 },
        { y: 0.93, rx: 0.068, rz: 0.068, zOffset: 0.010 },
        { y: 1.07, rx: 0.006, rz: 0.006, zOffset: 0.010 }
    ], { sides: 6, aoStrength: 0.06, aoGradient: 0.04 });
    // --- 5. Staff Frost ---
    const staffFrostShaft = bakeVertexAO(mergeMeshes([
        sculptLoft([
            { y: -0.415, rx: 0.015, rz: 0.015 },
            { y: -0.340, rx: 0.032, rz: 0.032 },
            { y: 0.220, rx: 0.030, rz: 0.030 },
            { y: 0.540, rx: 0.042, rz: 0.040 },
            { y: 0.640, rx: 0.056, rz: 0.052 }
        ], { sides: 6 }),
        sculptLoft([
            { y: 0.44, rx: 0.046, rz: 0.046 },
            { y: 0.50, rx: 0.058, rz: 0.058 },
            { y: 0.55, rx: 0.044, rz: 0.044 }
        ], { sides: 6 })
    ]), { strength: 0.16, verticalGradient: 0.10 });
    const staffFrostGrip = sculptLoft([
        { y: -0.095, rx: 0.036, rz: 0.036 },
        { y: 0.000, rx: 0.038, rz: 0.038 },
        { y: 0.095, rx: 0.036, rz: 0.036 }
    ], { sides: 6, aoStrength: 0.14, aoGradient: 0.08 });
    const frostShardA = sculptLoft([
        { y: 0.60, rx: 0.044, rz: 0.036, xOffset: -0.052, zOffset: 0.014 },
        { y: 0.80, rx: 0.036, rz: 0.032, xOffset: -0.096, zOffset: 0.022 },
        { y: 1.05, rx: 0.005, rz: 0.005, xOffset: -0.048, zOffset: 0.018 }
    ], { sides: 5 });
    const frostShardB = sculptLoft([
        { y: 0.60, rx: 0.044, rz: 0.036, xOffset: 0.052, zOffset: -0.010 },
        { y: 0.82, rx: 0.036, rz: 0.032, xOffset: 0.098, zOffset: -0.016 },
        { y: 1.02, rx: 0.005, rz: 0.005, xOffset: 0.056, zOffset: -0.008 }
    ], { sides: 5 });
    const frostShardC = sculptLoft([
        { y: 0.58, rx: 0.036, rz: 0.044, xOffset: 0.008, zOffset: 0.056 },
        { y: 0.76, rx: 0.028, rz: 0.034, xOffset: 0.012, zOffset: 0.104 },
        { y: 0.94, rx: 0.005, rz: 0.005, xOffset: 0.006, zOffset: 0.068 }
    ], { sides: 5 });
    const frostShardD = sculptLoft([
        { y: 0.58, rx: 0.036, rz: 0.040, xOffset: -0.010, zOffset: -0.052 },
        { y: 0.74, rx: 0.026, rz: 0.030, xOffset: -0.012, zOffset: -0.092 },
        { y: 0.90, rx: 0.005, rz: 0.005, xOffset: -0.008, zOffset: -0.062 }
    ], { sides: 5 });
    const staffFrostSpires = bakeVertexAO(mergeMeshes([frostShardA, frostShardB, frostShardC, frostShardD]), { strength: 0.14, verticalGradient: 0.08 });
    const staffFrostDiamond = transformMesh(octahedron, [0, 0.85, 0.004], [0, Math.PI * 0.25, 0], [0.068, 0.118, 0.068]);
    // --- 6. Mace Sun (Flanged Golden Cleric War-Mace) ---
    const maceGrip = sculptLoft([
        { y: -0.095, rx: 0.028, rz: 0.030 },
        { y: 0.000, rx: 0.031, rz: 0.033 },
        { y: 0.095, rx: 0.028, rz: 0.030 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.08 });
    const maceShaft = sculptLoft([
        { y: 0.090, rx: 0.026, rz: 0.026 },
        { y: 0.390, rx: 0.030, rz: 0.030 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.08 });
    const maceFlangeRaw = extrudeMesh([
        [0.042, 0.405], [0.132, 0.445], [0.156, 0.545], [0.124, 0.648], [0.042, 0.678]
    ], 0.024);
    const maceFlanges = [
        // Pommel
        sculptLoft([
            { y: -0.158, rx: 0.018, rz: 0.018 },
            { y: -0.124, rx: 0.044, rz: 0.044 },
            { y: -0.090, rx: 0.032, rz: 0.032 }
        ], { sides: 6 }),
        // Neck collar
        sculptLoft([
            { y: 0.365, rx: 0.044, rz: 0.044 },
            { y: 0.415, rx: 0.062, rz: 0.062 },
            { y: 0.445, rx: 0.052, rz: 0.052 }
        ], { sides: 6 }),
        // Top finial crown spike
        sculptLoft([
            { y: 0.640, rx: 0.058, rz: 0.058 },
            { y: 0.695, rx: 0.042, rz: 0.042 },
            { y: 0.790, rx: 0.006, rz: 0.006 }
        ], { sides: 6 })
    ];
    for (let i = 0; i < 6; i++) {
        maceFlanges.push(transformMesh(maceFlangeRaw, [0, 0, 0], [0, (i / 6) * Math.PI * 2, 0]));
    }
    const maceHeadGold = bakeVertexAO(mergeMeshes(maceFlanges), { strength: 0.16, verticalGradient: 0.08 });
    const maceCore = sculptLoft([
        { y: 0.435, rx: 0.056, rz: 0.056 },
        { y: 0.545, rx: 0.106, rz: 0.106 },
        { y: 0.655, rx: 0.056, rz: 0.056 }
    ], { sides: 8, aoStrength: 0.06, aoGradient: 0.04 });
    // --- 7. Dagger (Sleek Curved Dark-Steel Rogue Dagger + Mirrored Off-Hand) ---
    const daggerGrip = bakeVertexAO(mergeMeshes([
        sculptLoft([
            { y: -0.082, rx: 0.025, rz: 0.030 },
            { y: 0.000, rx: 0.029, rz: 0.034 },
            { y: 0.082, rx: 0.026, rz: 0.031 }
        ], { sides: 6 }),
        sculptLoft([
            { y: -0.142, rx: 0.014, rz: 0.016 },
            { y: -0.108, rx: 0.040, rz: 0.046 },
            { y: -0.078, rx: 0.028, rz: 0.032 }
        ], { sides: 6 })
    ]), { strength: 0.16, verticalGradient: 0.08 });
    const daggerGuard = extrudeYZ([
        [-0.112, 0.118], [-0.084, 0.142], [0, 0.112], [0.092, 0.148],
        [0.118, 0.116], [0.056, 0.072], [-0.056, 0.072]
    ], 0.054, 0.16);
    const daggerBlade = extrudeYZ([
        [-0.034, 0.110], [-0.024, 0.265], [0.012, 0.420], [0.086, 0.560],
        [0.066, 0.400], [0.050, 0.240], [0.050, 0.110]
    ], 0.040, 0.16);
    const daggerEdge = extrudeYZ([
        [0.034, 0.120], [0.034, 0.250], [0.050, 0.400], [0.090, 0.568],
        [0.078, 0.395], [0.060, 0.238], [0.058, 0.118]
    ], 0.022, 0.08);
    const offDaggerBlade = extrudeYZ([
        [0.034, 0.110], [0.024, 0.265], [-0.012, 0.420], [-0.086, 0.560],
        [-0.066, 0.400], [-0.050, 0.240], [-0.050, 0.110]
    ], 0.040, 0.16);
    const offDaggerEdge = extrudeYZ([
        [-0.034, 0.120], [-0.034, 0.250], [-0.050, 0.400], [-0.090, 0.568],
        [-0.078, 0.395], [-0.060, 0.238], [-0.058, 0.118]
    ], 0.022, 0.08);
    // --- 8. Greataxe (Chunky Double-Bladed Orc Battleaxe) ---
    const axeHaft = sculptLoft([
        { y: -0.24, rx: 0.030, rz: 0.030 },
        { y: 0.12, rx: 0.033, rz: 0.033 },
        { y: 0.56, rx: 0.036, rz: 0.036 },
        { y: 0.70, rx: 0.034, rz: 0.034 }
    ], { sides: 6, aoStrength: 0.18, aoGradient: 0.10 });
    const axeWrap = bakeVertexAO(mergeMeshes([
        sculptLoft([
            { y: -0.095, rx: 0.038, rz: 0.038 },
            { y: 0.000, rx: 0.041, rz: 0.041 },
            { y: 0.095, rx: 0.038, rz: 0.038 }
        ], { sides: 6 }),
        sculptLoft([
            { y: 0.32, rx: 0.040, rz: 0.040 },
            { y: 0.40, rx: 0.042, rz: 0.042 }
        ], { sides: 6 })
    ]), { strength: 0.16, verticalGradient: 0.08 });
    const axeCollar = bakeVertexAO(mergeMeshes([
        // Butt iron cap
        sculptLoft([
            { y: -0.285, rx: 0.020, rz: 0.020 },
            { y: -0.240, rx: 0.040, rz: 0.040 },
            { y: -0.205, rx: 0.036, rz: 0.036 }
        ], { sides: 6 }),
        // Central axe socket housing
        transformMesh(bevelBox(0.14), [0, 0.565, 0], ZERO_ROT, [0.098, 0.215, 0.118]),
        // Top crown spike
        sculptLoft([
            { y: 0.665, rx: 0.044, rz: 0.048 },
            { y: 0.725, rx: 0.030, rz: 0.032 },
            { y: 0.835, rx: 0.005, rz: 0.005 }
        ], { sides: 4 })
    ]), { strength: 0.18, verticalGradient: 0.08 });
    const axeBladeWing = [
        [0.045, 0.490], [0.165, 0.410], [0.245, 0.435], [0.275, 0.565],
        [0.245, 0.695], [0.165, 0.720], [0.045, 0.640]
    ];
    const axeBladeWingBack = [
        [-0.045, 0.490], [-0.165, 0.410], [-0.245, 0.435], [-0.275, 0.565],
        [-0.245, 0.695], [-0.165, 0.720], [-0.045, 0.640]
    ];
    const axeBlades = mergeMeshes([
        extrudeYZ(axeBladeWing, 0.050, 0.16),
        extrudeYZ(axeBladeWingBack, 0.050, 0.16)
    ]);
    const axeEdgeFront = [
        [0.228, 0.422], [0.268, 0.442], [0.296, 0.565], [0.268, 0.688], [0.228, 0.708], [0.254, 0.565]
    ];
    const axeEdgeBack = [
        [-0.228, 0.422], [-0.268, 0.442], [-0.296, 0.565], [-0.268, 0.688], [-0.228, 0.708], [-0.254, 0.565]
    ];
    const axeEdges = mergeMeshes([
        extrudeYZ(axeEdgeFront, 0.028, 0.08),
        extrudeYZ(axeEdgeBack, 0.028, 0.08)
    ]);
    const rivetOffsets = [
        [0.054, 0.625, 0.034], [0.054, 0.505, 0.034], [0.054, 0.625, -0.034], [0.054, 0.505, -0.034],
        [-0.054, 0.625, 0.034], [-0.054, 0.505, 0.034], [-0.054, 0.625, -0.034], [-0.054, 0.505, -0.034],
        [0.032, 0.565, 0.145], [-0.032, 0.565, 0.145], [0.032, 0.565, -0.145], [-0.032, 0.565, -0.145]
    ];
    const rivetParts = [];
    for (let i = 0; i < rivetOffsets.length; i++) {
        rivetParts.push(transformMesh(octahedron, rivetOffsets[i], ZERO_ROT, [0.023, 0.023, 0.023]));
    }
    const axeRivets = mergeMeshes(rivetParts);
    // --- 9. Scythe Bone (Tall Bone-Shafted Reaper Scythe) ---
    const scytheShaft = bakeVertexAO(mergeMeshes([
        tubeMesh([
            [0, -0.40, -0.010],
            [0, -0.18, 0.004],
            [0, 0.00, 0.000],
            [0, 0.28, -0.016],
            [0, 0.58, 0.012],
            [0, 0.82, 0.036]
        ], [0.024, 0.027, 0.029, 0.028, 0.031, 0.035], 6),
        // Knobby bone joints at bottom, mid-upper, and crown
        sculptLoft([
            { y: -0.420, rx: 0.034, rz: 0.038, zOffset: -0.012 },
            { y: -0.370, rx: 0.038, rz: 0.042, zOffset: -0.010 },
            { y: -0.335, rx: 0.026, rz: 0.028, zOffset: -0.008 }
        ], { sides: 6 }),
        sculptLoft([
            { y: 0.34, rx: 0.036, rz: 0.038, zOffset: -0.014 },
            { y: 0.38, rx: 0.044, rz: 0.046, zOffset: -0.012 },
            { y: 0.42, rx: 0.034, rz: 0.036, zOffset: -0.010 }
        ], { sides: 6 }),
        sculptLoft([
            { y: 0.80, rx: 0.046, rz: 0.052, zOffset: 0.036 },
            { y: 0.87, rx: 0.032, rz: 0.036, zOffset: 0.038 },
            { y: 0.94, rx: 0.008, rz: 0.008, zOffset: 0.040 }
        ], { sides: 6 })
    ]), { strength: 0.18, verticalGradient: 0.10 });
    const scytheWrap = sculptLoft([
        { y: -0.095, rx: 0.035, rz: 0.035 },
        { y: 0.000, rx: 0.037, rz: 0.037 },
        { y: 0.095, rx: 0.035, rz: 0.035 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.08 });
    const scytheCollar = bakeVertexAO(mergeMeshes([
        sculptLoft([
            { y: 0.69, rx: 0.050, rz: 0.056, zOffset: 0.026 },
            { y: 0.76, rx: 0.062, rz: 0.072, zOffset: 0.034 },
            { y: 0.82, rx: 0.050, rz: 0.058, zOffset: 0.036 }
        ], { sides: 6 }),
        // Rear counterbalance bone/iron spike
        extrudeYZ([
            [0.01, 0.79], [-0.14, 0.82], [-0.08, 0.74], [0.01, 0.73]
        ], 0.032, 0.12)
    ]), { strength: 0.16, verticalGradient: 0.08 });
    const scytheBlade = extrudeYZ([
        [0.02, 0.81], [0.18, 0.89], [0.39, 0.87], [0.56, 0.74], [0.66, 0.49],
        [0.53, 0.64], [0.36, 0.74], [0.18, 0.75], [0.02, 0.71]
    ], 0.044, 0.16);
    const scytheEdge = extrudeYZ([
        [0.05, 0.72], [0.19, 0.76], [0.37, 0.75], [0.54, 0.65], [0.675, 0.475],
        [0.51, 0.61], [0.35, 0.71], [0.17, 0.71], [0.05, 0.69]
    ], 0.022, 0.08);
    // --- 10. Goblin Cleaver (Notched Jagged Crude Iron Machete) ---
    const cleaverGrip = bakeVertexAO(mergeMeshes([
        sculptLoft([
            { y: -0.082, rx: 0.025, rz: 0.030 },
            { y: 0.000, rx: 0.029, rz: 0.034 },
            { y: 0.082, rx: 0.027, rz: 0.031 }
        ], { sides: 5 }),
        sculptLoft([
            { y: -0.130, rx: 0.024, rz: 0.026 },
            { y: -0.098, rx: 0.042, rz: 0.046 },
            { y: -0.078, rx: 0.030, rz: 0.032 }
        ], { sides: 5 })
    ]), { strength: 0.16, verticalGradient: 0.08 });
    const cleaverGuard = extrudeYZ([
        [-0.082, 0.082], [-0.068, 0.120], [0.102, 0.128], [0.114, 0.084]
    ], 0.056, 0.16);
    // Jagged heavy cleaver profile with 2 distinct deep battle notches on the +Z cutting edge & hooked tip
    const cleaverBlade = extrudeYZ([
        [-0.046, 0.118], [-0.058, 0.370], [-0.068, 0.560], [0.018, 0.625],
        [0.118, 0.575], [0.088, 0.482], [0.036, 0.456], [0.098, 0.415],
        [0.092, 0.305], [0.034, 0.280], [0.086, 0.238], [0.074, 0.118]
    ], 0.046, 0.18);
    const cleaverEdge = extrudeYZ([
        [0.058, 0.122], [0.070, 0.238], [0.024, 0.280], [0.078, 0.308],
        [0.084, 0.415], [0.026, 0.456], [0.076, 0.485], [0.104, 0.570],
        [0.126, 0.578], [0.096, 0.478], [0.044, 0.454], [0.106, 0.415],
        [0.100, 0.302], [0.042, 0.278], [0.094, 0.235], [0.082, 0.122]
    ], 0.022, 0.08);
    const cleaverRivets = mergeMeshes([
        transformMesh(octahedron, [0.028, 0.20, -0.024], ZERO_ROT, [0.020, 0.020, 0.020]),
        transformMesh(octahedron, [-0.028, 0.20, -0.024], ZERO_ROT, [0.020, 0.020, 0.020]),
        transformMesh(octahedron, [0.028, 0.47, -0.036], ZERO_ROT, [0.022, 0.022, 0.022]),
        transformMesh(octahedron, [-0.028, 0.47, -0.036], ZERO_ROT, [0.022, 0.022, 0.022])
    ]);
    // --- 11. Obsidian Greatsword (Massive Dark-Iron Warlord Greatsword + Violet Rune Core) ---
    const obsidianGrip = sculptLoft([
        { y: -0.115, rx: 0.029, rz: 0.034 },
        { y: 0.000, rx: 0.032, rz: 0.038 },
        { y: 0.115, rx: 0.030, rz: 0.035 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.08 });
    const obsidianGuard = mergeMeshes([
        // Jagged spiked pommel
        sculptLoft([
            { y: -0.215, rx: 0.008, rz: 0.008 },
            { y: -0.160, rx: 0.056, rz: 0.066 },
            { y: -0.110, rx: 0.036, rz: 0.042 }
        ], { sides: 6, aoStrength: 0.16 }),
        // Horned jagged warlord crossguard
        extrudeYZ([
            [-0.235, 0.250], [-0.185, 0.145], [-0.072, 0.098], [0.072, 0.098],
            [0.185, 0.145], [0.235, 0.250], [0.165, 0.210], [0.082, 0.172],
            [0, 0.210], [-0.082, 0.172], [-0.165, 0.210]
        ], 0.074, 0.18)
    ]);
    // Wide jagged obsidian core blade with ricasso teeth
    const obsidianBlade = extrudeYZ([
        [-0.086, 0.185], [-0.122, 0.290], [-0.082, 0.340], [-0.098, 0.720],
        [-0.074, 0.865], [0, 1.005], [0.074, 0.865], [0.098, 0.720],
        [0.082, 0.340], [0.122, 0.290], [0.086, 0.185]
    ], 0.048, 0.16);
    // Brighter gunmetal beveled outer cutting edges so dark obsidian reads crisply against dark floors
    const obsidianEdges = diamondBladeLoft([
        [0.195, 0.018, 0.096],
        [0.340, 0.018, 0.092],
        [0.720, 0.016, 0.106],
        [0.865, 0.013, 0.082],
        [1.015, 0.004, 0.005]
    ], 0.10);
    const obsidianRunes = mergeMeshes([
        // Central glowing violet rune channel
        diamondBladeLoft([
            [0.240, 0.038, 0.030],
            [0.805, 0.033, 0.024],
            [0.895, 0.009, 0.007]
        ], 0),
        // Guard rune gem + 3 diamond rune nodes along blade + pommel gem
        transformMesh(octahedron, [0, 0.155, 0], ZERO_ROT, [0.056, 0.068, 0.068]),
        transformMesh(octahedron, [0, 0.420, 0], ZERO_ROT, [0.046, 0.064, 0.054]),
        transformMesh(octahedron, [0, 0.625, 0], ZERO_ROT, [0.042, 0.058, 0.048]),
        transformMesh(octahedron, [0, -0.162, 0], ZERO_ROT, [0.038, 0.040, 0.040])
    ]);
    // --- Shared Shield Grip Handle (connects [0,0,0] inside handL to back of shield!) ---
    const shieldGrip = bakeVertexAO(mergeMeshes([
        sculptLoft([
            { y: -0.075, rx: 0.024, rz: 0.024 },
            { y: 0.075, rx: 0.024, rz: 0.024 }
        ], { sides: 6 }),
        // Upper & lower sturdy iron bracket struts connecting grip to shield face (+Z in shield-local space)
        transformMesh(bevelBox(0.14), [0, 0.062, 0.045], ZERO_ROT, [0.032, 0.026, 0.095]),
        transformMesh(bevelBox(0.14), [0, -0.062, 0.045], ZERO_ROT, [0.032, 0.026, 0.095])
    ]), { strength: 0.16, verticalGradient: 0.08 });
    // --- 12. Shield Heater ---
    const heaterOuterPoly = [
        [0, -0.250], [0.132, -0.165], [0.196, -0.010], [0.200, 0.165],
        [0.132, 0.228], [0, 0.244], [-0.132, 0.228], [-0.200, 0.165],
        [-0.196, -0.010], [-0.132, -0.165]
    ];
    const heaterInnerPoly = [
        [0, -0.206], [0.104, -0.134], [0.158, -0.008], [0.160, 0.136],
        [0.104, 0.188], [0, 0.200], [-0.104, 0.188], [-0.160, 0.136],
        [-0.158, -0.008], [-0.104, -0.134]
    ];
    const heaterRim = bakeVertexAO(transformMesh(extrudeMesh(heaterOuterPoly, 0.044), [0, 0.040, 0.088]), { strength: 0.18, verticalGradient: 0.10 });
    const rawHeaterField = transformMesh(extrudeMesh(heaterInnerPoly, 0.026), [0, 0.040, 0.106]);
    const heaterField = bakeVertexAO(bakeZoneColors(rawHeaterField, (_cx, cy) => (cy > 0.04 ? WHITE : [0.88, 0.88, 0.92, 1])), { strength: 0.14, verticalGradient: 0.08 });
    const heaterCrest = bakeVertexAO(mergeMeshes([
        // Raised faceted diamond heraldic crest
        transformMesh(extrudeMesh([[0, -0.108], [0.082, 0], [0, 0.108], [-0.082, 0]], 0.026), [0, 0.045, 0.124]),
        transformMesh(octahedron, [0, 0.045, 0.138], ZERO_ROT, [0.046, 0.062, 0.028]),
        // 4 crisp corner studs
        transformMesh(octahedron, [-0.142, 0.168, 0.114], ZERO_ROT, [0.018, 0.018, 0.016]),
        transformMesh(octahedron, [0.142, 0.168, 0.114], ZERO_ROT, [0.018, 0.018, 0.016]),
        transformMesh(octahedron, [-0.122, -0.085, 0.114], ZERO_ROT, [0.018, 0.018, 0.016]),
        transformMesh(octahedron, [0.122, -0.085, 0.114], ZERO_ROT, [0.018, 0.018, 0.016])
    ]), { strength: 0.14, verticalGradient: 0.06 });
    // --- 13. Shield Tower Paladin ---
    const paladinOuterPoly = [
        [0, -0.320], [0.142, -0.242], [0.205, -0.080], [0.214, 0.210],
        [0.145, 0.295], [0, 0.325], [-0.145, 0.295], [-0.214, 0.210],
        [-0.205, -0.080], [-0.142, -0.242]
    ];
    const paladinCobaltPoly = [
        [0, -0.278], [0.118, -0.208], [0.172, -0.068], [0.178, 0.185],
        [0.120, 0.258], [0, 0.284], [-0.120, 0.258], [-0.178, 0.185],
        [-0.172, -0.068], [-0.118, -0.208]
    ];
    const paladinIvoryPoly = [
        [0, -0.218], [0.088, -0.160], [0.132, -0.048], [0.136, 0.152],
        [0.090, 0.210], [0, 0.232], [-0.090, 0.210], [-0.136, 0.152],
        [-0.132, -0.048], [-0.088, -0.160]
    ];
    const paladinRim = bakeVertexAO(transformMesh(extrudeMesh(paladinOuterPoly, 0.046), [0, 0.055, 0.092]), { strength: 0.18, verticalGradient: 0.10 });
    const paladinCobalt = bakeVertexAO(transformMesh(extrudeMesh(paladinCobaltPoly, 0.026), [0, 0.055, 0.108]), { strength: 0.15, verticalGradient: 0.08 });
    const paladinIvory = bakeVertexAO(transformMesh(extrudeMesh(paladinIvoryPoly, 0.022), [0, 0.055, 0.118]), { strength: 0.12, verticalGradient: 0.06 });
    const paladinCross = bakeVertexAO(mergeMeshes([
        // Vertical flared gold cross beam
        transformMesh(extrudeMesh([
            [-0.024, -0.185], [0.024, -0.185], [0.018, -0.04], [0.018, 0.10],
            [0.032, 0.185], [-0.032, 0.185], [-0.018, 0.10], [-0.018, -0.04]
        ], 0.024), [0, 0.065, 0.132]),
        // Horizontal flared gold cross beam
        transformMesh(extrudeMesh([
            [-0.118, 0.012], [-0.040, 0.020], [0.040, 0.020], [0.118, 0.012],
            [0.118, 0.070], [0.040, 0.062], [-0.040, 0.062], [-0.118, 0.070]
        ], 0.024), [0, 0.065, 0.132])
    ]), { strength: 0.12, verticalGradient: 0.06 });
    const paladinGem = transformMesh(octahedron, [0, 0.106, 0.148], ZERO_ROT, [0.036, 0.044, 0.024]);
    // --- 14. Shield Buckler (Compact Round Faceted Iron-and-Wood Buckler) ---
    const bucklerOuterPts = [];
    const bucklerInnerPts = [];
    const bucklerSides = 10;
    for (let i = 0; i < bucklerSides; i++) {
        const a = (i / bucklerSides) * Math.PI * 2 + Math.PI / bucklerSides;
        bucklerOuterPts.push([Math.cos(a) * 0.195, Math.sin(a) * 0.195]);
        bucklerInnerPts.push([Math.cos(a) * 0.156, Math.sin(a) * 0.156]);
    }
    const bucklerRim = bakeVertexAO(mergeMeshes([
        transformMesh(extrudeMesh(bucklerOuterPts, 0.038), [0, 0.020, 0.084]),
        // 4 crisp iron rim rivets
        transformMesh(octahedron, [0.000, 0.195, 0.102], ZERO_ROT, [0.018, 0.018, 0.016]),
        transformMesh(octahedron, [0.000, -0.155, 0.102], ZERO_ROT, [0.018, 0.018, 0.016]),
        transformMesh(octahedron, [0.175, 0.020, 0.102], ZERO_ROT, [0.018, 0.018, 0.016]),
        transformMesh(octahedron, [-0.175, 0.020, 0.102], ZERO_ROT, [0.018, 0.018, 0.016])
    ]), { strength: 0.18, verticalGradient: 0.08 });
    const rawBucklerWood = transformMesh(extrudeMesh(bucklerInnerPts, 0.024), [0, 0.020, 0.098]);
    const bucklerWood = bakeVertexAO(bakeZoneColors(rawBucklerWood, (cx) => {
        const band = Math.floor((cx + 0.2) * 16) % 2;
        return band === 0 ? WHITE : [0.89, 0.85, 0.82, 1];
    }), { strength: 0.14, verticalGradient: 0.08 });
    const bucklerBoss = bakeVertexAO(transformMesh(sculptLoft([
        { y: 0.000, rx: 0.072, rz: 0.072 },
        { y: 0.032, rx: 0.056, rz: 0.056 },
        { y: 0.054, rx: 0.022, rz: 0.022 }
    ], { sides: 8 }), [0, 0.020, 0.108], [Math.PI * 0.5, 0, 0]), { strength: 0.14, verticalGradient: 0.06 });
    // --- 15. Shield Obsidian (Menacing Jagged Dark-Iron Boss Shield + Violet Gem) ---
    const obsidianShieldOuter = [
        [0, -0.295], [0.135, -0.185], [0.228, -0.020], [0.212, 0.155],
        [0.242, 0.268], [0.125, 0.218], [0, 0.278], [-0.125, 0.218],
        [-0.242, 0.268], [-0.212, 0.155], [-0.228, -0.020], [-0.135, -0.185]
    ];
    const obsidianShieldInner = [
        [0, -0.225], [0.102, -0.140], [0.168, -0.012], [0.158, 0.135],
        [0.095, 0.182], [0, 0.205], [-0.095, 0.182], [-0.158, 0.135],
        [-0.168, -0.012], [-0.102, -0.140]
    ];
    const obsidianShieldRim = bakeVertexAO(transformMesh(extrudeMesh(obsidianShieldOuter, 0.048), [0, 0.045, 0.090]), { strength: 0.18, verticalGradient: 0.10 });
    const obsidianShieldField = bakeVertexAO(transformMesh(extrudeMesh(obsidianShieldInner, 0.026), [0, 0.045, 0.108]), { strength: 0.16, verticalGradient: 0.08 });
    const clawSpike = extrudeMesh([[0.040, -0.018], [0.138, 0], [0.040, 0.018]], 0.024);
    const obsidianShieldClaws = bakeVertexAO(mergeMeshes([
        transformMesh(clawSpike, [0, 0.048, 0.126], [0, 0, Math.PI * 0.25]),
        transformMesh(clawSpike, [0, 0.048, 0.126], [0, 0, Math.PI * 0.75]),
        transformMesh(clawSpike, [0, 0.048, 0.126], [0, 0, Math.PI * 1.25]),
        transformMesh(clawSpike, [0, 0.048, 0.126], [0, 0, Math.PI * 1.75])
    ]), { strength: 0.14, verticalGradient: 0.06 });
    const obsidianShieldGem = transformMesh(octahedron, [0, 0.048, 0.138], ZERO_ROT, [0.058, 0.088, 0.042]);
    // --- 16. Offhand Bow Recurve ---
    // Grip seated squarely at [0, 0, 0]; bold C-arch sweeps forward (+Z) out of the palm, curves back to
    // recurve knees, and kicks cleanly forward at horn tips — with a razor-straight taut bowstring!
    const bowLimbs = bakeVertexAO(tubeMesh([
        [0, -0.37, -0.145],
        [0, -0.25, -0.045],
        [0, -0.12, 0.008],
        [0, 0.00, 0.010],
        [0, 0.12, 0.008],
        [0, 0.27, -0.045],
        [0, 0.41, -0.145]
    ], [0.023, 0.028, 0.032, 0.031, 0.032, 0.028, 0.023], 6), { strength: 0.16, verticalGradient: 0.08 });
    const bowGrip = sculptLoft([
        { y: -0.082, rx: 0.035, rz: 0.038, zOffset: 0.009 },
        { y: 0.000, rx: 0.037, rz: 0.040, zOffset: 0.010 },
        { y: 0.082, rx: 0.035, rz: 0.038, zOffset: 0.009 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.08 });
    const bowTips = bakeVertexAO(mergeMeshes([
        // Top & bottom recurve horn tips kicking gracefully forward (+Z)
        tubeMesh([[0, 0.39, -0.132], [0, 0.445, -0.155], [0, 0.495, -0.118]], [0.025, 0.021, 0.012], 6),
        tubeMesh([[0, -0.35, -0.132], [0, -0.400, -0.152], [0, -0.440, -0.118]], [0.025, 0.021, 0.012], 6),
        // Decorative horn/ivory riser collars
        sculptLoft([
            { y: 0.110, rx: 0.036, rz: 0.036, zOffset: 0.008 },
            { y: 0.150, rx: 0.035, rz: 0.035, zOffset: 0.002 }
        ], { sides: 6 }),
        sculptLoft([
            { y: -0.150, rx: 0.035, rz: 0.035, zOffset: 0.002 },
            { y: -0.110, rx: 0.036, rz: 0.036, zOffset: 0.008 }
        ], { sides: 6 })
    ]), { strength: 0.14, verticalGradient: 0.06 });
    // Razor-straight taut bowstring spanning directly between the recurve nocks
    const bowString = tubeMesh([[0, -0.425, -0.130], [0, 0.475, -0.130]], [0.008, 0.008], 4);
    // --- 17. Offhand Spell Orb ---
    const orbCrystal = sculptLoft([
        { y: -0.112, rx: 0.006, rz: 0.006 },
        { y: -0.055, rx: 0.088, rz: 0.088 },
        { y: 0.000, rx: 0.108, rz: 0.108 },
        { y: 0.055, rx: 0.088, rz: 0.088 },
        { y: 0.112, rx: 0.006, rz: 0.006 }
    ], { sides: 8, aoStrength: 0.06, aoGradient: 0.04 });
    const orbRing = mergeMeshes([
        transformMesh(ringTube(0.156, 0.016, 12, 5), [0, 0, 0], [0.56, 0.22, 0.36]),
        transformMesh(ringTube(0.132, 0.011, 10, 4), [0, 0, 0], [-0.48, -0.18, -0.44])
    ]);
    const orbShards = mergeMeshes([
        transformMesh(octahedron, [0.145, 0.068, 0.042], [0.3, 0.2, 0.1], [0.024, 0.036, 0.024]),
        transformMesh(octahedron, [-0.140, -0.058, -0.036], [-0.2, 0.4, 0.2], [0.022, 0.032, 0.022])
    ]);
    // --- 18. Offhand Tome (Heavy Leather-and-Gold Clasped Arcane Spellbook) ---
    const tomeCover = bakeVertexAO(mergeMeshes([
        // Front leather cover (+Z)
        transformMesh(bevelBox(0.16), [0, 0.02, 0.046], ZERO_ROT, [0.220, 0.295, 0.022]),
        // Back leather cover (-Z)
        transformMesh(bevelBox(0.16), [0, 0.02, -0.046], ZERO_ROT, [0.220, 0.295, 0.022]),
        // Heavy rounded spine (-X)
        transformMesh(bevelBox(0.22), [-0.102, 0.02, 0], ZERO_ROT, [0.034, 0.298, 0.114])
    ]), { strength: 0.18, verticalGradient: 0.08 });
    const tomePages = bakeVertexAO(transformMesh(bevelBox(0.10), [0.008, 0.02, 0], ZERO_ROT, [0.194, 0.264, 0.072]), { strength: 0.14, verticalGradient: 0.06 });
    const tomeGold = bakeVertexAO(mergeMeshes([
        // Front 4 gold corner brackets
        transformMesh(bevelBox(0.14), [0.086, 0.144, 0.054], ZERO_ROT, [0.054, 0.054, 0.018]),
        transformMesh(bevelBox(0.14), [0.086, -0.104, 0.054], ZERO_ROT, [0.054, 0.054, 0.018]),
        transformMesh(bevelBox(0.14), [-0.086, 0.144, 0.054], ZERO_ROT, [0.054, 0.054, 0.018]),
        transformMesh(bevelBox(0.14), [-0.086, -0.104, 0.054], ZERO_ROT, [0.054, 0.054, 0.018]),
        // Heavy golden book clasp wrapping the fore-edge (+X)
        transformMesh(bevelBox(0.14), [0.108, 0.02, 0], ZERO_ROT, [0.024, 0.064, 0.122]),
        transformMesh(bevelBox(0.14), [0.082, 0.02, 0.056], ZERO_ROT, [0.058, 0.044, 0.018]),
        // Raised gold spine ribs
        transformMesh(bevelBox(0.14), [-0.114, 0.095, 0], ZERO_ROT, [0.020, 0.022, 0.120]),
        transformMesh(bevelBox(0.14), [-0.114, -0.055, 0], ZERO_ROT, [0.020, 0.022, 0.120])
    ]), { strength: 0.14, verticalGradient: 0.06 });
    const tomeSigil = mergeMeshes([
        transformMesh(octahedron, [0.002, 0.022, 0.060], ZERO_ROT, [0.046, 0.068, 0.016]),
        transformMesh(extrudeMesh([[-0.058, 0.006], [0.058, 0.006], [0.058, -0.006], [-0.058, -0.006]], 0.012), [0.002, 0.022, 0.060])
    ]);
    cachedMeshes = {
        broadswordGrip,
        broadswordPommel,
        broadswordGuard,
        broadswordBlade,
        broadswordFuller,
        sunbladeGrip,
        sunbladePommel,
        sunbladeGuard,
        sunbladeGem,
        sunbladeBlade,
        sunbladeCore,
        arrowShaft,
        arrowFletching,
        arrowHead,
        arrowNock,
        staffArcaneShaft,
        staffArcaneGrip,
        staffArcaneGold,
        staffArcaneCrystal,
        staffFrostShaft,
        staffFrostGrip,
        staffFrostSpires,
        staffFrostDiamond,
        maceGrip,
        maceShaft,
        maceHeadGold,
        maceCore,
        daggerGrip,
        daggerGuard,
        daggerBlade,
        daggerEdge,
        offDaggerBlade,
        offDaggerEdge,
        axeHaft,
        axeWrap,
        axeCollar,
        axeBlades,
        axeEdges,
        axeRivets,
        scytheShaft,
        scytheWrap,
        scytheCollar,
        scytheBlade,
        scytheEdge,
        cleaverGrip,
        cleaverGuard,
        cleaverBlade,
        cleaverEdge,
        cleaverRivets,
        obsidianGrip,
        obsidianGuard,
        obsidianBlade,
        obsidianEdges,
        obsidianRunes,
        shieldGrip,
        heaterRim,
        heaterField,
        heaterCrest,
        paladinRim,
        paladinCobalt,
        paladinIvory,
        paladinCross,
        paladinGem,
        bucklerRim,
        bucklerWood,
        bucklerBoss,
        obsidianShieldRim,
        obsidianShieldField,
        obsidianShieldClaws,
        obsidianShieldGem,
        bowLimbs,
        bowGrip,
        bowTips,
        bowString,
        orbCrystal,
        orbRing,
        orbShards,
        tomeCover,
        tomePages,
        tomeGold,
        tomeSigil
    };
    return cachedMeshes;
}
let cachedEclipseScepter;
/** Boss scepter: long shaft, gold crescent cradle holding a dark eclipse orb wrapped in a glowing ring. */
function getEclipseScepterMeshes() {
    if (cachedEclipseScepter)
        return cachedEclipseScepter;
    const shaft = sculptLoft([
        { y: -0.42, rx: 0.026, rz: 0.026 },
        { y: -0.10, rx: 0.030, rz: 0.030 },
        { y: 0.30, rx: 0.031, rz: 0.031 },
        { y: 0.66, rx: 0.036, rz: 0.036 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.10 });
    const grip = sculptLoft([
        { y: -0.095, rx: 0.037, rz: 0.037 },
        { y: 0.000, rx: 0.039, rz: 0.039 },
        { y: 0.095, rx: 0.037, rz: 0.037 }
    ], { sides: 6, aoStrength: 0.14, aoGradient: 0.08 });
    const collar = sculptLoft([
        { y: 0.620, rx: 0.040, rz: 0.040 },
        { y: 0.660, rx: 0.058, rz: 0.058 },
        { y: 0.710, rx: 0.044, rz: 0.044 }
    ], { sides: 6 });
    const butt = sculptLoft([
        { y: -0.500, rx: 0.006, rz: 0.006 },
        { y: -0.450, rx: 0.040, rz: 0.040 },
        { y: -0.410, rx: 0.034, rz: 0.034 }
    ], { sides: 6 });
    const cy = 0.880;
    const arcPts = [];
    const arcR = [];
    for (let i = 0; i <= 8; i++) {
        const a = (150 + (240 * i) / 8) * Math.PI / 180;
        arcPts.push([Math.cos(a) * 0.180, cy + Math.sin(a) * 0.180, 0]);
        const t = Math.sin((i / 8) * Math.PI);
        arcR.push(0.008 + t * 0.030);
    }
    const crescent = tubeMesh(arcPts, arcR, 5);
    const spike = sculptLoft([
        { y: 0.690, rx: 0.030, rz: 0.030 },
        { y: 0.720, rx: 0.020, rz: 0.020 }
    ], { sides: 6 });
    const gold = bakeVertexAO(mergeMeshes([collar, butt, crescent, spike]), { strength: 0.12, verticalGradient: 0.06 });
    const orb = sculptLoft([
        { y: cy - 0.092, rx: 0.020, rz: 0.020 },
        { y: cy - 0.062, rx: 0.072, rz: 0.072 },
        { y: cy, rx: 0.094, rz: 0.094 },
        { y: cy + 0.062, rx: 0.072, rz: 0.072 },
        { y: cy + 0.092, rx: 0.020, rz: 0.020 }
    ], { sides: 8, aoStrength: 0.10, aoGradient: 0.04 });
    const ringPts = [];
    for (let i = 0; i <= 14; i++) {
        const a = (i / 14) * Math.PI * 2;
        ringPts.push([Math.cos(a) * 0.118, cy + Math.sin(a) * 0.118, 0.012]);
    }
    const ring = tubeMesh(ringPts, 0.016, 4);
    cachedEclipseScepter = { shaft, grip, gold, orb, ring };
    return cachedEclipseScepter;
}
let cachedEquipWeapons;
function getEquipmentWeaponMeshes() {
    if (cachedEquipWeapons)
        return cachedEquipWeapons;
    // --- A. Iron Broadsword (heavy riveted Vanguard arming sword) ---
    const ironGrip = sculptLoft([
        { y: -0.092, rx: 0.025, rz: 0.031 },
        { y: 0.000, rx: 0.028, rz: 0.035 },
        { y: 0.092, rx: 0.026, rz: 0.032 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.08 });
    const ironPommel = bakeVertexAO(transformMesh(bevelBox(0.24), [0, -0.128, 0], [0, Math.PI * 0.25, 0], [0.068, 0.068, 0.072]), { strength: 0.15, verticalGradient: 0.08 });
    const ironGuard = mergeMeshes([
        extrudeYZ([
            [-0.168, 0.105], [-0.158, 0.145], [-0.056, 0.140], [0, 0.162],
            [0.056, 0.140], [0.158, 0.145], [0.168, 0.105], [0.072, 0.086],
            [-0.072, 0.086]
        ], 0.060, 0.16),
        transformMesh(octahedron, [0, 0.124, 0.135], ZERO_ROT, [0.032, 0.024, 0.024]),
        transformMesh(octahedron, [0, 0.124, -0.135], ZERO_ROT, [0.032, 0.024, 0.024])
    ]);
    const ironBlade = extrudeYZ([
        [-0.074, 0.148], [-0.070, 0.560], [-0.054, 0.720], [0, 0.845],
        [0.054, 0.720], [0.070, 0.560], [0.074, 0.148]
    ], 0.034, 0.16);
    const ironEdge = diamondBladeLoft([
        [0.152, 0.022, 0.080],
        [0.560, 0.020, 0.076],
        [0.720, 0.016, 0.060],
        [0.855, 0.004, 0.005]
    ], 0.10);
    // --- B. Yew Longbow + Hunting Arrow ---
    const yewBowLimbs = bakeVertexAO(tubeMesh([
        [0, -0.42, -0.120],
        [0, -0.28, -0.028],
        [0, -0.14, 0.018],
        [0, 0.00, 0.022],
        [0, 0.14, 0.018],
        [0, 0.30, -0.028],
        [0, 0.46, -0.120]
    ], [0.020, 0.027, 0.033, 0.034, 0.033, 0.027, 0.020], 6), { strength: 0.16, verticalGradient: 0.08 });
    const yewBowGrip = bakeVertexAO(mergeMeshes([
        sculptLoft([
            { y: -0.095, rx: 0.037, rz: 0.041, zOffset: 0.020 },
            { y: 0.000, rx: 0.040, rz: 0.044, zOffset: 0.022 },
            { y: 0.095, rx: 0.037, rz: 0.041, zOffset: 0.020 }
        ], { sides: 6 }),
        // Upper and lower emerald leather limb bindings
        sculptLoft([
            { y: 0.220, rx: 0.035, rz: 0.035, zOffset: -0.008 },
            { y: 0.265, rx: 0.034, rz: 0.034, zOffset: -0.018 }
        ], { sides: 6 }),
        sculptLoft([
            { y: -0.265, rx: 0.034, rz: 0.034, zOffset: -0.018 },
            { y: -0.220, rx: 0.035, rz: 0.035, zOffset: -0.008 }
        ], { sides: 6 })
    ]), { strength: 0.15, verticalGradient: 0.08 });
    const yewBowTips = bakeVertexAO(mergeMeshes([
        tubeMesh([[0, 0.44, -0.108], [0, 0.515, -0.146], [0, 0.575, -0.096]], [0.024, 0.019, 0.010], 6),
        tubeMesh([[0, -0.40, -0.108], [0, -0.470, -0.142], [0, -0.515, -0.096]], [0.024, 0.019, 0.010], 6)
    ]), { strength: 0.14, verticalGradient: 0.06 });
    const yewBowString = tubeMesh([[0, -0.495, -0.115], [0, 0.550, -0.115]], [0.008, 0.008], 4);
    const yewArrowShaft = sculptLoft([
        { y: -0.24, rx: 0.018, rz: 0.018 },
        { y: 0.48, rx: 0.018, rz: 0.018 }
    ], { sides: 6, aoStrength: 0.14, aoGradient: 0.06 });
    const yewVane = extrudeMesh([
        [0.014, -0.252], [0.096, -0.270], [0.088, -0.098], [0.014, -0.052]
    ], 0.015);
    const yewArrowFletch = bakeVertexAO(mergeMeshes([
        transformMesh(yewVane, [0, 0, 0], [0, 0, 0]),
        transformMesh(yewVane, [0, 0, 0], [0, (Math.PI * 2) / 3, 0]),
        transformMesh(yewVane, [0, 0, 0], [0, (Math.PI * 4) / 3, 0])
    ]), { strength: 0.12, verticalGradient: 0.06 });
    const yewArrowHead = diamondBladeLoft([
        [0.455, 0.024, 0.062],
        [0.495, 0.030, 0.078],
        [0.675, 0.004, 0.004]
    ], 0.14);
    // --- C. Ember Scepter (brazier scepter cradling a blazing flame core) ---
    const emberShaft = sculptLoft([
        { y: -0.34, rx: 0.024, rz: 0.024 },
        { y: -0.06, rx: 0.028, rz: 0.028 },
        { y: 0.30, rx: 0.032, rz: 0.032 },
        { y: 0.52, rx: 0.044, rz: 0.044 }
    ], { sides: 6, aoStrength: 0.18, aoGradient: 0.10 });
    const emberGrip = sculptLoft([
        { y: -0.092, rx: 0.034, rz: 0.034 },
        { y: 0.000, rx: 0.037, rz: 0.037 },
        { y: 0.092, rx: 0.034, rz: 0.034 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.08 });
    const brazierProng = tubeMesh([
        [0.046, 0.55, 0],
        [0.124, 0.64, 0],
        [0.132, 0.77, 0],
        [0.092, 0.87, 0]
    ], [0.024, 0.022, 0.017, 0.010], 5);
    const emberBrazier = bakeVertexAO(mergeMeshes([
        // Butt bronze cap
        sculptLoft([
            { y: -0.395, rx: 0.014, rz: 0.014 },
            { y: -0.340, rx: 0.036, rz: 0.036 },
            { y: -0.305, rx: 0.030, rz: 0.030 }
        ], { sides: 6 }),
        // Flared brazier bowl
        sculptLoft([
            { y: 0.49, rx: 0.046, rz: 0.046 },
            { y: 0.56, rx: 0.088, rz: 0.088 },
            { y: 0.62, rx: 0.072, rz: 0.072 }
        ], { sides: 8 }),
        // 4 curved bronze flame-cage ribs
        brazierProng,
        transformMesh(brazierProng, [0, 0, 0], [0, Math.PI * 0.5, 0]),
        transformMesh(brazierProng, [0, 0, 0], [0, Math.PI, 0]),
        transformMesh(brazierProng, [0, 0, 0], [0, Math.PI * 1.5, 0]),
        // Mid-cage decorative ring
        transformMesh(ringTube(0.118, 0.014, 10, 4), [0, 0.69, 0])
    ]), { strength: 0.16, verticalGradient: 0.08 });
    const emberFlame = sculptLoft([
        { y: 0.60, rx: 0.028, rz: 0.028 },
        { y: 0.70, rx: 0.082, rz: 0.082 },
        { y: 0.82, rx: 0.056, rz: 0.056, zOffset: 0.010 },
        { y: 0.96, rx: 0.008, rz: 0.008, zOffset: 0.016 }
    ], { sides: 6, aoStrength: 0.04, aoGradient: 0.02 });
    const emberSpark = mergeMeshes([
        transformMesh(octahedron, [0, 1.03, 0.010], [0, Math.PI * 0.25, 0], [0.038, 0.056, 0.038]),
        transformMesh(octahedron, [0.088, 0.90, 0], ZERO_ROT, [0.022, 0.030, 0.022]),
        transformMesh(octahedron, [-0.084, 0.88, 0.02], ZERO_ROT, [0.020, 0.028, 0.020])
    ]);
    // --- D. Sunsteel Blade (gleaming crescent-guard solar longsword) ---
    const sunsteelGrip = sculptLoft([
        { y: -0.095, rx: 0.026, rz: 0.031 },
        { y: 0.000, rx: 0.029, rz: 0.035 },
        { y: 0.095, rx: 0.027, rz: 0.032 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.08 });
    const sunsteelGuard = mergeMeshes([
        // Ring pommel
        transformMesh(ringTube(0.042, 0.016, 10, 5), [0, -0.148, 0], [0, 0, Math.PI * 0.5]),
        // Sweeping crescent sunburst crossguard
        extrudeYZ([
            [-0.215, 0.200], [-0.162, 0.124], [-0.068, 0.092], [0.068, 0.092],
            [0.162, 0.124], [0.215, 0.200], [0.152, 0.184], [0.072, 0.148],
            [0, 0.186], [-0.072, 0.148], [-0.152, 0.184]
        ], 0.062, 0.16)
    ]);
    const sunsteelBlade = diamondBladeLoft([
        [0.162, 0.030, 0.082],
        [0.480, 0.027, 0.076],
        [0.730, 0.022, 0.064],
        [0.910, 0.004, 0.005]
    ], 0.14);
    const sunsteelRails = mergeMeshes([
        sculptLoft([
            { y: 0.180, rx: 0.036, rz: 0.018, zOffset: 0.028 },
            { y: 0.650, rx: 0.030, rz: 0.014, zOffset: 0.022 },
            { y: 0.720, rx: 0.012, rz: 0.006, zOffset: 0.014 }
        ], { sides: 4, aoStrength: 0.08 }),
        sculptLoft([
            { y: 0.180, rx: 0.036, rz: 0.018, zOffset: -0.028 },
            { y: 0.650, rx: 0.030, rz: 0.014, zOffset: -0.022 },
            { y: 0.720, rx: 0.012, rz: 0.006, zOffset: -0.014 }
        ], { sides: 4, aoStrength: 0.08 })
    ]);
    const sunsteelGem = transformMesh(octahedron, [0, 0.136, 0], ZERO_ROT, [0.048, 0.056, 0.056]);
    // --- E. Frostbite Staff (twin curling glacial crescent horns + hovering ice star) ---
    const frostbiteShaft = bakeVertexAO(mergeMeshes([
        sculptLoft([
            { y: -0.405, rx: 0.016, rz: 0.016 },
            { y: -0.335, rx: 0.032, rz: 0.032 },
            { y: 0.280, rx: 0.031, rz: 0.031 },
            { y: 0.590, rx: 0.044, rz: 0.044 }
        ], { sides: 6 }),
        sculptLoft([
            { y: 0.56, rx: 0.058, rz: 0.058 },
            { y: 0.62, rx: 0.074, rz: 0.074 },
            { y: 0.67, rx: 0.052, rz: 0.052 }
        ], { sides: 6 })
    ]), { strength: 0.16, verticalGradient: 0.10 });
    const frostbiteGrip = sculptLoft([
        { y: -0.095, rx: 0.036, rz: 0.036 },
        { y: 0.000, rx: 0.039, rz: 0.039 },
        { y: 0.095, rx: 0.036, rz: 0.036 }
    ], { sides: 6, aoStrength: 0.14, aoGradient: 0.08 });
    const frostHornL = tubeMesh([
        [0, 0.63, 0.040],
        [0, 0.72, 0.148],
        [0, 0.88, 0.188],
        [0, 1.04, 0.132],
        [0, 1.12, 0.046]
    ], [0.030, 0.028, 0.024, 0.018, 0.008], 5);
    const frostHornR = tubeMesh([
        [0, 0.63, -0.040],
        [0, 0.72, -0.148],
        [0, 0.88, -0.188],
        [0, 1.04, -0.132],
        [0, 1.12, -0.046]
    ], [0.030, 0.028, 0.024, 0.018, 0.008], 5);
    const frostbiteHorns = bakeVertexAO(mergeMeshes([frostHornL, frostHornR]), { strength: 0.14, verticalGradient: 0.08 });
    const icicleTooth = sculptLoft([
        { y: 0.44, rx: 0.005, rz: 0.005 },
        { y: 0.56, rx: 0.022, rz: 0.022 },
        { y: 0.62, rx: 0.026, rz: 0.026 }
    ], { sides: 5 });
    const frostbiteIcicles = bakeVertexAO(mergeMeshes([
        transformMesh(icicleTooth, [0.056, 0, 0]),
        transformMesh(icicleTooth, [-0.056, 0, 0]),
        transformMesh(icicleTooth, [0, 0, 0.056]),
        transformMesh(icicleTooth, [0, 0, -0.056])
    ]), { strength: 0.12, verticalGradient: 0.06 });
    const frostbiteStar = mergeMeshes([
        transformMesh(octahedron, [0, 0.88, 0], ZERO_ROT, [0.064, 0.134, 0.064]),
        transformMesh(octahedron, [0, 0.88, 0], ZERO_ROT, [0.064, 0.042, 0.130]),
        transformMesh(octahedron, [0, 0.88, 0], ZERO_ROT, [0.112, 0.042, 0.042])
    ]);
    // --- F. Dragonfang Halberd (long polearm with axe blade, rear dragonfang beak & spear spike) ---
    const halberdHaft = sculptLoft([
        { y: -0.39, rx: 0.028, rz: 0.028 },
        { y: 0.15, rx: 0.031, rz: 0.031 },
        { y: 0.72, rx: 0.034, rz: 0.034 }
    ], { sides: 6, aoStrength: 0.18, aoGradient: 0.10 });
    const halberdWrap = bakeVertexAO(mergeMeshes([
        sculptLoft([
            { y: -0.095, rx: 0.037, rz: 0.037 },
            { y: 0.000, rx: 0.040, rz: 0.040 },
            { y: 0.095, rx: 0.037, rz: 0.037 }
        ], { sides: 6 }),
        sculptLoft([
            { y: 0.36, rx: 0.038, rz: 0.038 },
            { y: 0.44, rx: 0.040, rz: 0.040 }
        ], { sides: 6 })
    ]), { strength: 0.16, verticalGradient: 0.08 });
    const halberdCollar = bakeVertexAO(mergeMeshes([
        // Butt counterweight spike
        sculptLoft([
            { y: -0.415, rx: 0.010, rz: 0.010 },
            { y: -0.375, rx: 0.038, rz: 0.038 },
            { y: -0.340, rx: 0.034, rz: 0.034 }
        ], { sides: 6 }),
        // Ornate halberd head socket
        transformMesh(bevelBox(0.16), [0, 0.675, 0], ZERO_ROT, [0.088, 0.245, 0.112]),
        // Neck collar ring
        sculptLoft([
            { y: 0.51, rx: 0.048, rz: 0.048 },
            { y: 0.55, rx: 0.056, rz: 0.056 }
        ], { sides: 6 })
    ]), { strength: 0.16, verticalGradient: 0.08 });
    // Sweeping curved halberd axe-blade (+Z) + wicked hooked dragonfang rear beak (-Z) + spearhead (+Y)
    const halberdBlade = mergeMeshes([
        extrudeYZ([
            [0.044, 0.565], [0.195, 0.475], [0.295, 0.540], [0.315, 0.680],
            [0.265, 0.825], [0.155, 0.840], [0.044, 0.765]
        ], 0.044, 0.16),
        extrudeYZ([
            [-0.044, 0.625], [-0.155, 0.605], [-0.255, 0.555], [-0.220, 0.675],
            [-0.140, 0.755], [-0.044, 0.745]
        ], 0.040, 0.16),
        diamondBladeLoft([
            [0.765, 0.028, 0.068],
            [0.900, 0.022, 0.054],
            [1.120, 0.004, 0.005]
        ], 0.14)
    ]);
    const halberdEdge = mergeMeshes([
        extrudeYZ([
            [0.245, 0.505], [0.308, 0.542], [0.334, 0.680], [0.282, 0.834],
            [0.235, 0.818], [0.286, 0.680], [0.270, 0.556]
        ], 0.024, 0.08),
        extrudeYZ([
            [-0.195, 0.585], [-0.272, 0.542], [-0.232, 0.680], [-0.185, 0.670]
        ], 0.022, 0.08)
    ]);
    const halberdGem = mergeMeshes([
        transformMesh(octahedron, [0, 0.680, 0], ZERO_ROT, [0.066, 0.082, 0.072]),
        transformMesh(octahedron, [0, 0.835, 0], ZERO_ROT, [0.036, 0.056, 0.036])
    ]);
    // --- G. Solis Crownblade (mythic sovereign greatsword with 3-prong crown guard & blazing split blade) ---
    const crownGrip = sculptLoft([
        { y: -0.118, rx: 0.028, rz: 0.034 },
        { y: 0.000, rx: 0.031, rz: 0.038 },
        { y: 0.118, rx: 0.029, rz: 0.035 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.08 });
    const crownGuard = mergeMeshes([
        // Crown pommel
        sculptLoft([
            { y: -0.205, rx: 0.014, rz: 0.016 },
            { y: -0.162, rx: 0.060, rz: 0.066 },
            { y: -0.114, rx: 0.036, rz: 0.040 }
        ], { sides: 6, aoStrength: 0.14 }),
        // Grand three-pronged solar crown crossguard
        extrudeYZ([
            [-0.285, 0.285], [-0.220, 0.300], [-0.140, 0.210], [-0.095, 0.268],
            [0, 0.228], [0.095, 0.268], [0.140, 0.210], [0.220, 0.300],
            [0.285, 0.285], [0.205, 0.140], [0.078, 0.102], [-0.078, 0.102], [-0.205, 0.140]
        ], 0.074, 0.16)
    ]);
    // Swept golden wing flanges rising along the lower blade
    const crownWings = mergeMeshes([
        extrudeYZ([
            [0.085, 0.220], [0.175, 0.340], [0.145, 0.455], [0.088, 0.365]
        ], 0.044, 0.12),
        extrudeYZ([
            [-0.085, 0.220], [-0.175, 0.340], [-0.145, 0.455], [-0.088, 0.365]
        ], 0.044, 0.12)
    ]);
    const crownBlade = diamondBladeLoft([
        [0.195, 0.034, 0.112],
        [0.440, 0.034, 0.106],
        [0.820, 0.028, 0.094],
        [1.060, 0.005, 0.006]
    ], 0.14);
    const crownCore = mergeMeshes([
        diamondBladeLoft([
            [0.220, 0.044, 0.048],
            [0.835, 0.038, 0.038],
            [0.980, 0.010, 0.008]
        ], 0),
        transformMesh(octahedron, [0, 0.42, 0], ZERO_ROT, [0.052, 0.068, 0.058]),
        transformMesh(octahedron, [0, 0.66, 0], ZERO_ROT, [0.048, 0.062, 0.052])
    ]);
    const crownJewel = mergeMeshes([
        transformMesh(octahedron, [0, 0.168, 0], ZERO_ROT, [0.064, 0.076, 0.074]),
        transformMesh(octahedron, [0, -0.162, 0], ZERO_ROT, [0.042, 0.046, 0.046])
    ]);
    // --- H. Aegis of Dawn Shield (radiant golden sunburst tower shield) ---
    const aegisOuterPoly = [
        [0, -0.345], [0.155, -0.258], [0.225, -0.085], [0.236, 0.225],
        [0.158, 0.318], [0, 0.352], [-0.158, 0.318], [-0.236, 0.225],
        [-0.225, -0.085], [-0.155, -0.258]
    ];
    const aegisInnerPoly = [
        [0, -0.288], [0.122, -0.212], [0.180, -0.068], [0.188, 0.186],
        [0.124, 0.264], [0, 0.292], [-0.124, 0.264], [-0.188, 0.186],
        [-0.180, -0.068], [-0.122, -0.212]
    ];
    const aegisRim = bakeVertexAO(transformMesh(extrudeMesh(aegisOuterPoly, 0.050), [0, 0.055, 0.092]), { strength: 0.16, verticalGradient: 0.10 });
    const aegisField = bakeVertexAO(transformMesh(extrudeMesh(aegisInnerPoly, 0.026), [0, 0.055, 0.112]), { strength: 0.12, verticalGradient: 0.06 });
    const raySpike = extrudeMesh([[0.036, -0.018], [0.152, 0], [0.036, 0.018]], 0.022);
    const rayParts = [];
    for (let i = 0; i < 8; i++) {
        rayParts.push(transformMesh(raySpike, [0, 0.068, 0.132], [0, 0, (i / 8) * Math.PI * 2]));
    }
    const aegisRays = bakeVertexAO(mergeMeshes(rayParts), { strength: 0.10, verticalGradient: 0.04 });
    const aegisCore = transformMesh(octahedron, [0, 0.068, 0.148], ZERO_ROT, [0.058, 0.066, 0.032]);
    cachedEquipWeapons = {
        ironGrip,
        ironPommel,
        ironGuard,
        ironBlade,
        ironEdge,
        yewBowLimbs,
        yewBowGrip,
        yewBowTips,
        yewBowString,
        yewArrowShaft,
        yewArrowFletch,
        yewArrowHead,
        emberShaft,
        emberGrip,
        emberBrazier,
        emberFlame,
        emberSpark,
        sunsteelGrip,
        sunsteelGuard,
        sunsteelBlade,
        sunsteelRails,
        sunsteelGem,
        frostbiteShaft,
        frostbiteGrip,
        frostbiteHorns,
        frostbiteIcicles,
        frostbiteStar,
        halberdHaft,
        halberdWrap,
        halberdCollar,
        halberdBlade,
        halberdEdge,
        halberdGem,
        crownGrip,
        crownGuard,
        crownWings,
        crownBlade,
        crownCore,
        crownJewel,
        aegisRim,
        aegisField,
        aegisRays,
        aegisCore
    };
    return cachedEquipWeapons;
}
/**
 * Register all Crownshard main-hand weapons (18) and off-hand shields & relics (10)
 * onto a Ridgetop `CharacterBuilder`.
 */
export function registerCrownshardWeapons(builder) {
    // =========================================================================
    // MAIN HAND (`mainHand`) — 11 Weapons
    // =========================================================================
    builder.registerPart('mainHand', 'weapon_broadsword', (palette) => {
        const m = getWeaponMeshes();
        const steel = mixColor(palette.metal, C_BRIGHT_STEEL, 0.35);
        const gold = mixColor(palette.accent, C_SUN_GOLD, 0.45);
        return orientParts([
            { name: 'broadsword_grip', mesh: m.broadswordGrip, color: palette.leather },
            { name: 'broadsword_pommel', mesh: m.broadswordPommel, color: gold },
            { name: 'broadsword_guard', mesh: m.broadswordGuard, color: gold },
            { name: 'broadsword_blade', mesh: m.broadswordBlade, color: steel },
            { name: 'broadsword_fuller', mesh: m.broadswordFuller, color: palette.metalDark }
        ], [1.06, 0.10, -0.08]);
    });
    builder.registerPart('mainHand', 'weapon_sunblade', (palette) => {
        const m = getWeaponMeshes();
        const gildedSteel = mixColor(palette.metal, [0.97, 0.92, 0.78, 1], 0.45);
        const gripCrimson = mixColor(palette.leather, C_CRIMSON_DARK, 0.55);
        return orientParts([
            { name: 'sunblade_grip', mesh: m.sunbladeGrip, color: gripCrimson },
            { name: 'sunblade_pommel', mesh: m.sunbladePommel, color: C_SUN_GOLD },
            { name: 'sunblade_guard', mesh: m.sunbladeGuard, color: C_SUN_GOLD },
            { name: 'sunblade_gem', mesh: m.sunbladeGem, color: C_SUN_GLOW, unlit: 0.92 },
            { name: 'sunblade_blade', mesh: m.sunbladeBlade, color: gildedSteel },
            { name: 'sunblade_core', mesh: m.sunbladeCore, color: C_SUN_GLOW, unlit: 0.94 }
        ], [0.88, 0.12, -0.10]);
    });
    builder.registerPart('mainHand', 'weapon_arrow_nocked', (palette) => {
        const m = getWeaponMeshes();
        const fletch = mixColor(palette.accent, [0.95, 0.32, 0.24, 1], 0.45);
        const steel = mixColor(palette.metal, C_BRIGHT_STEEL, 0.40);
        return orientParts([
            { name: 'arrow_shaft', mesh: m.arrowShaft, color: palette.leatherLight },
            { name: 'arrow_nock', mesh: m.arrowNock, color: C_HORN_IVORY },
            { name: 'arrow_fletching', mesh: m.arrowFletching, color: fletch },
            { name: 'arrow_head', mesh: m.arrowHead, color: steel }
        ], [1.22, 0.14, -0.06]);
    });
    builder.registerPart('mainHand', 'weapon_staff_arcane', (palette) => {
        const m = getWeaponMeshes();
        const wood = mixColor(palette.leather, C_DARK_WOOD, 0.35);
        const gold = mixColor(palette.accent, C_SUN_GOLD, 0.45);
        const cyan = mixColor(palette.glow, C_ARCANE_CYAN, 0.65);
        return orientParts([
            { name: 'staff_arcane_shaft', mesh: m.staffArcaneShaft, color: wood },
            { name: 'staff_arcane_grip', mesh: m.staffArcaneGrip, color: palette.leatherLight },
            { name: 'staff_arcane_gold', mesh: m.staffArcaneGold, color: gold },
            { name: 'staff_arcane_crystal', mesh: m.staffArcaneCrystal, color: cyan, unlit: 0.95 }
        ], [0.20, 0.04, -0.06]);
    });
    builder.registerPart('mainHand', 'weapon_staff_frost', (palette) => {
        const m = getWeaponMeshes();
        const shaft = mixColor(palette.metalDark, C_FROST_SHAFT, 0.60);
        return orientParts([
            { name: 'staff_frost_shaft', mesh: m.staffFrostShaft, color: shaft },
            { name: 'staff_frost_grip', mesh: m.staffFrostGrip, color: palette.leather },
            { name: 'staff_frost_spires', mesh: m.staffFrostSpires, color: C_FROST_ICE, unlit: 0.28 },
            { name: 'staff_frost_diamond', mesh: m.staffFrostDiamond, color: C_FROST_GLOW, unlit: 0.96 }
        ], [0.20, 0.04, -0.06]);
    });
    builder.registerPart('mainHand', 'weapon_mace_sun', (palette) => {
        const m = getWeaponMeshes();
        const gold = mixColor(palette.accent, C_SUN_GOLD, 0.60);
        return orientParts([
            { name: 'mace_sun_grip', mesh: m.maceGrip, color: palette.leather },
            { name: 'mace_sun_shaft', mesh: m.maceShaft, color: palette.metalDark },
            { name: 'mace_sun_head', mesh: m.maceHeadGold, color: gold },
            { name: 'mace_sun_core', mesh: m.maceCore, color: C_SUN_GLOW, unlit: 0.95 }
        ], [0.92, 0.10, -0.08]);
    });
    builder.registerPart('mainHand', 'weapon_dagger', (palette) => {
        const m = getWeaponMeshes();
        const darkBlade = mixColor(palette.metalDark, C_DARK_STEEL, 0.65);
        const brightEdge = mixColor(palette.metal, C_BRIGHT_STEEL, 0.42);
        return orientParts([
            { name: 'dagger_grip', mesh: m.daggerGrip, color: C_CRIMSON },
            { name: 'dagger_guard', mesh: m.daggerGuard, color: C_CRIMSON_DARK },
            { name: 'dagger_blade', mesh: m.daggerBlade, color: darkBlade },
            { name: 'dagger_edge', mesh: m.daggerEdge, color: brightEdge }
        ], [0.98, 0.16, -0.08]);
    });
    builder.registerPart('mainHand', 'weapon_greataxe', (palette) => {
        const m = getWeaponMeshes();
        const wood = mixColor(palette.leather, C_DARK_WOOD, 0.40);
        const darkIron = shadeColor(palette.metalDark, -0.06);
        const brightEdge = mixColor(palette.metal, C_BRIGHT_STEEL, 0.55);
        return orientParts([
            { name: 'greataxe_haft', mesh: m.axeHaft, color: wood },
            { name: 'greataxe_wrap', mesh: m.axeWrap, color: palette.leatherLight },
            { name: 'greataxe_collar', mesh: m.axeCollar, color: darkIron },
            { name: 'greataxe_blades', mesh: m.axeBlades, color: palette.metalDark },
            { name: 'greataxe_edges', mesh: m.axeEdges, color: brightEdge },
            { name: 'greataxe_rivets', mesh: m.axeRivets, color: C_BRIGHT_STEEL }
        ], [0.76, 0.10, -0.10]);
    });
    builder.registerPart('mainHand', 'weapon_scythe_bone', (palette) => {
        const m = getWeaponMeshes();
        const darkIron = shadeColor(palette.metalDark, -0.08);
        const edgeSilver = mixColor(palette.metal, C_BRIGHT_STEEL, 0.55);
        return orientParts([
            { name: 'scythe_shaft', mesh: m.scytheShaft, color: C_BONE },
            { name: 'scythe_wrap', mesh: m.scytheWrap, color: palette.leather },
            { name: 'scythe_collar', mesh: m.scytheCollar, color: C_BONE_SHADE },
            { name: 'scythe_blade', mesh: m.scytheBlade, color: darkIron },
            { name: 'scythe_edge', mesh: m.scytheEdge, color: edgeSilver }
        ], [0.16, 0.18, -0.10]);
    });
    builder.registerPart('mainHand', 'weapon_goblin_cleaver', (palette) => {
        const m = getWeaponMeshes();
        const edgeSteel = mixColor(palette.metal, C_BRIGHT_STEEL, 0.35);
        return orientParts([
            { name: 'cleaver_grip', mesh: m.cleaverGrip, color: palette.leather },
            { name: 'cleaver_guard', mesh: m.cleaverGuard, color: C_GOBLIN_RUST },
            { name: 'cleaver_blade', mesh: m.cleaverBlade, color: C_GOBLIN_IRON },
            { name: 'cleaver_edge', mesh: m.cleaverEdge, color: edgeSteel },
            { name: 'cleaver_rivets', mesh: m.cleaverRivets, color: C_BRIGHT_STEEL }
        ], [0.98, 0.12, -0.08]);
    });
    builder.registerPart('mainHand', 'weapon_obsidian_greatsword', (palette) => {
        const m = getWeaponMeshes();
        const darkGrip = mixColor(palette.leather, C_OBSIDIAN, 0.55);
        const blade = mixColor(C_OBSIDIAN, palette.metalDark, 0.35);
        const guard = mixColor(C_OBSIDIAN_EDGE, palette.accent, 0.35);
        const edges = mixColor(C_OBSIDIAN_EDGE, palette.metal, 0.45);
        const runes = mixColor(palette.glow, C_VIOLET_GLOW, 0.30);
        return orientParts([
            { name: 'obsidian_sword_grip', mesh: m.obsidianGrip, color: darkGrip },
            { name: 'obsidian_sword_guard', mesh: m.obsidianGuard, color: guard },
            { name: 'obsidian_sword_blade', mesh: m.obsidianBlade, color: blade },
            { name: 'obsidian_sword_edges', mesh: m.obsidianEdges, color: edges },
            { name: 'obsidian_sword_runes', mesh: m.obsidianRunes, color: runes, unlit: 0.96 }
        ], [0.86, 0.12, -0.10]);
    });
    builder.registerPart('mainHand', 'weapon_eclipse_scepter', (palette) => {
        const m = getEclipseScepterMeshes();
        const shaft = mixColor(palette.metalDark, palette.primary, 0.35);
        const gold = mixColor(palette.accent, C_SUN_GOLD, 0.50);
        const orb = mixColor(palette.metalDark, [0.10, 0.06, 0.16, 1], 0.55);
        return orientParts([
            { name: 'eclipse_scepter_shaft', mesh: m.shaft, color: shaft },
            { name: 'eclipse_scepter_grip', mesh: m.grip, color: palette.leather },
            { name: 'eclipse_scepter_gold', mesh: m.gold, color: gold },
            { name: 'eclipse_scepter_orb', mesh: m.orb, color: orb },
            { name: 'eclipse_scepter_ring', mesh: m.ring, color: palette.glow, unlit: 0.96 }
        ], [0.20, 0.04, -0.06]);
    });
    // =========================================================================
    // OFF HAND (`offHand`) — 8 Shields & Relics
    // =========================================================================
    builder.registerPart('offHand', 'shield_heater', (palette) => {
        const m = getWeaponMeshes();
        const gold = mixColor(palette.accent, C_SUN_GOLD, 0.45);
        return orientParts([
            { name: 'shield_heater_grip', mesh: m.shieldGrip, color: palette.leather },
            { name: 'shield_heater_rim', mesh: m.heaterRim, color: gold },
            { name: 'shield_heater_field', mesh: m.heaterField, color: palette.primary },
            { name: 'shield_heater_crest', mesh: m.heaterCrest, color: shadeColor(gold, 0.06) }
        ], [-0.06, -0.82, 0.04]);
    });
    builder.registerPart('offHand', 'shield_tower_paladin', (palette) => {
        const m = getWeaponMeshes();
        const gold = mixColor(palette.accent, C_SUN_GOLD, 0.65);
        return orientParts([
            { name: 'shield_paladin_grip', mesh: m.shieldGrip, color: palette.leather },
            { name: 'shield_paladin_rim', mesh: m.paladinRim, color: gold },
            { name: 'shield_paladin_cobalt', mesh: m.paladinCobalt, color: C_PALADIN_COBALT },
            { name: 'shield_paladin_ivory', mesh: m.paladinIvory, color: C_PALADIN_IVORY },
            { name: 'shield_paladin_cross', mesh: m.paladinCross, color: C_SUN_GOLD },
            { name: 'shield_paladin_gem', mesh: m.paladinGem, color: C_SUN_GLOW, unlit: 0.92 }
        ], [-0.05, -0.82, 0.04]);
    });
    builder.registerPart('offHand', 'shield_buckler', (palette) => {
        const m = getWeaponMeshes();
        const iron = mixColor(palette.metalDark, C_DARK_STEEL, 0.40);
        const steelBoss = mixColor(palette.metal, C_BRIGHT_STEEL, 0.35);
        return orientParts([
            { name: 'shield_buckler_grip', mesh: m.shieldGrip, color: palette.leather },
            { name: 'shield_buckler_rim', mesh: m.bucklerRim, color: iron },
            { name: 'shield_buckler_wood', mesh: m.bucklerWood, color: palette.leatherLight },
            { name: 'shield_buckler_boss', mesh: m.bucklerBoss, color: steelBoss }
        ], [-0.04, -0.88, 0.04]);
    });
    builder.registerPart('offHand', 'shield_obsidian', (palette) => {
        const m = getWeaponMeshes();
        const field = mixColor(palette.primary, palette.metalDark, 0.35);
        const rim = mixColor(C_OBSIDIAN_EDGE, palette.metal, 0.45);
        const claws = mixColor(C_OBSIDIAN_EDGE, palette.accent, 0.55);
        const gem = mixColor(palette.glow, C_VIOLET_GLOW, 0.25);
        return orientParts([
            { name: 'shield_obsidian_grip', mesh: m.shieldGrip, color: palette.leather },
            { name: 'shield_obsidian_rim', mesh: m.obsidianShieldRim, color: rim },
            { name: 'shield_obsidian_field', mesh: m.obsidianShieldField, color: field },
            { name: 'shield_obsidian_claws', mesh: m.obsidianShieldClaws, color: claws },
            { name: 'shield_obsidian_gem', mesh: m.obsidianShieldGem, color: gem, unlit: 0.96 }
        ], [-0.05, -0.82, 0.04]);
    });
    builder.registerPart('offHand', 'offhand_bow_recurve', (palette) => {
        const m = getWeaponMeshes();
        const wood = mixColor(palette.leatherLight, C_BOW_WOOD, 0.55);
        return orientParts([
            { name: 'bow_recurve_limbs', mesh: m.bowLimbs, color: wood },
            { name: 'bow_recurve_grip', mesh: m.bowGrip, color: palette.leather },
            { name: 'bow_recurve_tips', mesh: m.bowTips, color: C_HORN_IVORY },
            { name: 'bow_recurve_string', mesh: m.bowString, color: C_PARCHMENT }
        ], [0.12, -0.22, 0.22], [-0.012, 0.010, 0.020]);
    });
    builder.registerPart('offHand', 'offhand_spell_orb', (palette) => {
        const m = getWeaponMeshes();
        const gold = mixColor(palette.accent, C_SUN_GOLD, 0.50);
        const cyan = mixColor(palette.glow, C_ARCANE_CYAN, 0.55);
        return orientParts([
            { name: 'spell_orb_crystal', mesh: m.orbCrystal, color: cyan, unlit: 0.96 },
            { name: 'spell_orb_ring', mesh: m.orbRing, color: gold },
            { name: 'spell_orb_shards', mesh: m.orbShards, color: C_SUN_GLOW, unlit: 0.88 }
        ], [0, 0, 0], [-0.024, 0.032, 0.108]);
    });
    builder.registerPart('offHand', 'offhand_tome', (palette) => {
        const m = getWeaponMeshes();
        const cover = mixColor(palette.leather, C_TOME_COVER, 0.65);
        const gold = mixColor(palette.accent, C_SUN_GOLD, 0.55);
        const sigil = mixColor(palette.glow, C_ARCANE_CYAN, 0.50);
        return orientParts([
            { name: 'tome_cover', mesh: m.tomeCover, color: cover },
            { name: 'tome_pages', mesh: m.tomePages, color: C_PARCHMENT },
            { name: 'tome_gold', mesh: m.tomeGold, color: gold },
            { name: 'tome_sigil', mesh: m.tomeSigil, color: sigil, unlit: 0.95 }
        ], [0.22, -0.62, 0.16], [-0.036, 0.012, 0.052]);
    });
    builder.registerPart('offHand', 'offhand_dagger', (palette) => {
        const m = getWeaponMeshes();
        const darkBlade = mixColor(palette.metalDark, C_DARK_STEEL, 0.65);
        const brightEdge = mixColor(palette.metal, C_BRIGHT_STEEL, 0.42);
        return orientParts([
            { name: 'offhand_dagger_grip', mesh: m.daggerGrip, color: C_CRIMSON },
            { name: 'offhand_dagger_guard', mesh: m.daggerGuard, color: C_CRIMSON_DARK },
            { name: 'offhand_dagger_blade', mesh: m.offDaggerBlade, color: darkBlade },
            { name: 'offhand_dagger_edge', mesh: m.offDaggerEdge, color: brightEdge }
        ], [0.98, -0.16, 0.08]);
    });
    // =========================================================================
    // BESPOKE EQUIPMENT WEAPONS & OFF-HANDS (1:1 for every EquipmentSpec weapon)
    // =========================================================================
    builder.registerPart('mainHand', 'weapon_iron_broadsword', (palette) => {
        const m = getEquipmentWeaponMeshes();
        const darkGrip = mixColor(palette.leather, C_DARK_WOOD, 0.55);
        return orientParts([
            { name: 'iron_sword_grip', mesh: m.ironGrip, color: darkGrip },
            { name: 'iron_sword_pommel', mesh: m.ironPommel, color: C_IRON_GUARD },
            { name: 'iron_sword_guard', mesh: m.ironGuard, color: C_IRON_GUARD },
            { name: 'iron_sword_blade', mesh: m.ironBlade, color: C_IRON_STEEL },
            { name: 'iron_sword_edge', mesh: m.ironEdge, color: C_BRIGHT_STEEL }
        ], [1.04, 0.10, -0.08]);
    });
    builder.registerPart('mainHand', 'weapon_yew_arrow', () => {
        const m = getEquipmentWeaponMeshes();
        return orientParts([
            { name: 'yew_arrow_shaft', mesh: m.yewArrowShaft, color: C_YEW_GOLD },
            { name: 'yew_arrow_fletch', mesh: m.yewArrowFletch, color: C_FOREST_GREEN },
            { name: 'yew_arrow_head', mesh: m.yewArrowHead, color: C_BRIGHT_STEEL }
        ], [1.22, 0.14, -0.06]);
    });
    builder.registerPart('offHand', 'offhand_bow_yew', () => {
        const m = getEquipmentWeaponMeshes();
        return orientParts([
            { name: 'yew_bow_limbs', mesh: m.yewBowLimbs, color: C_YEW_GOLD },
            { name: 'yew_bow_grip', mesh: m.yewBowGrip, color: C_FOREST_GREEN },
            { name: 'yew_bow_tips', mesh: m.yewBowTips, color: C_HORN_IVORY },
            { name: 'yew_bow_string', mesh: m.yewBowString, color: C_PARCHMENT }
        ], [0.12, -0.22, 0.22], [-0.012, 0.010, 0.020]);
    });
    builder.registerPart('mainHand', 'weapon_ember_scepter', (palette) => {
        const m = getEquipmentWeaponMeshes();
        const charredWood = mixColor(palette.leather, [0.22, 0.12, 0.10, 1], 0.65);
        return orientParts([
            { name: 'ember_scepter_shaft', mesh: m.emberShaft, color: charredWood },
            { name: 'ember_scepter_grip', mesh: m.emberGrip, color: C_CRIMSON_DARK },
            { name: 'ember_scepter_brazier', mesh: m.emberBrazier, color: C_BRONZE },
            { name: 'ember_scepter_flame', mesh: m.emberFlame, color: C_EMBER_CORE, unlit: 0.96 },
            { name: 'ember_scepter_spark', mesh: m.emberSpark, color: C_EMBER_TIP, unlit: 0.98 }
        ], [0.22, 0.06, -0.06]);
    });
    builder.registerPart('mainHand', 'weapon_sunsteel_blade', (palette) => {
        const m = getEquipmentWeaponMeshes();
        const sunSteel = mixColor(C_BRIGHT_STEEL, C_SUN_GLOW, 0.25);
        const grip = mixColor(palette.leather, C_CRIMSON, 0.35);
        return orientParts([
            { name: 'sunsteel_grip', mesh: m.sunsteelGrip, color: grip },
            { name: 'sunsteel_guard', mesh: m.sunsteelGuard, color: C_SUN_GOLD },
            { name: 'sunsteel_blade', mesh: m.sunsteelBlade, color: sunSteel },
            { name: 'sunsteel_rails', mesh: m.sunsteelRails, color: C_SUN_GOLD },
            { name: 'sunsteel_gem', mesh: m.sunsteelGem, color: C_SUN_GLOW, unlit: 0.92 }
        ], [0.96, 0.10, -0.08]);
    });
    builder.registerPart('mainHand', 'weapon_frostbite_staff', (palette) => {
        const m = getEquipmentWeaponMeshes();
        const shaft = mixColor(C_FROST_SHAFT, palette.metalDark, 0.35);
        return orientParts([
            { name: 'frostbite_shaft', mesh: m.frostbiteShaft, color: shaft },
            { name: 'frostbite_grip', mesh: m.frostbiteGrip, color: C_PALADIN_COBALT },
            { name: 'frostbite_horns', mesh: m.frostbiteHorns, color: C_FROST_ICE, unlit: 0.22 },
            { name: 'frostbite_icicles', mesh: m.frostbiteIcicles, color: C_BRIGHT_STEEL, unlit: 0.26 },
            { name: 'frostbite_star', mesh: m.frostbiteStar, color: C_FROST_GLOW, unlit: 0.96 }
        ], [0.18, 0.04, -0.06]);
    });
    builder.registerPart('mainHand', 'weapon_dragonfang_halberd', (palette) => {
        const m = getEquipmentWeaponMeshes();
        const haft = mixColor(C_DRAGON_DARK, palette.leather, 0.35);
        return orientParts([
            { name: 'dragonfang_haft', mesh: m.halberdHaft, color: haft },
            { name: 'dragonfang_wrap', mesh: m.halberdWrap, color: C_CRIMSON_DARK },
            { name: 'dragonfang_collar', mesh: m.halberdCollar, color: C_SUN_GOLD },
            { name: 'dragonfang_blade', mesh: m.halberdBlade, color: C_DRAGON_DARK },
            { name: 'dragonfang_edge', mesh: m.halberdEdge, color: C_BRIGHT_STEEL },
            { name: 'dragonfang_gem', mesh: m.halberdGem, color: C_DRAGON_AMETHYST, unlit: 0.96 }
        ], [0.34, 0.12, -0.08]);
    });
    builder.registerPart('mainHand', 'weapon_solis_crownblade', () => {
        const m = getEquipmentWeaponMeshes();
        return orientParts([
            { name: 'crownblade_grip', mesh: m.crownGrip, color: C_CRIMSON },
            { name: 'crownblade_guard', mesh: m.crownGuard, color: C_SUN_GOLD },
            { name: 'crownblade_wings', mesh: m.crownWings, color: shadeColor(C_SUN_GOLD, 0.12) },
            { name: 'crownblade_blade', mesh: m.crownBlade, color: C_PALADIN_IVORY },
            { name: 'crownblade_core', mesh: m.crownCore, color: C_SUN_GLOW, unlit: 0.98 },
            { name: 'crownblade_jewel', mesh: m.crownJewel, color: C_SUN_GLOW, unlit: 0.98 }
        ], [0.84, 0.12, -0.10]);
    });
    builder.registerPart('offHand', 'shield_aegis_dawn', (palette) => {
        const baseM = getWeaponMeshes();
        const m = getEquipmentWeaponMeshes();
        return orientParts([
            { name: 'shield_aegis_grip', mesh: baseM.shieldGrip, color: palette.leather },
            { name: 'shield_aegis_rim', mesh: m.aegisRim, color: C_SUN_GOLD },
            { name: 'shield_aegis_field', mesh: m.aegisField, color: C_PALADIN_IVORY },
            { name: 'shield_aegis_rays', mesh: m.aegisRays, color: shadeColor(C_SUN_GOLD, 0.10) },
            { name: 'shield_aegis_core', mesh: m.aegisCore, color: C_SUN_GLOW, unlit: 0.96 }
        ], [-0.05, -0.82, 0.04]);
    });
    // =========================================================================
    // CLASS-FAMILY ARSENAL WEAPONS (Arcane Staves & Skirmisher Bows)
    // =========================================================================
    builder.registerPart('mainHand', 'weapon_apprentice_staff', () => {
        const m = getClassFamilyWeaponMeshes();
        return orientParts([
            { name: 'apprentice_staff_shaft', mesh: m.apprenticeShaft, color: C_BOW_WOOD },
            { name: 'apprentice_staff_ferrule', mesh: m.apprenticeFerrule, color: C_BRONZE },
            { name: 'apprentice_staff_crystal', mesh: m.apprenticeCrystal, color: [0.46, 0.78, 0.98, 1], unlit: 0.88 }
        ], [0.20, 0.05, -0.06]);
    });
    builder.registerPart('mainHand', 'weapon_solis_archstaff', () => {
        const m = getClassFamilyWeaponMeshes();
        return orientParts([
            { name: 'archstaff_shaft', mesh: m.archstaffShaft, color: C_DRAGON_DARK },
            { name: 'archstaff_rings', mesh: m.archstaffRings, color: C_SUN_GOLD },
            { name: 'archstaff_prism', mesh: m.archstaffPrism, color: C_DRAGON_AMETHYST, unlit: 0.94 },
            { name: 'archstaff_core', mesh: m.archstaffCore, color: C_SUN_GLOW, unlit: 0.96 }
        ], [0.18, 0.05, -0.06]);
    });
    builder.registerPart('mainHand', 'weapon_celestial_staff', () => {
        const m = getClassFamilyWeaponMeshes();
        return orientParts([
            { name: 'celestial_shaft', mesh: m.celestialShaft, color: C_PALADIN_IVORY },
            { name: 'celestial_halo', mesh: m.celestialHalo, color: C_SUN_GOLD },
            { name: 'celestial_star', mesh: m.celestialStar, color: C_ARCANE_CYAN, unlit: 0.98 },
            { name: 'celestial_moons', mesh: m.celestialMoons, color: C_SUN_GLOW, unlit: 0.94 }
        ], [0.16, 0.04, -0.06]);
    });
    builder.registerPart('mainHand', 'weapon_falcon_arrow', () => {
        const m = getClassFamilyWeaponMeshes();
        return orientParts([
            { name: 'falcon_arrow_shaft', mesh: m.falconArrowShaft, color: C_BOW_WOOD },
            { name: 'falcon_arrow_fletch', mesh: m.falconArrowFletch, color: [0.34, 0.82, 0.56, 1] },
            { name: 'falcon_arrow_head', mesh: m.falconArrowHead, color: C_SUN_GOLD }
        ], [1.22, 0.14, -0.06]);
    });
    builder.registerPart('offHand', 'offhand_bow_falcon', () => {
        const m = getClassFamilyWeaponMeshes();
        return orientParts([
            { name: 'falcon_bow_limbs', mesh: m.falconBowLimbs, color: [0.24, 0.62, 0.42, 1] },
            { name: 'falcon_bow_grip', mesh: m.falconBowGrip, color: C_DARK_WOOD },
            { name: 'falcon_bow_tips', mesh: m.falconBowTips, color: C_SUN_GOLD },
            { name: 'falcon_bow_string', mesh: m.falconBowString, color: C_PARCHMENT }
        ], [0.12, -0.22, 0.22], [-0.012, 0.010, 0.020]);
    });
    builder.registerPart('mainHand', 'weapon_gale_arrow', () => {
        const m = getClassFamilyWeaponMeshes();
        return orientParts([
            { name: 'gale_arrow_shaft', mesh: m.galeArrowShaft, color: C_BRIGHT_STEEL },
            { name: 'gale_arrow_fletch', mesh: m.galeArrowFletch, color: C_ARCANE_CYAN, unlit: 0.72 },
            { name: 'gale_arrow_head', mesh: m.galeArrowHead, color: C_FROST_GLOW, unlit: 0.88 }
        ], [1.22, 0.14, -0.06]);
    });
    builder.registerPart('offHand', 'offhand_bow_gale', () => {
        const m = getClassFamilyWeaponMeshes();
        return orientParts([
            { name: 'gale_bow_limbs', mesh: m.galeBowLimbs, color: [0.26, 0.68, 0.88, 1] },
            { name: 'gale_bow_fins', mesh: m.galeBowFins, color: C_FROST_GLOW, unlit: 0.55 },
            { name: 'gale_bow_grip', mesh: m.galeBowGrip, color: C_PALADIN_COBALT },
            { name: 'gale_bow_string', mesh: m.galeBowString, color: C_ARCANE_CYAN, unlit: 0.80 }
        ], [0.12, -0.22, 0.22], [-0.012, 0.010, 0.020]);
    });
    builder.registerPart('mainHand', 'weapon_shadowfang_arrow', () => {
        const m = getClassFamilyWeaponMeshes();
        return orientParts([
            { name: 'shadowfang_arrow_shaft', mesh: m.shadowfangArrowShaft, color: C_OBSIDIAN },
            { name: 'shadowfang_arrow_fletch', mesh: m.shadowfangArrowFletch, color: C_VIOLET_GLOW, unlit: 0.80 },
            { name: 'shadowfang_arrow_head', mesh: m.shadowfangArrowHead, color: [0.64, 0.94, 0.36, 1], unlit: 0.92 }
        ], [1.22, 0.14, -0.06]);
    });
    builder.registerPart('offHand', 'offhand_bow_shadowfang', () => {
        const m = getClassFamilyWeaponMeshes();
        return orientParts([
            { name: 'shadowfang_bow_limbs', mesh: m.shadowfangBowLimbs, color: C_DRAGON_DARK },
            { name: 'shadowfang_bow_spurs', mesh: m.shadowfangBowSpurs, color: C_BONE },
            { name: 'shadowfang_bow_gem', mesh: m.shadowfangBowGem, color: C_VIOLET_GLOW, unlit: 0.94 },
            { name: 'shadowfang_bow_string', mesh: m.shadowfangBowString, color: C_DRAGON_AMETHYST, unlit: 0.72 }
        ], [0.12, -0.22, 0.22], [-0.012, 0.010, 0.020]);
    });
    builder.registerPart('mainHand', 'weapon_windrunner_arrow', () => {
        const m = getClassFamilyWeaponMeshes();
        return orientParts([
            { name: 'windrunner_arrow_shaft', mesh: m.windrunnerArrowShaft, color: C_SUN_GOLD },
            { name: 'windrunner_arrow_fletch', mesh: m.windrunnerArrowFletch, color: [0.44, 0.96, 0.72, 1], unlit: 0.85 },
            { name: 'windrunner_arrow_head', mesh: m.windrunnerArrowHead, color: C_SUN_GLOW, unlit: 0.96 }
        ], [1.22, 0.14, -0.06]);
    });
    builder.registerPart('offHand', 'offhand_bow_windrunner', () => {
        const m = getClassFamilyWeaponMeshes();
        return orientParts([
            { name: 'windrunner_bow_limbs', mesh: m.windrunnerBowLimbs, color: [0.22, 0.78, 0.56, 1] },
            { name: 'windrunner_bow_wings', mesh: m.windrunnerBowWings, color: C_SUN_GOLD },
            { name: 'windrunner_bow_gem', mesh: m.windrunnerBowGem, color: [0.58, 1.0, 0.82, 1], unlit: 0.96 },
            { name: 'windrunner_bow_string', mesh: m.windrunnerBowString, color: C_SUN_GLOW, unlit: 0.90 }
        ], [0.12, -0.22, 0.22], [-0.012, 0.010, 0.020]);
    });
}
let cachedClassFamilyWeapons = null;
function getClassFamilyWeaponMeshes() {
    if (cachedClassFamilyWeapons)
        return cachedClassFamilyWeapons;
    const baseEq = getEquipmentWeaponMeshes();
    // 1. Apprentice Staff (oak stave + brass collar + sky-blue crystal finial)
    const apprenticeShaft = sculptLoft([
        { y: -0.36, rx: 0.022, rz: 0.022 },
        { y: 0.00, rx: 0.027, rz: 0.027 },
        { y: 0.44, rx: 0.030, rz: 0.030 },
        { y: 0.62, rx: 0.038, rz: 0.038 }
    ], { sides: 6, aoStrength: 0.16, aoGradient: 0.08 });
    const apprenticeFerrule = mergeMeshes([
        sculptLoft([
            { y: 0.56, rx: 0.044, rz: 0.044 },
            { y: 0.65, rx: 0.056, rz: 0.056 },
            { y: 0.69, rx: 0.042, rz: 0.042 }
        ], { sides: 6 }),
        transformMesh(ringTube(0.068, 0.011, 8, 4), [0, 0.72, 0])
    ]);
    const apprenticeCrystal = transformMesh(octahedron, [0, 0.80, 0], ZERO_ROT, [0.062, 0.118, 0.062]);
    // 2. Solis Archstaff (ornate twin-ringed violet-gold archstaff)
    const archstaffShaft = sculptLoft([
        { y: -0.39, rx: 0.020, rz: 0.020 },
        { y: 0.00, rx: 0.030, rz: 0.030 },
        { y: 0.54, rx: 0.038, rz: 0.038 },
        { y: 0.66, rx: 0.052, rz: 0.052 }
    ], { sides: 6, aoStrength: 0.18, aoGradient: 0.10 });
    const archstaffRings = bakeVertexAO(mergeMeshes([
        transformMesh(ringTube(0.145, 0.017, 12, 5), [0, 0.84, 0], [Math.PI * 0.5, 0.35, 0]),
        transformMesh(ringTube(0.145, 0.017, 12, 5), [0, 0.84, 0], [Math.PI * 0.5, -0.35, 0]),
        sculptLoft([
            { y: 0.62, rx: 0.062, rz: 0.062 },
            { y: 0.70, rx: 0.044, rz: 0.044 }
        ], { sides: 8 })
    ]), { strength: 0.14, verticalGradient: 0.08 });
    const archstaffPrism = transformMesh(octahedron, [0, 0.84, 0], [0, Math.PI * 0.25, 0], [0.068, 0.132, 0.068]);
    const archstaffCore = mergeMeshes([
        transformMesh(octahedron, [0, 1.03, 0], ZERO_ROT, [0.032, 0.054, 0.032]),
        transformMesh(octahedron, [0, 0.67, 0], ZERO_ROT, [0.036, 0.036, 0.036])
    ]);
    // 3. Celestial Staff (mythic crescent halo + twin orbiting star crystals)
    const celestialShaft = sculptLoft([
        { y: -0.40, rx: 0.018, rz: 0.018 },
        { y: -0.05, rx: 0.031, rz: 0.031 },
        { y: 0.56, rx: 0.040, rz: 0.040 },
        { y: 0.68, rx: 0.058, rz: 0.058 }
    ], { sides: 8, aoStrength: 0.16, aoGradient: 0.08 });
    const celestialHalo = bakeVertexAO(mergeMeshes([
        transformMesh(ringTube(0.182, 0.018, 14, 5), [0, 0.88, 0], [Math.PI * 0.5, 0, 0]),
        transformMesh(ringTube(0.118, 0.012, 12, 4), [0, 0.88, 0], [0.35, 0.25, 0]),
        sculptLoft([
            { y: 0.66, rx: 0.068, rz: 0.068 },
            { y: 0.74, rx: 0.038, rz: 0.038 }
        ], { sides: 8 })
    ]), { strength: 0.12, verticalGradient: 0.06 });
    const celestialStar = mergeMeshes([
        transformMesh(octahedron, [0, 0.88, 0], ZERO_ROT, [0.072, 0.156, 0.072]),
        transformMesh(octahedron, [0, 0.88, 0], ZERO_ROT, [0.145, 0.048, 0.048]),
        transformMesh(octahedron, [0, 0.88, 0], ZERO_ROT, [0.048, 0.048, 0.145])
    ]);
    const celestialMoons = mergeMeshes([
        transformMesh(octahedron, [0, 0.88, 0.185], ZERO_ROT, [0.032, 0.052, 0.032]),
        transformMesh(octahedron, [0, 0.88, -0.185], ZERO_ROT, [0.032, 0.052, 0.032]),
        transformMesh(octahedron, [0, 1.07, 0], ZERO_ROT, [0.038, 0.060, 0.038])
    ]);
    // 4. Falcon Recurve (`recurved_bow`)
    const falconBowLimbs = bakeVertexAO(tubeMesh([
        [0, -0.44, -0.06],
        [0, -0.26, 0.10],
        [0, 0.00, 0.14],
        [0, 0.26, 0.10],
        [0, 0.44, -0.06]
    ], [0.014, 0.024, 0.030, 0.024, 0.014], 6), { strength: 0.14, verticalGradient: 0.08 });
    const falconBowGrip = sculptLoft([
        { y: -0.09, rx: 0.032, rz: 0.036, zOffset: 0.14 },
        { y: 0.00, rx: 0.035, rz: 0.040, zOffset: 0.14 },
        { y: 0.09, rx: 0.032, rz: 0.036, zOffset: 0.14 }
    ], { sides: 6 });
    const falconBowTips = mergeMeshes([
        transformMesh(octahedron, [0, 0.46, -0.08], [0.35, 0, 0], [0.026, 0.068, 0.034]),
        transformMesh(octahedron, [0, -0.46, -0.08], [-0.35, 0, 0], [0.026, 0.068, 0.034])
    ]);
    const falconBowString = tubeMesh([[0, -0.43, -0.06], [0, 0, -0.09], [0, 0.43, -0.06]], [0.006, 0.006, 0.006], 4);
    const falconArrowShaft = transformMesh(baseEq.yewArrowShaft, [0, 0, 0], ZERO_ROT, [1.05, 1.02, 1.05]);
    const falconArrowFletch = transformMesh(baseEq.yewArrowFletch, [0, -0.01, 0], ZERO_ROT, [1.18, 1.10, 1.18]);
    const falconArrowHead = diamondBladeLoft([
        [0.45, 0.028, 0.072],
        [0.51, 0.034, 0.088],
        [0.69, 0.004, 0.004]
    ], 0.14);
    // 5. Gale Longbow (`gale_longbow`)
    const galeBowLimbs = bakeVertexAO(tubeMesh([
        [0, -0.50, -0.04],
        [0, -0.28, 0.12],
        [0, 0.00, 0.16],
        [0, 0.28, 0.12],
        [0, 0.50, -0.04]
    ], [0.012, 0.022, 0.028, 0.022, 0.012], 6), { strength: 0.14, verticalGradient: 0.08 });
    const galeBowFins = mergeMeshes([
        extrudeYZ([[0.09, 0.22], [0.22, 0.34], [0.16, 0.48], [0.02, 0.42]], 0.020, 0.10),
        extrudeYZ([[0.09, -0.22], [0.22, -0.34], [0.16, -0.48], [0.02, -0.42]], 0.020, 0.10)
    ]);
    const galeBowGrip = sculptLoft([
        { y: -0.08, rx: 0.030, rz: 0.038, zOffset: 0.16 },
        { y: 0.08, rx: 0.030, rz: 0.038, zOffset: 0.16 }
    ], { sides: 6 });
    const galeBowString = tubeMesh([[0, -0.49, -0.04], [0, 0, -0.08], [0, 0.49, -0.04]], [0.006, 0.006, 0.006], 4);
    const galeArrowShaft = transformMesh(baseEq.yewArrowShaft, [0, 0, 0], ZERO_ROT, [0.95, 1.06, 0.95]);
    const galeArrowFletch = transformMesh(baseEq.yewArrowFletch, [0, 0.02, 0], [0, 0.5, 0], [1.26, 1.18, 1.26]);
    const galeArrowHead = diamondBladeLoft([
        [0.47, 0.022, 0.068],
        [0.54, 0.028, 0.082],
        [0.73, 0.003, 0.003]
    ], 0.12);
    // 6. Shadowfang Bow (`shadowfang_bow`)
    const shadowfangBowLimbs = bakeVertexAO(tubeMesh([
        [0, -0.40, -0.07],
        [0, -0.22, 0.13],
        [0, 0.00, 0.17],
        [0, 0.22, 0.13],
        [0, 0.42, -0.07]
    ], [0.015, 0.028, 0.034, 0.028, 0.015], 5), { strength: 0.18, verticalGradient: 0.10 });
    const shadowfangBowSpurs = mergeMeshes([
        extrudeYZ([[0.12, 0.16], [0.25, 0.26], [0.16, 0.32], [0.08, 0.26]], 0.024, 0.12),
        extrudeYZ([[0.12, -0.16], [0.25, -0.26], [0.16, -0.32], [0.08, -0.26]], 0.024, 0.12),
        transformMesh(octahedron, [0, 0.43, -0.09], [0.55, 0, 0], [0.024, 0.056, 0.028]),
        transformMesh(octahedron, [0, -0.41, -0.09], [-0.55, 0, 0], [0.024, 0.052, 0.028])
    ]);
    const shadowfangBowGem = transformMesh(octahedron, [0, 0, 0.205], ZERO_ROT, [0.036, 0.060, 0.036]);
    const shadowfangBowString = tubeMesh([[0, -0.39, -0.07], [0, 0, -0.09], [0, 0.41, -0.07]], [0.007, 0.007, 0.007], 4);
    const shadowfangArrowShaft = transformMesh(baseEq.yewArrowShaft, [0, 0, 0], ZERO_ROT, [1.10, 1.04, 1.10]);
    const shadowfangArrowFletch = transformMesh(baseEq.yewArrowFletch, [0, -0.02, 0], [0, 1.0, 0], [1.22, 1.14, 1.22]);
    const shadowfangArrowHead = diamondBladeLoft([
        [0.44, 0.032, 0.086],
        [0.52, 0.038, 0.098],
        [0.71, 0.004, 0.004]
    ], 0.16);
    // 7. Windrunner Greatbow (`windrunner_bow`)
    const windrunnerBowLimbs = bakeVertexAO(tubeMesh([
        [0, -0.44, -0.05],
        [0, -0.24, 0.14],
        [0, 0.00, 0.19],
        [0, 0.24, 0.14],
        [0, 0.46, -0.05]
    ], [0.015, 0.028, 0.036, 0.028, 0.015], 6), { strength: 0.14, verticalGradient: 0.08 });
    const windrunnerBowWings = mergeMeshes([
        extrudeYZ([[0.12, 0.14], [0.28, 0.28], [0.22, 0.44], [0.04, 0.40]], 0.026, 0.12),
        extrudeYZ([[0.12, -0.14], [0.28, -0.28], [0.22, -0.44], [0.04, -0.40]], 0.026, 0.12),
        transformMesh(octahedron, [0, 0.47, -0.07], [0.42, 0, 0], [0.028, 0.064, 0.034]),
        transformMesh(octahedron, [0, -0.45, -0.07], [-0.42, 0, 0], [0.028, 0.058, 0.034])
    ]);
    const windrunnerBowGem = mergeMeshes([
        transformMesh(octahedron, [0, 0, 0.228], ZERO_ROT, [0.046, 0.074, 0.042]),
        transformMesh(octahedron, [0, 0.24, 0.175], ZERO_ROT, [0.026, 0.040, 0.026]),
        transformMesh(octahedron, [0, -0.24, 0.175], ZERO_ROT, [0.026, 0.040, 0.026])
    ]);
    const windrunnerBowString = tubeMesh([[0, -0.43, -0.05], [0, 0, -0.09], [0, 0.45, -0.05]], [0.008, 0.008, 0.008], 4);
    const windrunnerArrowShaft = transformMesh(baseEq.yewArrowShaft, [0, 0, 0], ZERO_ROT, [1.15, 1.08, 1.15]);
    const windrunnerArrowFletch = transformMesh(baseEq.yewArrowFletch, [0, 0.02, 0], [0, 0.25, 0], [1.34, 1.24, 1.34]);
    const windrunnerArrowHead = diamondBladeLoft([
        [0.46, 0.034, 0.092],
        [0.56, 0.040, 0.104],
        [0.76, 0.004, 0.004]
    ], 0.14);
    cachedClassFamilyWeapons = {
        apprenticeShaft,
        apprenticeFerrule,
        apprenticeCrystal,
        archstaffShaft,
        archstaffRings,
        archstaffPrism,
        archstaffCore,
        celestialShaft,
        celestialHalo,
        celestialStar,
        celestialMoons,
        falconBowLimbs,
        falconBowGrip,
        falconBowTips,
        falconBowString,
        falconArrowShaft,
        falconArrowFletch,
        falconArrowHead,
        galeBowLimbs,
        galeBowFins,
        galeBowGrip,
        galeBowString,
        galeArrowShaft,
        galeArrowFletch,
        galeArrowHead,
        shadowfangBowLimbs,
        shadowfangBowSpurs,
        shadowfangBowGem,
        shadowfangBowString,
        shadowfangArrowShaft,
        shadowfangArrowFletch,
        shadowfangArrowHead,
        windrunnerBowLimbs,
        windrunnerBowWings,
        windrunnerBowGem,
        windrunnerBowString,
        windrunnerArrowShaft,
        windrunnerArrowFletch,
        windrunnerArrowHead
    };
    return cachedClassFamilyWeapons;
}
