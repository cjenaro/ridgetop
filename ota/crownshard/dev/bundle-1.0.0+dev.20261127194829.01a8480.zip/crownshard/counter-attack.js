import { computeEndlessAttackerDamageMultiplier } from "./endless-roguelite.js";
import { computeUnitBondAssist } from "./hero-bonds.js";
import { computeShieldWallDefBonus } from "./passives.js";
import { mutatorDamageMultiplier } from "./mutators.js";
import { cellHeightAt, facingVector, terrainDefBonus, vectorToFacing } from "./types.js";
/** Counter-attacks deal 70% of the defender's normal frontal basic attack damage. */
export const COUNTER_DAMAGE_MULTIPLIER = 0.7;
/** Minimum damage floor for a melee counter-attack (70% of the 4-damage basic floor, rounded). */
export const COUNTER_MIN_DAMAGE = 3;
function manhattanDist(c1, r1, c2, r2) {
    return Math.abs(c1 - c2) + Math.abs(r1 - r2);
}
function elevationMul(attackerLevel, defenderLevel) {
    const diff = attackerLevel - defenderLevel;
    if (diff >= 3)
        return 1.35;
    if (diff === 2)
        return 1.28;
    if (diff === 1)
        return 1.2;
    if (diff === -1)
        return 0.92;
    if (diff <= -2)
        return 0.85;
    return 1.0;
}
function attackArcBetween(fromCol, fromRow, targetCol, targetRow, targetFacing) {
    const vc = fromCol - targetCol;
    const vr = fromRow - targetRow;
    if (vc === 0 && vr === 0)
        return 'front';
    const [fc, fr] = facingVector(targetFacing);
    const dot = vc * fc + vr * fr;
    const cross = Math.abs(vc * fr - vr * fc);
    if (dot > 0 && dot >= cross)
        return 'front';
    if (dot < 0 && -dot >= cross)
        return 'back';
    return 'flank';
}
function arcDamageMultiplier(arc) {
    if (arc === 'back')
        return 1.30;
    if (arc === 'flank')
        return 1.15;
    return 1.0;
}
/**
 * Returns true if a hero skill is a single-target adjacent melee weapon strike
 * that allows a surviving, unstunned frontal melee defender to counter-attack.
 */
export function isMeleeSkillEligibleForCounter(skill) {
    if (!skill)
        return false;
    return skill.range === 1 && skill.pattern === 'single' && skill.powerMul > 0;
}
/**
 * Determines whether `defender` will counter-attack `attacker` in response to an incoming hit.
 *
 * Rules:
 * - Both units must be alive and on opposing teams.
 * - Defender must survive the hit (`!incomingLethal`) and not be stunned (`stunTurns <= 0 && !incomingStun`).
 * - Incoming attack must be a frontal (`attackArc === 'front'`) adjacent melee strike (`manhattan === 1`,
 *   `!isRangedOrSkill`) against an eligible melee defender (`defender.range === 1`).
 */
export function canCounterAttack(battle, attacker, defender, attackArc, isRangedOrSkill = false, opts) {
    if (!battle || !attacker || !defender)
        return false;
    if (!attacker.alive || !defender.alive)
        return false;
    if (defender.team === attacker.team)
        return false;
    if (opts?.incomingLethal)
        return false;
    if (defender.stunTurns > 0 || opts?.incomingStun)
        return false;
    if (isRangedOrSkill)
        return false;
    if (attackArc !== 'front')
        return false;
    if (defender.range !== 1)
        return false;
    const aCol = opts?.attackerCol ?? attacker.col;
    const aRow = opts?.attackerRow ?? attacker.row;
    return manhattanDist(aCol, aRow, defender.col, defender.row) === 1;
}
/**
 * Explains why an eligible melee defender (`defender.range === 1`) cannot counter-attack,
 * or returns `null` if the defender will counter or is not a melee counter-capable unit.
 */
export function getCounterAvoidReason(battle, attacker, defender, attackArc, isRangedOrSkill = false, opts) {
    if (!battle || !attacker || !defender)
        return null;
    if (!attacker.alive || !defender.alive)
        return null;
    if (defender.team === attacker.team)
        return null;
    if (defender.range !== 1)
        return null;
    if (canCounterAttack(battle, attacker, defender, attackArc, isRangedOrSkill, opts))
        return null;
    if (opts?.incomingLethal)
        return 'lethal';
    if (defender.stunTurns > 0 || opts?.incomingStun)
        return 'stunned';
    const aCol = opts?.attackerCol ?? attacker.col;
    const aRow = opts?.attackerRow ?? attacker.row;
    if (isRangedOrSkill || manhattanDist(aCol, aRow, defender.col, defender.row) !== 1)
        return 'ranged';
    if (attackArc === 'back')
        return 'backstab';
    if (attackArc === 'flank')
        return 'flank';
    return null;
}
/**
 * Computes deterministic counter-attack damage dealt by `defender` back to `attacker`.
 * Counter strikes deal 70% of the defender's normal frontal basic attack damage,
 * accounting for attacker DEF, shield, elevation, cover/terrain DEF, empower,
 * and attacker's facing toward defender.
 */
export function computeCounterDamage(battle, defender, attacker, opts) {
    const attCol = opts?.attackerCol ?? attacker.col;
    const attRow = opts?.attackerRow ?? attacker.row;
    const attHp = opts?.attackerHp ?? attacker.hp;
    const attShield = opts?.attackerShield ?? attacker.shield;
    const attFacing = opts?.attackerFacing ?? vectorToFacing(defender.col - attCol, defender.row - attRow, attacker.facing);
    let raw = defender.atk;
    const defLvl = cellHeightAt(battle, defender.col, defender.row);
    const attLvl = cellHeightAt(battle, attCol, attRow);
    raw *= elevationMul(defLvl, attLvl);
    const counterArc = attackArcBetween(defender.col, defender.row, attCol, attRow, attFacing);
    raw *= arcDamageMultiplier(counterArc);
    if (defender.empowerTurns > 0) {
        raw *= 1.35;
    }
    raw *= computeEndlessAttackerDamageMultiplier(battle.endlessBlessings, { team: defender.team ?? 'enemy' }, { slowTurns: attacker.slowTurns ?? 0, stunTurns: attacker.stunTurns ?? 0 });
    raw *= mutatorDamageMultiplier(battle);
    if (battle.units && defender.uid && defender.team) {
        const defBond = computeUnitBondAssist({ units: battle.units, bondPairsActive: battle.bondPairsActive }, {
            uid: defender.uid,
            team: defender.team,
            col: defender.col,
            row: defender.row,
            alive: defender.alive ?? true,
            heroId: defender.heroId,
            downed: defender.downed
        });
        if (defBond.active)
            raw *= defBond.atkMul;
    }
    const attCell = battle.cells[attRow]?.[attCol];
    const terrainDef = attCell ? terrainDefBonus(attCell.terrain) : 0;
    const coverBonus = opts?.coverBonus ?? 0;
    const shieldWallDef = battle.units && attacker.uid && attacker.team
        ? computeShieldWallDefBonus({ units: battle.units }, { uid: attacker.uid, team: attacker.team, col: attCol, row: attRow, alive: attacker.alive ?? true })
        : 0;
    let bondedAttDef = attacker.def;
    if (battle.units && attacker.uid && attacker.team) {
        const attBond = computeUnitBondAssist({ units: battle.units, bondPairsActive: battle.bondPairsActive }, {
            uid: attacker.uid,
            team: attacker.team,
            col: attCol,
            row: attRow,
            alive: attacker.alive ?? true,
            heroId: attacker.heroId,
            downed: attacker.downed
        }, { col: attCol, row: attRow });
        if (attBond.active)
            bondedAttDef *= attBond.defMul;
    }
    const effDef = Math.max(0, bondedAttDef + shieldWallDef + terrainDef + coverBonus);
    const fullBasicDmg = Math.max(4, Math.round(raw - effDef * 0.72));
    const counterMul = COUNTER_DAMAGE_MULTIPLIER * (opts?.counterMul ?? 1.0);
    const normalDmg = Math.max(COUNTER_MIN_DAMAGE, Math.round(fullBasicDmg * counterMul));
    const shieldAbsorbed = Math.min(Math.max(0, attShield), normalDmg);
    const hpDamage = Math.max(0, normalDmg - shieldAbsorbed);
    const attackerHpAfter = Math.max(0, attHp - hpDamage);
    return {
        normalDmg,
        shieldAbsorbed,
        hpDamage,
        attackerHpAfter,
        lethalToAttacker: attackerHpAfter <= 0
    };
}
