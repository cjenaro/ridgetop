export const WORLD_REGIONS = {
    solis_vale: { name: 'Solis Vale', subtitle: 'Western Sunlit Heartlands', tierRange: 'Tier I–II', tintHex: '#93b868', accentHex: '#6ea858' },
    silverfen: { name: 'The Silverfen', subtitle: 'Twin-River Marshes & Shrines', tierRange: 'Tier II–III', tintHex: '#7cb5a0', accentHex: '#4fa89b' },
    ashen_catacombs: { name: 'Ashen Catacombs', subtitle: 'Haunted Timberlands & Vaults', tierRange: 'Tier II–IV', tintHex: '#8d7ea8', accentHex: '#8b72cf' },
    frostspire: { name: 'Frostspire Highlands', subtitle: 'Glacial Peaks & Ice Citadels', tierRange: 'Tier III–V', tintHex: '#9bc4db', accentHex: '#6fc3eb' },
    emberwaste: { name: 'Emberwaste Caldera', subtitle: 'Basalt Forges & Lava Rifts', tierRange: 'Tier IV–V', tintHex: '#c78262', accentHex: '#eb7544' },
    eclipse_dominion: { name: 'Eclipse Dominion', subtitle: 'Obsidian Headland & Throne', tierRange: 'Tier V', tintHex: '#9e6f9e', accentHex: '#d95ecc' },
    sunbleached_dunes: {
        name: 'Sunbleached Dunes', subtitle: 'Southern Desert Reach (Future)', tierRange: 'Tier V–VI',
        tintHex: '#dbb26b', accentHex: '#f0b84f', futureFrontier: true
    },
    aether_isles: {
        name: 'Aether Isles', subtitle: 'Sky-Struck Archipelago (Future)', tierRange: 'Tier VI–VII',
        tintHex: '#7da6d9', accentHex: '#7ad4ff', futureFrontier: true
    },
    shattered_expanse: {
        name: 'Shattered Expanse', subtitle: 'Outer Void Rim (Future)', tierRange: 'Tier VI–VIII',
        tintHex: '#8c5678', accentHex: '#ff69b4', futureFrontier: true
    }
};
export const DIFFICULTY_META = {
    1: { label: 'Skirmish', short: 'I', hex: '#4cd48c', bgHex: '#153828' },
    2: { label: 'Standard', short: 'II', hex: '#5ca8ff', bgHex: '#172c4d' },
    3: { label: 'Challenging', short: 'III', hex: '#ffcb57', bgHex: '#3b2c12' },
    4: { label: 'Hard', short: 'IV', hex: '#ff8a47', bgHex: '#422214' },
    5: { label: 'Boss', short: 'V', hex: '#ff5266', bgHex: '#421622' },
    6: { label: 'Mythic', short: 'VI', hex: '#d77dff', bgHex: '#331647' },
    7: { label: 'Cataclysm', short: 'VII', hex: '#ff69b4', bgHex: '#451232' },
    8: { label: 'Apex', short: 'VIII', hex: '#ffe878', bgHex: '#472210' }
};
export const RARITY_ORDER = ['common', 'uncommon', 'rare', 'epic', 'legendary'];
export const RARITY_META = {
    common: { label: 'Common', short: 'COM', hex: '#9fb4c2', bgHex: '#1b2836e8', value: 40, salvage: 15 },
    uncommon: { label: 'Uncommon', short: 'UNC', hex: '#4cd48c', bgHex: '#152e2be8', value: 90, salvage: 35 },
    rare: { label: 'Rare', short: 'RARE', hex: '#5ca8ff', bgHex: '#152742e8', value: 185, salvage: 80 },
    epic: { label: 'Epic', short: 'EPIC', hex: '#c87dff', bgHex: '#291b3ee8', value: 360, salvage: 175 },
    legendary: { label: 'Legendary', short: 'LEG', hex: '#ffcb57', bgHex: '#382a14e8', value: 720, salvage: 350 }
};
export const MERGE_COPIES_REQUIRED = {
    1: 3, // 3 identical 1* heroes -> 2* hero (unlocks Skill 2!)
    2: 2 // 2 identical 2* heroes -> 3* hero (unlocks Skill 3!)
};
export const HERO_SPECS = {
    knight: {
        id: 'knight',
        name: 'Sir Aldric',
        title: 'Knight',
        rarity: 'common',
        maxHp: 74,
        atk: 15,
        def: 6,
        speed: 8,
        move: 4,
        jump: 1,
        range: 1,
        crit: 0.10,
        zoc: true,
        lore: 'Sworn shieldbearer of the Solis Vanguard who holds the line against the Eclipse.',
        skills: [
            {
                id: 'shield_bash', name: 'Shield Bash', tier: 1,
                desc: 'Strike adjacent foe (125% ATK), Push 1 tile, +12 Shield & Taunt 2 turns.',
                range: 1, cooldown: 2, target: 'enemy', pattern: 'single',
                powerMul: 1.25, flatBonus: 4, healAmount: 0, shieldAmount: 12, ignoreArmor: 0.2,
                selfStatus: 'taunt', displacement: { kind: 'knockback', distance: 1 }, vfx: 'slash'
            },
            {
                id: 'bulwark_aura', name: 'Bulwark Aura', tier: 2,
                desc: 'Grant +20 Shield to self & adjacent allies, & Taunt nearby foes.',
                range: 0, cooldown: 3, target: 'self', pattern: 'aura',
                powerMul: 0, flatBonus: 0, healAmount: 6, shieldAmount: 20, ignoreArmor: 0,
                selfStatus: 'taunt', vfx: 'holy'
            },
            {
                id: 'solar_cleave', name: 'Crown Cleave', tier: 3,
                desc: 'Shatter all nearby enemies (165% ATK) & stun 1 turn.',
                range: 1, cooldown: 3, target: 'enemy', pattern: 'cross',
                powerMul: 1.65, flatBonus: 8, healAmount: 0, shieldAmount: 14, ignoreArmor: 0.35,
                status: 'stun', vfx: 'holy'
            }
        ]
    },
    archer: {
        id: 'archer',
        name: 'Lyra',
        title: 'Archer',
        rarity: 'common',
        maxHp: 50,
        atk: 16,
        def: 3,
        speed: 13,
        move: 4,
        jump: 2,
        range: 3,
        crit: 0.22,
        zoc: false,
        lore: 'Highland scout whose fletched arrows strike true from every ridge and tower.',
        skills: [
            {
                id: 'piercing_arrow', name: 'Piercing Shot', tier: 1,
                desc: 'Long shot (135% ATK, ignores 60% DEF) & Push 1 tile.',
                range: 4, cooldown: 2, target: 'enemy', pattern: 'single',
                powerMul: 1.35, flatBonus: 4, healAmount: 0, shieldAmount: 0, ignoreArmor: 0.6,
                displacement: { kind: 'knockback', distance: 1 }, vfx: 'arrow'
            },
            {
                id: 'volley_rain', name: 'Volley Rain', tier: 2,
                desc: 'Rain arrows in a 3x3 area (115% ATK to all foes).',
                range: 4, cooldown: 3, target: 'tile', pattern: 'area3',
                powerMul: 1.15, flatBonus: 3, healAmount: 0, shieldAmount: 0, ignoreArmor: 0.25,
                vfx: 'arrow'
            },
            {
                id: 'hawks_snipe', name: 'Hawk Snipe', tier: 3,
                desc: 'Cross-field lethal shot (210% ATK, ignores all armor).',
                range: 6, cooldown: 3, target: 'enemy', pattern: 'single',
                powerMul: 2.1, flatBonus: 10, healAmount: 0, shieldAmount: 0, ignoreArmor: 1.0,
                vfx: 'arrow'
            }
        ]
    },
    mage: {
        id: 'mage',
        name: 'Vesper',
        title: 'Mage',
        rarity: 'common',
        maxHp: 46,
        atk: 18,
        def: 2,
        speed: 11,
        move: 4,
        jump: 2,
        range: 3,
        crit: 0.16,
        zoc: false,
        lore: 'Keeper of the Solis Lantern who channels raw starfire into tactical bursts.',
        skills: [
            {
                id: 'arcane_bolt', name: 'Arcane Bolt', tier: 1,
                desc: 'Unerring arcane lance (130% ATK, ignores 75% DEF).',
                range: 3, cooldown: 2, target: 'enemy', pattern: 'single',
                powerMul: 1.3, flatBonus: 5, healAmount: 0, shieldAmount: 0, ignoreArmor: 0.75,
                vfx: 'arcane'
            },
            {
                id: 'ember_nova', name: 'Ember Nova', tier: 2,
                desc: 'Cross-shaped flame blast (125% ATK) & inflicts Burn.',
                range: 3, cooldown: 3, target: 'tile', pattern: 'cross',
                powerMul: 1.25, flatBonus: 5, healAmount: 0, shieldAmount: 0, ignoreArmor: 0.5,
                status: 'burn', vfx: 'fire'
            },
            {
                id: 'starfall', name: 'Starfall Storm', tier: 3,
                desc: '3x3 meteor tempest (175% ATK, ignores 80% DEF, Burn).',
                range: 4, cooldown: 3, target: 'tile', pattern: 'area3',
                powerMul: 1.75, flatBonus: 8, healAmount: 0, shieldAmount: 0, ignoreArmor: 0.8,
                status: 'burn', vfx: 'fire'
            }
        ]
    },
    cleric: {
        id: 'cleric',
        name: 'Sera',
        title: 'Cleric',
        rarity: 'uncommon',
        maxHp: 56,
        atk: 14,
        def: 4,
        speed: 10,
        move: 4,
        jump: 2,
        range: 3,
        crit: 0.12,
        zoc: false,
        lore: 'Sun-order healer who mends shattered bones and burns shadow creatures.',
        skills: [
            {
                id: 'sun_mend', name: 'Sunbeam Mend', tier: 1,
                desc: 'Heal an ally 28 HP (+8 Shield & Haste), or Revive a downed hero (50% HP).',
                range: 3, cooldown: 2, target: 'ally', pattern: 'single',
                powerMul: 0, flatBonus: 0, healAmount: 28, shieldAmount: 8, ignoreArmor: 0,
                canRevive: true, reviveHpRatio: 0.5, status: 'haste',
                vfx: 'holy'
            },
            {
                id: 'sanctuary_wave', name: 'Sanctuary Wave', tier: 2,
                desc: 'Heal self & adjacent allies 24 HP + 14 Shield; revives adjacent downed allies.',
                range: 0, cooldown: 3, target: 'self', pattern: 'aura',
                powerMul: 0, flatBonus: 0, healAmount: 24, shieldAmount: 14, ignoreArmor: 0,
                canRevive: true, reviveHpRatio: 0.45,
                vfx: 'holy'
            },
            {
                id: 'dawns_judgment', name: 'Dawn Judgment', tier: 3,
                desc: 'Smite 3x3 enemies (155% ATK) & heal or revive nearby allies.',
                range: 3, cooldown: 3, target: 'tile', pattern: 'area3',
                powerMul: 1.55, flatBonus: 8, healAmount: 22, shieldAmount: 10, ignoreArmor: 0.7,
                canRevive: true, reviveHpRatio: 0.55,
                vfx: 'holy'
            }
        ]
    },
    rogue: {
        id: 'rogue',
        name: 'Kael',
        title: 'Rogue',
        rarity: 'uncommon',
        maxHp: 54,
        atk: 19,
        def: 3,
        speed: 15,
        move: 5,
        jump: 3,
        range: 1,
        crit: 0.32,
        zoc: true,
        evadeZoc: true,
        lore: 'Swift twilight duelist who vaults across battle lines to sever enemy casters.',
        skills: [
            {
                id: 'shadowstep', name: 'Shadow Strike', tier: 1,
                desc: 'Vault up to 3 tiles to ambush foe (145% ATK), Swap positions & inflict Poison x2.',
                range: 3, cooldown: 2, target: 'enemy', pattern: 'single',
                powerMul: 1.45, flatBonus: 5, healAmount: 0, shieldAmount: 0, ignoreArmor: 0.4,
                status: 'poison', statusStacks: 2, displacement: { kind: 'swap', distance: 1 }, vfx: 'shadow'
            },
            {
                id: 'fan_blades', name: 'Fan of Blades', tier: 2,
                desc: 'Slash all enemies in a cross (135% ATK) & inflict Poison.',
                range: 1, cooldown: 2, target: 'enemy', pattern: 'cross',
                powerMul: 1.35, flatBonus: 4, healAmount: 0, shieldAmount: 10, ignoreArmor: 0.35,
                status: 'poison', statusStacks: 1, vfx: 'shadow'
            },
            {
                id: 'phantom_exec', name: 'Phantom Finisher', tier: 3,
                desc: 'Devastating 225% ATK strike & gain Empower.',
                range: 3, cooldown: 3, target: 'enemy', pattern: 'single',
                powerMul: 2.25, flatBonus: 12, healAmount: 14, shieldAmount: 0, ignoreArmor: 0.85,
                status: 'empower', vfx: 'shadow'
            }
        ]
    },
    paladin: {
        id: 'paladin',
        name: 'Dame Isolde',
        title: 'Paladin',
        rarity: 'rare',
        maxHp: 88,
        atk: 18,
        def: 8,
        speed: 9,
        move: 4,
        jump: 1,
        range: 1,
        crit: 0.15,
        zoc: true,
        lore: 'Gilded champion of the High Bastion, armored in sun-forged plate.',
        skills: [
            {
                id: 'radiant_cleave', name: 'Radiant Smite', tier: 1,
                desc: 'Strike enemy (145% ATK) & heal self for 16 HP.',
                range: 1, cooldown: 2, target: 'enemy', pattern: 'single',
                powerMul: 1.45, flatBonus: 6, healAmount: 16, shieldAmount: 8, ignoreArmor: 0.35,
                vfx: 'holy'
            },
            {
                id: 'aegis_vow', name: 'Aegis Vow', tier: 2,
                desc: 'Fortify self & allies (+30 Shield, Empower) & Taunt nearby foes.',
                range: 0, cooldown: 3, target: 'self', pattern: 'aura',
                powerMul: 0, flatBonus: 0, healAmount: 14, shieldAmount: 30, ignoreArmor: 0,
                status: 'empower', selfStatus: 'taunt', vfx: 'holy'
            },
            {
                id: 'solar_verdict', name: 'Solar Verdict', tier: 3,
                desc: 'Unleash 3x3 radiant wrath (190% ATK) & stun foes.',
                range: 2, cooldown: 3, target: 'tile', pattern: 'area3',
                powerMul: 1.9, flatBonus: 10, healAmount: 16, shieldAmount: 16, ignoreArmor: 0.65,
                status: 'stun', vfx: 'holy'
            }
        ]
    },
    cryomancer: {
        id: 'cryomancer',
        name: 'Freya',
        title: 'Cryomancer',
        rarity: 'epic',
        maxHp: 56,
        atk: 21,
        def: 4,
        speed: 11,
        move: 4,
        jump: 2,
        range: 3,
        crit: 0.18,
        zoc: false,
        lore: 'Glacial arcanist from Frostspire who locks entire enemy flanks in crystal ice.',
        skills: [
            {
                id: 'frost_lance', name: 'Frost Lance', tier: 1,
                desc: 'Pierce enemy (140% ATK, ignores 70% DEF), Pull 2 tiles & Slow.',
                range: 4, cooldown: 2, target: 'enemy', pattern: 'single',
                powerMul: 1.4, flatBonus: 6, healAmount: 0, shieldAmount: 0, ignoreArmor: 0.7,
                status: 'slow', displacement: { kind: 'pull', distance: 2 }, vfx: 'frost'
            },
            {
                id: 'glacial_ring', name: 'Glacial Ring', tier: 2,
                desc: 'Freeze a cross area (135% ATK) & Slow all struck.',
                range: 3, cooldown: 3, target: 'tile', pattern: 'cross',
                powerMul: 1.35, flatBonus: 6, healAmount: 0, shieldAmount: 10, ignoreArmor: 0.6,
                status: 'slow', vfx: 'frost'
            },
            {
                id: 'absolute_zero', name: 'Absolute Zero', tier: 3,
                desc: '3x3 deep freeze (195% ATK, Stuns all enemies!).',
                range: 4, cooldown: 3, target: 'tile', pattern: 'area3',
                powerMul: 1.95, flatBonus: 10, healAmount: 0, shieldAmount: 12, ignoreArmor: 0.85,
                status: 'stun', vfx: 'frost'
            }
        ]
    },
    champion: {
        id: 'champion',
        name: 'Aurelius',
        title: 'Sunblade',
        rarity: 'legendary',
        maxHp: 96,
        atk: 25,
        def: 9,
        speed: 12,
        move: 5,
        jump: 3,
        range: 2,
        crit: 0.26,
        zoc: true,
        lore: 'Mythic heir of the First Crown, wielding twin blades of living starlight.',
        skills: [
            {
                id: 'solar_slash', name: 'Solar Arc', tier: 1,
                desc: 'Sweeping fire arc (155% ATK, ignores 50% DEF, Burn) & Push 1 tile.',
                range: 2, cooldown: 2, target: 'enemy', pattern: 'cross',
                powerMul: 1.55, flatBonus: 8, healAmount: 0, shieldAmount: 14, ignoreArmor: 0.5,
                status: 'burn', displacement: { kind: 'knockback', distance: 1 }, vfx: 'fire'
            },
            {
                id: 'phoenix_charge', name: 'Phoenix Surge', tier: 2,
                desc: 'Blazing 3x3 detonation (170% ATK) & +24 Shield.',
                range: 3, cooldown: 3, target: 'tile', pattern: 'area3',
                powerMul: 1.7, flatBonus: 10, healAmount: 14, shieldAmount: 24, ignoreArmor: 0.65,
                status: 'burn', vfx: 'fire'
            },
            {
                id: 'crownbreaker', name: 'Crownbreaker', tier: 3,
                desc: 'Cataclysmic 3x3 golden shockwave (240% ATK, Stun).',
                range: 3, cooldown: 3, target: 'tile', pattern: 'area3',
                powerMul: 2.4, flatBonus: 16, healAmount: 20, shieldAmount: 28, ignoreArmor: 0.9,
                status: 'stun', vfx: 'holy'
            }
        ]
    }
};
export const HERO_LIST = Object.values(HERO_SPECS);
export const EQUIPMENT_LIST = [
    // Weapons — Vanguard (Swords & Plate), Arcane (Staves & Robes), Skirmisher (Bows & Light)
    {
        id: 'iron_sword', name: 'Iron Broadsword', slot: 'weapon', family: 'vanguard', rarity: 'common',
        desc: '+5 ATK. Reliable Vanguard steel.',
        atk: 5, def: 0, hp: 0, speed: 0, move: 0, range: 0, crit: 0.04, lifesteal: 0, shieldStart: 0, accentHex: '#c2cfd8'
    },
    {
        id: 'apprentice_staff', name: 'Apprentice Staff', slot: 'weapon', family: 'arcane', rarity: 'common',
        desc: '+5 ATK, +4 HP, +5% Crit.',
        atk: 5, def: 0, hp: 4, speed: 0, move: 0, range: 0, crit: 0.05, lifesteal: 0, shieldStart: 0, accentHex: '#76b4e8'
    },
    {
        id: 'hunter_bow', name: 'Yew Longbow', slot: 'weapon', family: 'skirmisher', rarity: 'common',
        desc: '+4 ATK, +1 SPD, +10% Crit.',
        atk: 4, def: 0, hp: 0, speed: 1, move: 0, range: 0, crit: 0.10, lifesteal: 0, shieldStart: 0, accentHex: '#b8834d'
    },
    {
        id: 'ember_wand', name: 'Ember Scepter', slot: 'weapon', family: 'arcane', setId: 'astral', rarity: 'uncommon',
        desc: '+8 ATK, +6 HP, +1 SPD.',
        atk: 8, def: 0, hp: 6, speed: 1, move: 0, range: 0, crit: 0.06, lifesteal: 0, shieldStart: 0, accentHex: '#f08742'
    },
    {
        id: 'recurved_bow', name: 'Falcon Recurve', slot: 'weapon', family: 'skirmisher', rarity: 'uncommon',
        desc: '+8 ATK, +2 SPD, +14% Crit.',
        atk: 8, def: 0, hp: 4, speed: 2, move: 0, range: 0, crit: 0.14, lifesteal: 0, shieldStart: 0, accentHex: '#66c98e'
    },
    {
        id: 'sunsteel_blade', name: 'Sunsteel Blade', slot: 'weapon', family: 'vanguard', setId: 'solis', rarity: 'rare',
        desc: '+11 ATK, +1 SPD, +14% Crit.',
        atk: 11, def: 1, hp: 0, speed: 1, move: 0, range: 0, crit: 0.14, lifesteal: 0, shieldStart: 0, accentHex: '#f0c44d'
    },
    {
        id: 'frostbite_staff', name: 'Frostbite Staff', slot: 'weapon', family: 'arcane', setId: 'frostguard', rarity: 'rare',
        desc: '+10 ATK, +1 Range, +1 SPD.',
        atk: 10, def: 0, hp: 8, speed: 1, move: 0, range: 1, crit: 0.08, lifesteal: 0, shieldStart: 0, accentHex: '#6dd9ff'
    },
    {
        id: 'gale_longbow', name: 'Gale Longbow', slot: 'weapon', family: 'skirmisher', setId: 'windrunner', rarity: 'rare',
        desc: '+11 ATK, +1 Range, +2 SPD, +18% Crit.',
        atk: 11, def: 0, hp: 6, speed: 2, move: 0, range: 1, crit: 0.18, lifesteal: 0, shieldStart: 0, accentHex: '#59d4ff'
    },
    {
        id: 'dragonfang_spear', name: 'Dragonfang Halberd', slot: 'weapon', family: 'vanguard', setId: 'frostguard', rarity: 'epic',
        desc: '+15 ATK, +1 Range, +15% Lifesteal, Venom.',
        atk: 15, def: 2, hp: 10, speed: 1, move: 0, range: 1, crit: 0.12, lifesteal: 0.15, shieldStart: 0, onHitStatus: 'poison', accentHex: '#d66bff'
    },
    {
        id: 'solis_archstaff', name: 'Solis Archstaff', slot: 'weapon', family: 'arcane', setId: 'solis', rarity: 'epic',
        desc: '+15 ATK, +1 Range, +2 SPD, +12% Crit.',
        atk: 15, def: 1, hp: 12, speed: 2, move: 0, range: 1, crit: 0.12, lifesteal: 0, shieldStart: 0, accentHex: '#b882ff'
    },
    {
        id: 'shadowfang_bow', name: 'Shadowfang Bow', slot: 'weapon', family: 'skirmisher', setId: 'shadowfang', rarity: 'epic',
        desc: '+15 ATK, +1 Range, +22% Crit, Venom.',
        atk: 15, def: 0, hp: 8, speed: 2, move: 0, range: 1, crit: 0.22, lifesteal: 0.12, shieldStart: 0, onHitStatus: 'poison', accentHex: '#c76eff'
    },
    {
        id: 'solis_crownblade', name: 'Solis Crownblade', slot: 'weapon', family: 'vanguard', setId: 'solis', rarity: 'legendary',
        desc: '+22 ATK, +2 SPD, +25% Crit, Lifesteal.',
        atk: 22, def: 3, hp: 16, speed: 2, move: 0, range: 0, crit: 0.25, lifesteal: 0.25, shieldStart: 0, accentHex: '#ffe066'
    },
    {
        id: 'celestial_staff', name: 'Celestial Staff', slot: 'weapon', family: 'arcane', setId: 'astral', rarity: 'legendary',
        desc: '+21 ATK, +1 Range, +2 SPD, +20% Crit.',
        atk: 21, def: 2, hp: 18, speed: 2, move: 0, range: 1, crit: 0.20, lifesteal: 0.15, shieldStart: 0, accentHex: '#8ef4ff'
    },
    {
        id: 'windrunner_bow', name: 'Windrunner Greatbow', slot: 'weapon', family: 'skirmisher', setId: 'windrunner', rarity: 'legendary',
        desc: '+21 ATK, +1 Range, +3 SPD, +28% Crit.',
        atk: 21, def: 1, hp: 12, speed: 3, move: 0, range: 1, crit: 0.28, lifesteal: 0.15, shieldStart: 0, accentHex: '#74f2b8'
    },
    // Armor — Plate (Vanguard), Robes (Arcane), Light (Skirmisher)
    {
        id: 'leather_jerkin', name: 'Scout Brigandine', slot: 'armor', family: 'skirmisher', rarity: 'common',
        desc: '+14 HP, +2 DEF.',
        atk: 0, def: 2, hp: 14, speed: 0, move: 0, range: 0, crit: 0, lifesteal: 0, shieldStart: 0, accentHex: '#8c6543'
    },
    {
        id: 'iron_plate', name: 'Watchman Plate', slot: 'armor', family: 'vanguard', rarity: 'common',
        desc: '+22 HP, +4 DEF, +6 Start Shield.',
        atk: 0, def: 4, hp: 22, speed: 0, move: 0, range: 0, crit: 0, lifesteal: 0, shieldStart: 6, accentHex: '#8d9ca6'
    },
    {
        id: 'acolyte_robe', name: 'Acolyte Robe', slot: 'armor', family: 'arcane', rarity: 'common',
        desc: '+12 HP, +2 DEF, +1 SPD, +6 Start Shield.',
        atk: 0, def: 2, hp: 12, speed: 1, move: 0, range: 0, crit: 0, lifesteal: 0, shieldStart: 6, accentHex: '#6a7fd4'
    },
    {
        id: 'ranger_cloak', name: 'Windrunner Cloak', slot: 'armor', family: 'skirmisher', setId: 'windrunner', rarity: 'uncommon',
        desc: '+16 HP, +2 SPD, +1 Move.',
        atk: 0, def: 2, hp: 16, speed: 2, move: 1, range: 0, crit: 0.06, lifesteal: 0, shieldStart: 0, accentHex: '#43a87b'
    },
    {
        id: 'sunweave_robe', name: 'Sunweave Vestment', slot: 'armor', family: 'arcane', setId: 'solis', rarity: 'uncommon',
        desc: '+18 HP, +3 DEF, +1 ATK, +10 Start Shield.',
        atk: 1, def: 3, hp: 18, speed: 1, move: 0, range: 0, crit: 0.04, lifesteal: 0, shieldStart: 10, accentHex: '#e6b655'
    },
    {
        id: 'runed_mail', name: 'Runed Chainmail', slot: 'armor', family: 'vanguard', setId: 'frostguard', rarity: 'rare',
        desc: '+32 HP, +6 DEF, +12 Start Shield.',
        atk: 0, def: 6, hp: 32, speed: 1, move: 0, range: 0, crit: 0, lifesteal: 0, shieldStart: 12, accentHex: '#5a9cf2'
    },
    {
        id: 'astral_vestments', name: 'Astral Vestments', slot: 'armor', family: 'arcane', setId: 'astral', rarity: 'rare',
        desc: '+26 HP, +4 DEF, +3 ATK, +2 SPD, +14 Shield.',
        atk: 3, def: 4, hp: 26, speed: 2, move: 0, range: 0, crit: 0.06, lifesteal: 0, shieldStart: 14, accentHex: '#6ea8ff'
    },
    {
        id: 'stalker_leathers', name: 'Stalker Leathers', slot: 'armor', family: 'skirmisher', setId: 'shadowfang', rarity: 'rare',
        desc: '+24 HP, +4 DEF, +3 ATK, +2 SPD, +10% Crit.',
        atk: 3, def: 4, hp: 24, speed: 2, move: 0, range: 0, crit: 0.10, lifesteal: 0, shieldStart: 0, accentHex: '#5d87b8'
    },
    {
        id: 'frostguard_plate', name: 'Frostguard Plate', slot: 'armor', family: 'vanguard', setId: 'frostguard', rarity: 'epic',
        desc: '+44 HP, +8 DEF, +20 Start Shield.',
        atk: 2, def: 8, hp: 44, speed: 1, move: 0, range: 0, crit: 0, lifesteal: 0, shieldStart: 20, accentHex: '#9d7bff'
    },
    {
        id: 'glacier_raiment', name: 'Glacier Raiment', slot: 'armor', family: 'arcane', setId: 'frostguard', rarity: 'epic',
        desc: '+36 HP, +5 DEF, +4 ATK, +2 SPD, +18 Shield.',
        atk: 4, def: 5, hp: 36, speed: 2, move: 0, range: 0, crit: 0.08, lifesteal: 0, shieldStart: 18, accentHex: '#85e0ff'
    },
    {
        id: 'shadowsilk_vest', name: 'Shadowsilk Vest', slot: 'armor', family: 'skirmisher', setId: 'shadowfang', rarity: 'epic',
        desc: '+34 HP, +5 DEF, +5 ATK, +3 SPD, +1 Move.',
        atk: 5, def: 5, hp: 34, speed: 3, move: 1, range: 0, crit: 0.14, lifesteal: 0, shieldStart: 0, accentHex: '#a86bff'
    },
    {
        id: 'aegis_of_dawn', name: 'Aegis of Dawn', slot: 'armor', family: 'vanguard', setId: 'solis', rarity: 'legendary',
        desc: '+62 HP, +11 DEF, +2 SPD, +32 Shield, Start Taunt.',
        atk: 4, def: 11, hp: 62, speed: 2, move: 0, range: 0, crit: 0, lifesteal: 0, shieldStart: 32, startStatus: 'taunt', accentHex: '#ffd15c'
    },
    {
        id: 'starweaver_mantle', name: 'Starweaver Mantle', slot: 'armor', family: 'arcane', setId: 'astral', rarity: 'legendary',
        desc: '+48 HP, +7 DEF, +6 ATK, +3 SPD, +26 Shield.',
        atk: 6, def: 7, hp: 48, speed: 3, move: 0, range: 0, crit: 0.10, lifesteal: 0, shieldStart: 26, accentHex: '#d499ff'
    },
    {
        id: 'nightwind_garb', name: 'Nightwind Shroud', slot: 'armor', family: 'skirmisher', setId: 'shadowfang', rarity: 'legendary',
        desc: '+46 HP, +7 DEF, +7 ATK, +3 SPD, +1 Move, +18% Crit.',
        atk: 7, def: 7, hp: 46, speed: 3, move: 1, range: 0, crit: 0.18, lifesteal: 0, shieldStart: 16, accentHex: '#5ce8b8'
    },
    // Relics — Universal (equippable by all hero classes)
    {
        id: 'copper_signet', name: 'Copper Signet', slot: 'relic', family: 'universal', rarity: 'common',
        desc: '+3 ATK, +8 HP, +1 SPD.',
        atk: 3, def: 1, hp: 8, speed: 1, move: 0, range: 0, crit: 0.05, lifesteal: 0, shieldStart: 0, accentHex: '#c9885b'
    },
    {
        id: 'swift_boots', name: 'Gale Striders', slot: 'relic', family: 'universal', setId: 'windrunner', rarity: 'uncommon',
        desc: '+3 SPD, +1 Move, +10 HP, Start Haste.',
        atk: 2, def: 1, hp: 10, speed: 3, move: 1, range: 0, crit: 0.08, lifesteal: 0, shieldStart: 0, startStatus: 'haste', accentHex: '#5cd99e'
    },
    {
        id: 'blood_amulet', name: 'Crimson Pendant', slot: 'relic', family: 'universal', setId: 'shadowfang', rarity: 'rare',
        desc: '+6 ATK, +28% Lifesteal, +1 SPD.',
        atk: 6, def: 0, hp: 12, speed: 1, move: 0, range: 0, crit: 0.08, lifesteal: 0.28, shieldStart: 0, accentHex: '#e85a6f'
    },
    {
        id: 'eagle_charm', name: 'Skyhawk Crest', slot: 'relic', family: 'universal', setId: 'windrunner', rarity: 'epic',
        desc: '+1 Range, +2 SPD, +8 ATK, +20% Crit.',
        atk: 8, def: 1, hp: 14, speed: 2, move: 0, range: 1, crit: 0.20, lifesteal: 0, shieldStart: 0, accentHex: '#be7dff'
    },
    {
        id: 'heart_of_solis', name: 'Heart of Solis', slot: 'relic', family: 'universal', setId: 'solis', rarity: 'legendary',
        desc: '+34 HP, +12 ATK, +3 SPD, +1 Move.',
        atk: 12, def: 4, hp: 34, speed: 3, move: 1, range: 0, crit: 0.18, lifesteal: 0.15, shieldStart: 15, accentHex: '#ffdb6e'
    }
];
export const EQUIPMENT_BY_ID = Object.fromEntries(EQUIPMENT_LIST.map(item => [item.id, item]));
export const TACTIC_LIST = [
    {
        id: 'rally_banner', name: 'Rally Banner', rarity: 'common', cost: 1,
        target: 'ally', pattern: 'single',
        desc: 'Empower ally (+35% DMG) & +10 Shield.',
        damage: 0, heal: 0, shield: 10, apGain: 0, status: 'empower', vfx: 'holy'
    },
    {
        id: 'healing_draught', name: 'Sunleaf Tonic', rarity: 'common', cost: 1,
        target: 'ally', pattern: 'single',
        desc: 'Restore 26 HP or Revive a downed hero (45% HP).',
        damage: 0, heal: 26, shield: 0, apGain: 0, canRevive: true, reviveHpRatio: 0.45, vfx: 'holy'
    },
    {
        id: 'phoenix_sigil', name: 'Phoenix Sigil', rarity: 'uncommon', cost: 1,
        target: 'ally', pattern: 'single',
        desc: 'Revive a downed hero (60% HP) or heal 30 HP + 12 Shield.',
        damage: 0, heal: 30, shield: 12, apGain: 0, canRevive: true, reviveHpRatio: 0.6, vfx: 'holy'
    },
    {
        id: 'iron_ward', name: 'Iron Ward', rarity: 'common', cost: 1,
        target: 'ally', pattern: 'single',
        desc: 'Grant +24 Shield to target hero.',
        damage: 0, heal: 0, shield: 24, apGain: 0, vfx: 'holy'
    },
    {
        id: 'flame_scroll', name: 'Cinder Scroll', rarity: 'uncommon', cost: 1,
        target: 'enemy', pattern: 'single',
        desc: 'Deal 20 Fire DMG & inflict Burn.',
        damage: 20, heal: 0, shield: 0, apGain: 0, status: 'burn', vfx: 'fire'
    },
    {
        id: 'wind_step', name: 'Gale Step', rarity: 'uncommon', cost: 1,
        target: 'ally', pattern: 'single',
        desc: 'Refresh ally Movement, +8 Shield & grant Haste.',
        damage: 0, heal: 0, shield: 8, apGain: 0, status: 'haste', refreshMove: true, vfx: 'arcane'
    },
    {
        id: 'gale_gust', name: 'Gale Gust', rarity: 'uncommon', cost: 1,
        target: 'enemy', pattern: 'single',
        desc: 'Blast an enemy 2 tiles back (8 DMG) with roaring wind.',
        damage: 8, heal: 0, shield: 0, apGain: 0,
        displacement: { kind: 'knockback', distance: 2 },
        vfx: 'arcane'
    },
    {
        id: 'taunt_banner', name: 'Vanguard Challenge', rarity: 'common', cost: 1,
        target: 'ally', pattern: 'single',
        desc: 'Grant +16 Shield & Taunt nearby foes for 2 turns.',
        damage: 0, heal: 0, shield: 16, apGain: 0, status: 'taunt', vfx: 'holy'
    },
    {
        id: 'venom_vial', name: 'Venom Flask', rarity: 'uncommon', cost: 1,
        target: 'enemy', pattern: 'single',
        desc: 'Deal 14 Venom DMG & inflict Poison x2.',
        damage: 14, heal: 0, shield: 0, apGain: 0, status: 'poison', statusStacks: 2, vfx: 'shadow'
    },
    {
        id: 'frost_nova_scroll', name: 'Rime Seal', rarity: 'rare', cost: 2,
        target: 'tile', pattern: 'cross',
        desc: 'Deal 24 Frost DMG in cross & Slow foes.',
        damage: 24, heal: 0, shield: 0, apGain: 0, status: 'slow', vfx: 'frost'
    },
    {
        id: 'arcane_surge', name: 'Crown Surge', rarity: 'rare', cost: 0,
        target: 'ally', pattern: 'single',
        desc: 'Gain +2 AP immediately & +10 Shield.',
        damage: 0, heal: 0, shield: 10, apGain: 2, vfx: 'arcane'
    },
    {
        id: 'lightning_chain', name: 'Storm Decree', rarity: 'epic', cost: 2,
        target: 'tile', pattern: 'area3',
        desc: '3x3 Tempest dealing 32 DMG & Stun!',
        damage: 32, heal: 0, shield: 0, apGain: 0, status: 'stun', vfx: 'arcane'
    },
    {
        id: 'solar_blessing', name: 'Solar Blessing', rarity: 'legendary', cost: 2,
        target: 'any', pattern: 'all_allies',
        desc: 'Heal or Revive ALL heroes (30 HP), +22 Shield & Empower!',
        damage: 0, heal: 30, shield: 22, apGain: 0, canRevive: true, reviveHpRatio: 0.6, status: 'empower', vfx: 'holy'
    }
];
export const TACTIC_BY_ID = Object.fromEntries(TACTIC_LIST.map(card => [card.id, card]));
export const PACK_LIST = [
    {
        id: 'recruit',
        name: 'Recruit Deck',
        subtitle: '3 Cards · Hero Copies & Starter Gear',
        cost: 75,
        cardsPerPack: 3,
        guaranteedMinRarity: 'common',
        weights: { common: 75, uncommon: 20, rare: 4.5, epic: 0.45, legendary: 0.05 },
        accentHex: '#7fb5cf'
    },
    {
        id: 'vanguard',
        name: 'Vanguard Deck',
        subtitle: '4 Cards · 1+ Rare, Slim Epic Odds',
        cost: 190,
        cardsPerPack: 4,
        guaranteedMinRarity: 'rare',
        weights: { common: 56, uncommon: 31, rare: 11.4, epic: 1.45, legendary: 0.15 },
        featuredWeights: { common: 0, uncommon: 0, rare: 91, epic: 8.2, legendary: 0.8 },
        accentHex: '#5ca8ff'
    },
    {
        id: 'sovereign',
        name: 'Sovereign Deck',
        subtitle: '4 Cards · 1+ Rare, Best Epic/Leg Odds',
        cost: 520,
        cardsPerPack: 4,
        guaranteedMinRarity: 'rare',
        weights: { common: 32, uncommon: 36, rare: 26, epic: 5.2, legendary: 0.8 },
        featuredWeights: { common: 0, uncommon: 0, rare: 82, epic: 15.5, legendary: 2.5 },
        accentHex: '#ffcb57'
    }
];
export const PACK_BY_ID = {
    recruit: PACK_LIST[0],
    vanguard: PACK_LIST[1],
    sovereign: PACK_LIST[2]
};
export const ENEMY_SPECS = {
    goblin: {
        id: 'goblin', name: 'Ashen Goblin', maxHp: 38, atk: 12, def: 2, speed: 12, move: 4, jump: 2, range: 1, ai: 'melee', zoc: true
    },
    bone_archer: {
        id: 'bone_archer', name: 'Bone Archer', maxHp: 34, atk: 14, def: 1, speed: 11, move: 3, jump: 2, range: 3, ai: 'ranged', zoc: false
    },
    orc_brute: {
        id: 'orc_brute', name: 'Ironclad Orc', maxHp: 64, atk: 17, def: 5, speed: 7, move: 3, jump: 1, range: 1, ai: 'melee', zoc: true
    },
    bog_shaman: {
        id: 'bog_shaman', name: 'Eclipse Shaman', maxHp: 46, atk: 14, def: 2, speed: 10, move: 3, jump: 2, range: 3, ai: 'support', zoc: false
    },
    crypt_knight: {
        id: 'crypt_knight', name: 'Dread Knight', maxHp: 78, atk: 20, def: 7, speed: 9, move: 4, jump: 2, range: 1, ai: 'melee', zoc: true
    },
    frost_golem: {
        id: 'frost_golem', name: 'Frost Golem', maxHp: 96, atk: 22, def: 8, speed: 6, move: 3, jump: 1, range: 1, ai: 'melee', zoc: true
    },
    eclipse_archon: {
        id: 'eclipse_archon', name: 'Archon Malakor', maxHp: 190, atk: 26, def: 7, speed: 11, move: 4, jump: 3, range: 3, ai: 'boss', isBoss: true, zoc: true
    },
    // Biome-specific archetypes
    ember_pyromancer: {
        id: 'ember_pyromancer', name: 'Ember Pyromancer', maxHp: 52, atk: 18, def: 2, speed: 11, move: 4, jump: 2, range: 3, ai: 'ranged', zoc: false
    },
    ice_wraith: {
        id: 'ice_wraith', name: 'Ice Wraith', maxHp: 48, atk: 16, def: 3, speed: 13, move: 5, jump: 2, range: 2, ai: 'ranged', zoc: false, evadeZoc: true
    },
    bone_necromancer: {
        id: 'bone_necromancer', name: 'Bone Necromancer', maxHp: 56, atk: 16, def: 3, speed: 10, move: 3, jump: 2, range: 3, ai: 'support', zoc: false
    },
    bone_thrall: {
        id: 'bone_thrall', name: 'Bone Thrall', maxHp: 28, atk: 11, def: 2, speed: 10, move: 4, jump: 1, range: 1, ai: 'melee', zoc: true
    },
    river_troll: {
        id: 'river_troll', name: 'River Troll', maxHp: 94, atk: 19, def: 4, speed: 7, move: 4, jump: 1, range: 1, ai: 'melee', zoc: true
    },
    // Named regional mini-bosses for Special / Elite nodes
    briar_warlord: {
        id: 'briar_warlord', name: 'Grom, Briar Warlord', maxHp: 112, atk: 19, def: 6, speed: 8, move: 4, jump: 2, range: 1, ai: 'boss', isBoss: true, zoc: true
    },
    mire_matriarch: {
        id: 'mire_matriarch', name: 'Vex, Mire Matriarch', maxHp: 98, atk: 17, def: 4, speed: 10, move: 3, jump: 2, range: 3, ai: 'boss', isBoss: true, zoc: false
    },
    ash_inquisitor: {
        id: 'ash_inquisitor', name: 'Vaelen, Ash Inquisitor', maxHp: 128, atk: 21, def: 5, speed: 10, move: 3, jump: 2, range: 3, ai: 'boss', isBoss: true, zoc: false
    },
    frost_jarl: {
        id: 'frost_jarl', name: 'Jarl Skadi', maxHp: 152, atk: 24, def: 8, speed: 9, move: 4, jump: 2, range: 2, ai: 'boss', isBoss: true, zoc: true
    },
    magma_warden: {
        id: 'magma_warden', name: 'Ignar, Magma Warden', maxHp: 168, atk: 25, def: 8, speed: 8, move: 3, jump: 2, range: 2, ai: 'boss', isBoss: true, zoc: true
    },
    // Outer Frontier Raid Bosses (Tiers VI–VIII)
    dune_sovereign_boss: {
        id: 'dune_sovereign_boss', name: 'Dune Sovereign', maxHp: 235, atk: 29, def: 9, speed: 10, move: 4, jump: 2, range: 3, ai: 'boss', isBoss: true, zoc: true
    },
    astral_warden_boss: {
        id: 'astral_warden_boss', name: 'Astral Warden', maxHp: 270, atk: 32, def: 9, speed: 12, move: 5, jump: 3, range: 3, ai: 'boss', isBoss: true, zoc: true
    },
    unbroken_crown_boss: {
        id: 'unbroken_crown_boss', name: 'The Unbroken Crown', maxHp: 340, atk: 35, def: 11, speed: 12, move: 4, jump: 3, range: 3, ai: 'boss', isBoss: true, zoc: true
    },
    // Act II Expansion Bosses (Ashen Catacombs & Frostspire)
    lich_vaelen: {
        id: 'lich_vaelen', name: 'Lich Vaelen', maxHp: 158, atk: 23, def: 6, speed: 10, move: 3, jump: 2, range: 3, ai: 'boss', isBoss: true, footprintSize: 1, zoc: false
    },
    frostwyrm_rimefang: {
        id: 'frostwyrm_rimefang', name: 'Rimefang, Glacial Frostwyrm', maxHp: 245, atk: 26, def: 8, speed: 9, move: 3, jump: 2, range: 3, ai: 'boss', isBoss: true, footprintSize: 2, zoc: true
    },
    // Endgame Raid Boss & Abyssal Guardians
    ignis_titan: {
        id: 'ignis_titan', name: 'Ignis Titan', maxHp: 245, atk: 28, def: 9, speed: 8, move: 3, jump: 2, range: 2, ai: 'boss', isBoss: true, zoc: true
    },
    abyssal_sentinel: {
        id: 'abyssal_sentinel', name: 'Abyssal Sentinel', maxHp: 118, atk: 24, def: 8, speed: 9, move: 4, jump: 2, range: 2, ai: 'melee', zoc: true
    }
};
const G = 'grass';
const S = 'stone';
const H = 'hill';
const B = 'bridge';
const W = 'water';
const R = 'shrine';
const P = 'pillar';
const C = 'cracked_pillar';
const L = 'lava';
const N = 'snow';
const D = 'darkstone';
const T = 'stairs';
const V = 'void';
const M = 'lava_geyser';
const I = 'ice';
const A = 'cursed_altar';
const F = 'tall_grass';
const K = 'barricade';
export const CHAPTERS = [
    // =========================================================================
    // ACT I: SOLIS VALE & THE SILVERFEN
    // =========================================================================
    {
        id: 'border_watch',
        index: 0,
        region: 'solis_vale',
        landmark: 'watchtower',
        kind: 'story',
        difficulty: 1,
        recommendedPower: 420,
        mapX: 0.10,
        mapY: 0.39,
        requires: [],
        title: 'Border Watch',
        subtitle: 'Sunlit Meadow Outpost',
        biome: 'meadow',
        introSpeaker: 'Sir Aldric',
        introText: 'The Eclipse raiders seized the Watchtower road! Hold the high hill, let Lyra loose from cover, and reclaim our first Crownshard.',
        outroSpeaker: 'Lyra',
        outroText: 'The road is clear! Chart our next march on the World Map — cross Millers\' Ford or push directly toward Sunken Bridge.',
        rewardGold: 85,
        replayGold: 45,
        rewardEquipId: 'iron_plate',
        rewardHeroId: 'knight',
        grid: [
            [V, G, H, H, H, T, G, H, H, V],
            [G, G, T, G, F, G, K, S, H, G],
            [G, S, S, G, G, C, G, S, G, G],
            [G, S, R, G, F, G, G, H, S, G],
            [G, S, S, T, H, G, K, S, G, G],
            [G, G, F, F, G, C, F, G, G, G],
            [V, G, G, W, W, B, W, G, G, V]
        ],
        heights: [
            [0, 0, 2, 2, 2, 1, 1, 2, 2, 0],
            [0, 0, 1, 1, 0, 1, 1, 1, 2, 1],
            [0, 0, 0, 0, 0, 0, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 1, 2, 1, 1],
            [0, 0, 0, 1, 2, 1, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 0, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        ],
        heroSpawns: [[0, 2], [1, 3], [0, 4], [1, 2]],
        objective: {
            kind: 'rout',
            label: 'Rout All Enemies',
            description: 'Defeat all Eclipse raiders holding the Watchtower road.'
        },
        enemies: [
            { id: 'goblin', col: 6, row: 2 },
            { id: 'goblin', col: 7, row: 4 },
            { id: 'bone_archer', col: 8, row: 1 }
        ]
    },
    {
        id: 'miller_ford',
        index: 1,
        region: 'solis_vale',
        landmark: 'bridge',
        kind: 'special',
        difficulty: 1,
        recommendedPower: 460,
        mapX: 0.17,
        mapY: 0.54,
        requires: ['border_watch'],
        specialTag: 'Ford Ambush',
        modifierDesc: '10x7 Twin Creek Crossing · Seize 2 Supply Chests',
        title: 'Millers\' Ford',
        subtitle: 'Special: Twin Creek Crossing',
        biome: 'meadow',
        introSpeaker: 'Lyra',
        introText: 'Raiders are looting the grain wagons at Millers\' Ford! Two narrow footbridges span the creek — strike quickly and seize their supply chests.',
        outroSpeaker: 'Sir Aldric',
        outroText: 'The villagers are safe and their supply chests are ours! The southern road now links cleanly toward Sunken Bridge.',
        rewardGold: 95,
        replayGold: 50,
        rewardEquipId: 'copper_signet',
        rewardHeroId: 'archer',
        grid: [
            [V, G, G, W, W, F, H, H, G, V],
            [G, S, S, B, B, S, T, G, H, G],
            [G, H, F, W, W, G, K, G, G, G],
            [G, S, R, W, W, G, C, S, H, G],
            [G, H, F, W, W, G, K, G, G, G],
            [G, S, S, B, B, S, T, G, H, G],
            [V, G, G, W, W, F, H, H, G, V]
        ],
        heights: [
            [0, 0, 0, 0, 0, 0, 2, 2, 1, 0],
            [0, 0, 0, 0, 0, 0, 1, 1, 2, 1],
            [0, 1, 0, 0, 0, 0, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 1, 1, 2, 1],
            [0, 1, 0, 0, 0, 0, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 1, 1, 2, 1],
            [0, 0, 0, 0, 0, 0, 2, 2, 1, 0]
        ],
        heroSpawns: [[0, 1], [0, 5], [1, 2], [1, 4]],
        objective: {
            kind: 'seize',
            label: 'Seize Supply Chests',
            description: 'Claim both raided supply chests within 12 turns (or rout all foes).',
            chestTiles: [{ col: 6, row: 1 }, { col: 8, row: 5 }],
            requiredChests: 2,
            turnLimit: 12
        },
        enemies: [
            { id: 'goblin', col: 5, row: 1 },
            { id: 'goblin', col: 5, row: 5 },
            { id: 'bone_archer', col: 7, row: 0 },
            { id: 'goblin', col: 8, row: 3 }
        ]
    },
    {
        id: 'sunken_bridge',
        index: 2,
        region: 'silverfen',
        landmark: 'bridge',
        kind: 'story',
        difficulty: 2,
        recommendedPower: 520,
        mapX: 0.26,
        mapY: 0.41,
        requires: ['border_watch', 'miller_ford'],
        unlockMode: 'any',
        unlocksSlot4: true,
        title: 'Sunken Bridge',
        subtitle: 'Misty River Crossing',
        biome: 'river',
        introSpeaker: 'Vesper',
        introText: 'Ironclad Orcs surge across the old stone arches toward our River Shrine! Hold the ward for 6 turns or break their line.',
        outroSpeaker: 'Sir Aldric',
        outroText: 'The crossing is ours! Reinforcements joined our banner — you can now deploy 4 Heroes, and multiple roads branch across Solis.',
        rewardGold: 110,
        replayGold: 60,
        rewardEquipId: 'ember_wand',
        rewardHeroId: 'archer',
        grid: [
            [V, G, G, W, W, W, G, H, H, G, V],
            [G, H, S, B, B, B, S, T, G, H, G],
            [G, T, G, W, W, W, F, K, G, G, G],
            [G, R, S, W, W, W, G, C, S, H, G],
            [G, S, F, B, B, B, S, G, F, G, G],
            [G, T, G, W, W, W, F, K, G, H, G],
            [G, H, S, B, B, B, S, T, H, G, G],
            [V, G, G, W, W, W, G, G, G, G, V]
        ],
        heights: [
            [0, 0, 0, 0, 0, 0, 1, 2, 2, 1, 0],
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1],
            [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 1, 1, 1, 2, 1],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 1, 1, 1, 2, 1],
            [0, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1],
            [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0]
        ],
        heroSpawns: [[0, 1], [1, 2], [0, 6], [1, 4]],
        objective: {
            kind: 'defend',
            label: 'Defend River Shrine',
            description: 'Keep enemies off the River Shrine for 6 turns (or defeat all foes).',
            targetTurns: 6,
            protectTile: { col: 1, row: 3 },
            protectLabel: 'River Shrine'
        },
        enemies: [
            { id: 'river_troll', col: 6, row: 1 },
            { id: 'goblin', col: 6, row: 4 },
            { id: 'bone_archer', col: 8, row: 0 },
            { id: 'bog_shaman', col: 9, row: 5 }
        ]
    },
    {
        id: 'briar_hollow',
        index: 3,
        region: 'silverfen',
        landmark: 'forest',
        kind: 'special',
        difficulty: 2,
        recommendedPower: 580,
        mapX: 0.32,
        mapY: 0.28,
        requires: ['sunken_bridge'],
        specialTag: 'Forest Ambush',
        modifierDesc: '11x7 Sunken Timber Road · Mini-Boss: Grom, Briar Warlord',
        title: 'Briar Hollow',
        subtitle: 'Special: Briar Warlord Ambush',
        biome: 'meadow',
        introSpeaker: 'Lyra',
        introText: 'Grom the Briar Warlord and his scouts hold the timber ridges of Briar Hollow. Push down the sunken road and topple their warlord!',
        outroSpeaker: 'Lyra',
        outroText: 'The Briar Warlord falls and the timber road is ours! Ahead through the sunlit oaks lies the sacred Sunwell Glade.',
        rewardGold: 115,
        replayGold: 64,
        rewardEquipId: 'hunter_bow',
        rewardHeroId: 'mage',
        grid: [
            [V, H, H, P, T, H, H, T, H, H, V],
            [G, T, F, F, G, G, C, G, T, H, G],
            [G, S, S, K, G, F, G, K, S, G, G],
            [G, S, R, G, G, C, G, G, S, H, G],
            [G, S, S, K, G, F, G, K, S, G, G],
            [G, T, F, F, G, G, C, G, T, H, G],
            [V, H, H, P, T, H, H, T, H, H, V]
        ],
        heights: [
            [0, 2, 2, 2, 1, 2, 2, 2, 3, 3, 0],
            [0, 1, 0, 0, 0, 1, 1, 1, 2, 2, 1],
            [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 1, 1, 1, 2, 1],
            [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1],
            [0, 1, 0, 0, 0, 1, 1, 1, 2, 2, 1],
            [0, 2, 2, 2, 1, 2, 2, 2, 3, 3, 0]
        ],
        heroSpawns: [[0, 2], [1, 3], [0, 4], [1, 2]],
        enemies: [
            { id: 'goblin', col: 8, row: 2 },
            { id: 'briar_warlord', col: 8, row: 3 },
            { id: 'bone_archer', col: 8, row: 0 },
            { id: 'bone_archer', col: 8, row: 6 }
        ]
    },
    {
        id: 'sunwell_glade',
        index: 4,
        region: 'silverfen',
        landmark: 'shrine',
        kind: 'special',
        difficulty: 2,
        recommendedPower: 620,
        mapX: 0.40,
        mapY: 0.23,
        requires: ['briar_hollow', 'sunken_bridge'],
        unlockMode: 'any',
        specialTag: 'Shrine Trial',
        modifierDesc: '11x8 Sacred Grove · Mini-Boss: Vex, Mire Matriarch · Recruits Sera',
        title: 'Sunwell Glade',
        subtitle: 'Special: Mire Matriarch Trial',
        biome: 'meadow',
        introSpeaker: 'Lyra',
        introText: 'Vex the Mire Matriarch and a River Troll are corrupting the Sunwell shrines! Hold the healing altars and Sera of the Sun Order will pledge to our banner.',
        outroSpeaker: 'Lyra',
        outroText: 'The shrines glow again and Sera rides with us! The mountain trail now climbs north into Frostspire Highlands.',
        rewardGold: 120,
        replayGold: 68,
        rewardEquipId: 'swift_boots',
        rewardHeroId: 'cleric',
        grid: [
            [V, H, H, T, R, T, G, T, H, H, V],
            [G, F, C, G, G, P, G, G, C, F, G],
            [G, S, S, T, H, H, H, T, S, S, G],
            [G, R, S, G, H, R, H, G, S, H, G],
            [G, S, S, G, H, H, H, G, S, H, G],
            [G, S, S, T, G, P, G, T, S, S, G],
            [G, F, P, G, F, G, F, G, C, F, G],
            [V, H, H, T, W, W, W, T, H, H, V]
        ],
        heights: [
            [0, 2, 2, 1, 2, 1, 1, 1, 2, 2, 0],
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 1, 1, 2, 2, 2, 1, 1, 1, 1],
            [0, 1, 1, 1, 2, 2, 2, 1, 1, 2, 2],
            [0, 0, 1, 1, 2, 2, 2, 1, 1, 2, 2],
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 2, 2, 1, 0, 0, 0, 1, 2, 2, 0]
        ],
        heroSpawns: [[0, 2], [1, 3], [0, 5], [1, 4]],
        objective: {
            kind: 'defend',
            label: 'Defend Sunwell Altar',
            description: 'Protect the Sunwell Altar for 6 turns or defeat all raiders.',
            targetTurns: 6,
            protectTile: { col: 1, row: 3 },
            protectLabel: 'Sunwell Altar'
        },
        enemies: [
            { id: 'river_troll', col: 7, row: 2 },
            { id: 'goblin', col: 7, row: 5 },
            { id: 'bone_archer', col: 8, row: 0 },
            { id: 'bone_archer', col: 8, row: 7 },
            { id: 'mire_matriarch', col: 9, row: 3 }
        ]
    },
    // =========================================================================
    // ACT II: ASHEN CATACOMBS & FROSTSPIRE HIGHLANDS
    // =========================================================================
    {
        id: 'lantern_crypt',
        index: 5,
        region: 'ashen_catacombs',
        landmark: 'crypt',
        kind: 'story',
        difficulty: 2,
        recommendedPower: 660,
        mapX: 0.35,
        mapY: 0.56,
        requires: ['sunken_bridge'],
        title: 'Lantern Crypt',
        subtitle: 'Torchlit Catacomb Vault',
        biome: 'crypt',
        introSpeaker: 'Vesper',
        introText: 'The Crypt Warden awakens in the blue lantern mist! Use the stone pillars to break archer sightlines and cut down their commander.',
        outroSpeaker: 'Vesper',
        outroText: 'The catacombs are silent! Beyond these halls lie Whispering Barrow, the Cursed Vault, and the northern pass.',
        rewardGold: 130,
        replayGold: 72,
        rewardEquipId: 'ranger_cloak',
        rewardHeroId: 'mage',
        grid: [
            [V, D, S, S, T, D, D, S, H, H, V],
            [S, S, C, S, S, P, S, S, C, H, H],
            [S, T, S, R, S, A, S, P, S, T, S],
            [S, S, S, S, S, S, S, S, S, S, S],
            [S, S, K, S, S, C, S, S, K, S, S],
            [S, S, S, T, S, S, S, P, S, T, H],
            [S, S, C, S, S, A, S, S, C, S, H],
            [V, D, S, S, T, D, D, S, H, H, V]
        ],
        heights: [
            [0, 2, 2, 2, 1, 2, 2, 2, 2, 2, 0],
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2],
            [0, 1, 0, 1, 0, 1, 0, 1, 1, 2, 2],
            [0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1],
            [0, 1, 0, 1, 0, 1, 0, 1, 1, 2, 2],
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2],
            [0, 2, 2, 2, 1, 2, 2, 2, 2, 2, 0]
        ],
        heroSpawns: [[0, 2], [1, 3], [0, 4], [1, 5]],
        objective: {
            kind: 'assassinate',
            label: 'Slay Crypt Warden',
            description: 'Defeat the Crypt Warden leading the catacomb garrison.',
            targetEnemyIndex: 0,
            targetEnemyId: 'crypt_knight',
            targetName: 'Crypt Warden'
        },
        enemies: [
            { id: 'crypt_knight', col: 8, row: 3, name: 'Crypt Warden' },
            { id: 'orc_brute', col: 7, row: 4 },
            { id: 'bone_archer', col: 9, row: 1 },
            { id: 'bone_necromancer', col: 10, row: 6 }
        ]
    },
    {
        id: 'whispering_barrow',
        index: 6,
        region: 'ashen_catacombs',
        landmark: 'ruins',
        kind: 'special',
        difficulty: 3,
        recommendedPower: 740,
        mapX: 0.31,
        mapY: 0.70,
        requires: ['lantern_crypt'],
        specialTag: 'Barrow Raid',
        modifierDesc: '11x8 Sunken Crypt Gallery · Mini-Boss: Vaelen, Ash Inquisitor',
        title: 'Whispering Barrow',
        subtitle: 'Special: Ash Inquisitor Sanctum',
        biome: 'crypt',
        introSpeaker: 'Vesper',
        introText: 'Vaelen the Ash Inquisitor and his Bone Necromancer raise endless dead across the Whispering Barrow! Cut down the summoners before their thralls overwhelm us!',
        outroSpeaker: 'Vesper',
        outroText: 'The Inquisitor falls and the barrow bells fall silent — and we recovered a gleaming Frostbite Staff from the crypt reliquary!',
        rewardGold: 155,
        replayGold: 84,
        rewardEquipId: 'frostbite_staff',
        rewardHeroId: null,
        grid: [
            [V, D, H, D, H, D, H, D, H, H, V],
            [S, T, P, T, S, C, S, P, T, H, S],
            [S, S, S, S, A, S, S, S, S, H, S],
            [S, R, S, P, S, S, P, S, H, S, S],
            [S, S, S, S, S, A, S, S, H, S, S],
            [S, S, S, P, S, S, P, S, S, H, S],
            [S, T, P, T, S, C, S, P, T, H, S],
            [V, D, H, D, H, D, H, D, H, H, V]
        ],
        heights: [
            [0, 2, 3, 3, 3, 3, 3, 3, 3, 3, 0],
            [0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1],
            [0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 1],
            [0, 0, 0, 1, 1, 1, 1, 1, 2, 1, 1],
            [0, 0, 0, 1, 1, 1, 1, 1, 2, 1, 1],
            [0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 1],
            [0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1],
            [0, 2, 3, 3, 3, 3, 3, 3, 3, 3, 0]
        ],
        heroSpawns: [[0, 2], [1, 3], [0, 5], [1, 4]],
        enemies: [
            { id: 'crypt_knight', col: 7, row: 3 },
            { id: 'bone_archer', col: 8, row: 0, levelScale: 1.12 },
            { id: 'bone_necromancer', col: 8, row: 7, levelScale: 1.08 },
            { id: 'ash_inquisitor', col: 9, row: 4 }
        ]
    },
    {
        id: 'cursed_vault',
        index: 7,
        region: 'ashen_catacombs',
        landmark: 'vault',
        kind: 'treasure',
        difficulty: 3,
        recommendedPower: 830,
        mapX: 0.45,
        mapY: 0.64,
        requires: ['lantern_crypt'],
        specialTag: 'Treasure Vault',
        modifierDesc: '11x8 Obsidian Reliquary · War-Chest Bounty',
        title: 'Cursed Vault',
        subtitle: 'Special: Sealed Reliquary',
        biome: 'crypt',
        introSpeaker: 'Vesper',
        introText: 'An obsidian reliquary overflowing with stolen Solis gold! Dread Knights and a Bone Necromancer seal the chamber — push through their vaults and claim the seal.',
        outroSpeaker: 'Vesper',
        outroText: 'The war-chest is cracked open and Sunsteel steel gleams inside! A tunnel here climbs straight toward Emberwaste.',
        rewardGold: 220,
        replayGold: 95,
        rewardEquipId: 'sunsteel_blade',
        rewardHeroId: null,
        grid: [
            [V, S, D, D, S, D, D, S, D, S, V],
            [S, P, T, T, S, C, S, T, T, P, S],
            [S, T, S, H, S, K, S, H, S, S, S],
            [S, S, R, H, S, S, S, H, A, S, S],
            [S, S, S, H, S, S, S, H, S, S, S],
            [S, T, S, H, S, K, S, H, S, S, S],
            [S, P, T, T, S, C, S, T, T, P, S],
            [V, S, D, D, S, D, D, S, D, S, V]
        ],
        heights: [
            [0, 1, 2, 2, 1, 2, 2, 1, 2, 1, 0],
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 1, 1, 2, 1, 1, 1, 2, 1, 1, 1],
            [0, 1, 1, 2, 1, 1, 1, 2, 1, 1, 1],
            [0, 1, 1, 2, 1, 1, 1, 2, 1, 1, 1],
            [0, 1, 1, 2, 1, 1, 1, 2, 1, 1, 1],
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 1, 2, 2, 1, 2, 2, 1, 2, 1, 0]
        ],
        heroSpawns: [[0, 2], [0, 5], [1, 3], [1, 4]],
        objective: {
            kind: 'seize',
            label: 'Seize Reliquary Seal',
            description: 'Reach the Reliquary Seal within 12 turns. Optional chests hold bonus gold!',
            goalTile: { col: 10, row: 3 },
            goalLabel: 'Reliquary Seal',
            chestTiles: [{ col: 4, row: 1 }, { col: 8, row: 6 }],
            requiredChests: 0,
            turnLimit: 12
        },
        enemies: [
            { id: 'crypt_knight', col: 7, row: 3, levelScale: 1.08 },
            { id: 'crypt_knight', col: 7, row: 4, levelScale: 1.08 },
            { id: 'bone_archer', col: 9, row: 2, levelScale: 1.1 },
            { id: 'bone_necromancer', col: 9, row: 5, levelScale: 1.08 }
        ]
    },
    {
        id: 'frostspire_pass',
        index: 8,
        region: 'frostspire',
        landmark: 'pass',
        kind: 'story',
        difficulty: 3,
        recommendedPower: 790,
        mapX: 0.48,
        mapY: 0.31,
        requires: ['sunwell_glade', 'lantern_crypt'],
        unlockMode: 'any',
        title: 'Frostspire Pass',
        subtitle: 'Glacial Alpine Ridge',
        biome: 'frost',
        introSpeaker: 'Lyra',
        introText: 'Frost Golems and swift Ice Wraiths guard the broad mountain stairs! Watch your flanks — the Wraiths slip right past Zones of Control and punish chilled targets.',
        outroSpeaker: 'Sir Aldric',
        outroText: 'The pass is ours and Kael joins our banner! Explore Mirror Tarn and Glacial Citadel, or march east to Obsidian Gate.',
        rewardGold: 165,
        replayGold: 90,
        rewardEquipId: 'runed_mail',
        rewardHeroId: 'rogue',
        grid: [
            [V, V, H, H, N, T, H, H, N, H, H, V],
            [N, S, T, C, N, N, H, T, S, T, H, H],
            [N, S, R, I, T, S, I, S, I, T, N, H],
            [W, W, N, I, P, I, S, C, S, S, H, H],
            [N, S, N, I, S, I, S, P, I, S, H, N],
            [N, S, T, N, N, H, T, S, N, T, S, N],
            [N, N, S, C, N, N, H, S, N, S, N, N],
            [V, N, N, V, W, W, N, N, V, N, V, V]
        ],
        heights: [
            [0, 0, 2, 2, 2, 2, 3, 3, 3, 4, 4, 0],
            [0, 0, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4],
            [0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 4],
            [0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3],
            [0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3],
            [0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3],
            [0, 0, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3],
            [0, 0, 1, 0, 0, 0, 2, 2, 0, 2, 0, 0]
        ],
        heroSpawns: [[0, 1], [1, 2], [0, 5], [1, 6]],
        enemies: [
            { id: 'frost_golem', col: 7, row: 2 },
            { id: 'frost_golem', col: 8, row: 5 },
            { id: 'ice_wraith', col: 10, row: 1, levelScale: 1.12 },
            { id: 'ice_wraith', col: 10, row: 4, levelScale: 1.12 }
        ]
    },
    {
        id: 'frozen_lake',
        index: 9,
        region: 'frostspire',
        landmark: 'lake',
        kind: 'special',
        difficulty: 3,
        recommendedPower: 880,
        mapX: 0.55,
        mapY: 0.19,
        requires: ['frostspire_pass'],
        specialTag: 'Frozen Island',
        modifierDesc: '12x8 Ice-Ringed Shrine Island · Twin Bridges',
        title: 'Mirror Tarn',
        subtitle: 'Special: Frozen Shrine Island',
        biome: 'frost',
        introSpeaker: 'Lyra',
        introText: 'An icy moat encircles a lone highland shrine! Ice Wraiths haunt the frozen bridges while a Frost Golem anchors the central crown.',
        outroSpeaker: 'Lyra',
        outroText: 'Mirror Tarn gleams beneath the snow! Skyhawk Crest is ours — giving our ranged scouts unmatched reach.',
        rewardGold: 185,
        replayGold: 100,
        rewardEquipId: 'eagle_charm',
        rewardHeroId: null,
        grid: [
            [V, N, H, H, I, I, I, I, H, H, N, V],
            [N, S, S, W, B, B, B, B, W, S, S, N],
            [N, N, W, W, T, S, S, T, W, W, N, N],
            [N, B, B, T, S, R, H, S, T, B, B, H],
            [N, B, B, T, S, H, H, S, T, B, B, H],
            [N, N, W, W, T, S, S, T, W, W, N, N],
            [N, S, S, W, B, B, B, B, W, S, S, N],
            [V, N, H, H, I, I, I, I, H, H, N, V]
        ],
        heights: [
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
            [0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1],
            [0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1],
            [0, 0, 0, 1, 1, 2, 3, 2, 1, 1, 1, 2],
            [0, 0, 0, 1, 1, 2, 3, 2, 1, 1, 1, 2],
            [0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1],
            [0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1],
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0]
        ],
        heroSpawns: [[0, 2], [0, 3], [0, 4], [1, 3]],
        objective: {
            kind: 'seize',
            label: 'Seize Mirror Shrine',
            description: 'Claim the central Mirror Shrine within 11 turns (or rout all foes).',
            goalTile: { col: 5, row: 3 },
            goalLabel: 'Mirror Shrine',
            turnLimit: 11
        },
        enemies: [
            { id: 'frost_golem', col: 6, row: 3, levelScale: 1.12 },
            { id: 'ice_wraith', col: 9, row: 1, levelScale: 1.10 },
            { id: 'ice_wraith', col: 9, row: 6, levelScale: 1.10 },
            { id: 'bog_shaman', col: 10, row: 4, levelScale: 1.15 }
        ]
    },
    {
        id: 'glacial_citadel',
        index: 10,
        region: 'frostspire',
        landmark: 'citadel',
        kind: 'elite',
        difficulty: 4,
        recommendedPower: 1080,
        mapX: 0.64,
        mapY: 0.24,
        requires: ['frostspire_pass', 'frozen_lake'],
        unlockMode: 'any',
        specialTag: 'Elite Siege',
        modifierDesc: '13x8 Twin-Bridge Siege · Mini-Boss: Jarl Skadi · Epic Halberd',
        title: 'Glacial Citadel',
        subtitle: 'Special: Elite Ice Stronghold',
        biome: 'frost',
        introSpeaker: 'Sir Aldric',
        introText: 'Jarl Skadi commands this elite stronghold perched over twin ice chasms! Bring down the Frostborn Jarl to shatter the garrison and claim the Dragonfang Halberd!',
        outroSpeaker: 'Lyra',
        outroText: 'Jarl Skadi yields the Dragonfang Halberd! Our champions are truly forged for the Throne.',
        rewardGold: 240,
        replayGold: 130,
        rewardEquipId: 'dragonfang_spear',
        rewardHeroId: null,
        grid: [
            [V, H, N, N, V, V, V, N, H, H, H, N, V],
            [N, S, S, S, B, B, B, S, K, T, S, H, H],
            [N, R, I, N, V, V, V, I, T, H, S, S, N],
            [N, S, I, S, B, B, B, S, H, T, S, H, N],
            [N, N, I, N, V, V, V, I, H, T, S, H, N],
            [N, S, S, S, B, B, B, S, P, T, S, H, H],
            [N, H, I, N, V, V, V, N, C, S, H, N, N],
            [V, H, N, N, V, V, V, N, H, H, H, N, V]
        ],
        heights: [
            [0, 1, 1, 1, 0, 0, 0, 1, 2, 3, 3, 3, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 3, 4, 4],
            [0, 0, 1, 1, 0, 0, 0, 1, 2, 3, 3, 3, 3],
            [0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 3, 3, 3],
            [0, 0, 1, 1, 0, 0, 0, 1, 2, 2, 3, 3, 3],
            [0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 3, 4, 4],
            [0, 1, 1, 1, 0, 0, 0, 1, 2, 2, 3, 3, 3],
            [0, 1, 1, 1, 0, 0, 0, 1, 2, 3, 3, 3, 0]
        ],
        heroSpawns: [[0, 1], [1, 2], [0, 5], [1, 4]],
        objective: {
            kind: 'assassinate',
            label: 'Slay Jarl Skadi',
            description: 'Defeat Jarl Skadi commanding the Glacial Citadel.',
            targetEnemyIndex: 2,
            targetEnemyId: 'frost_jarl',
            targetName: 'Jarl Skadi'
        },
        enemies: [
            { id: 'frost_golem', col: 7, row: 1, levelScale: 1.15 },
            { id: 'frost_golem', col: 7, row: 5, levelScale: 1.15 },
            { id: 'frost_jarl', col: 10, row: 3, levelScale: 1.05, name: 'Jarl Skadi' },
            { id: 'ice_wraith', col: 11, row: 1, levelScale: 1.18 },
            { id: 'ice_wraith', col: 11, row: 6, levelScale: 1.18 }
        ]
    },
    // =========================================================================
    // ACT III: EMBERWASTE CALDERA & ECLIPSE DOMINION
    // =========================================================================
    {
        id: 'obsidian_gate',
        index: 11,
        region: 'emberwaste',
        landmark: 'gate',
        kind: 'story',
        difficulty: 4,
        recommendedPower: 960,
        mapX: 0.58,
        mapY: 0.49,
        requires: ['frostspire_pass', 'cursed_vault'],
        unlockMode: 'any',
        title: 'Obsidian Gate',
        subtitle: 'Volcanic Ember Bastion',
        biome: 'volcano',
        introSpeaker: 'Sir Aldric',
        introText: 'Ember Pyromancers rain fire across the molten causeway! Hold the Ember Ward for 6 turns against Malakor\'s vanguard or shatter their line.',
        outroSpeaker: 'Vesper',
        outroText: 'The outer bastion falls and Dame Isolde joins our vanguard! Raid Ashfall Foundry or storm the Eclipse Throne!',
        rewardGold: 210,
        replayGold: 115,
        rewardEquipId: 'blood_amulet',
        rewardHeroId: 'paladin',
        grid: [
            [V, D, D, L, L, L, D, H, H, D, H, V],
            [D, S, S, B, B, B, S, T, D, H, H, H],
            [D, R, D, L, P, L, M, D, H, T, D, D],
            [D, S, S, B, B, B, S, T, M, D, D, H],
            [D, D, D, L, L, L, M, C, D, H, T, D],
            [D, S, S, B, B, B, S, T, D, D, H, H],
            [D, D, H, L, P, L, D, P, T, H, H, D],
            [V, H, D, V, V, V, D, D, D, D, D, V]
        ],
        heights: [
            [0, 1, 1, 0, 0, 0, 1, 2, 3, 3, 3, 0],
            [0, 1, 1, 1, 1, 1, 1, 2, 2, 3, 4, 4],
            [0, 1, 1, 0, 1, 0, 1, 2, 3, 3, 3, 3],
            [0, 1, 1, 1, 1, 1, 1, 2, 2, 3, 3, 3],
            [0, 1, 1, 0, 0, 0, 1, 2, 2, 3, 3, 3],
            [0, 1, 1, 1, 1, 1, 1, 2, 2, 3, 3, 4],
            [0, 1, 2, 0, 1, 0, 1, 2, 2, 3, 4, 3],
            [0, 2, 1, 0, 0, 0, 1, 2, 2, 2, 2, 0]
        ],
        heroSpawns: [[0, 1], [1, 1], [0, 5], [1, 3]],
        objective: {
            kind: 'defend',
            label: 'Defend Ember Ward',
            description: 'Protect the Ember Ward for 6 turns or defeat all foes.',
            targetTurns: 6,
            protectTile: { col: 1, row: 2 },
            protectLabel: 'Ember Ward'
        },
        enemies: [
            { id: 'crypt_knight', col: 6, row: 1, levelScale: 1.15 },
            { id: 'orc_brute', col: 6, row: 3, levelScale: 1.18 },
            { id: 'orc_brute', col: 8, row: 5, levelScale: 1.2 },
            { id: 'ember_pyromancer', col: 10, row: 1, levelScale: 1.15 },
            { id: 'ember_pyromancer', col: 10, row: 6, levelScale: 1.15 }
        ]
    },
    {
        id: 'ashfall_foundry',
        index: 12,
        region: 'emberwaste',
        landmark: 'foundry',
        kind: 'treasure',
        difficulty: 4,
        recommendedPower: 1120,
        mapX: 0.65,
        mapY: 0.63,
        requires: ['obsidian_gate'],
        specialTag: 'Magma Vault',
        modifierDesc: '12x9 Magma Forge · Mini-Boss: Ignar, Magma Warden · Frostguard Plate',
        title: 'Ashfall Foundry',
        subtitle: 'Special: Magma Warden Forge',
        biome: 'volcano',
        introSpeaker: 'Sir Aldric',
        introText: 'Ignar the Magma Warden and his Ember Pyromancers guard Malakor\'s war-forges! Seize the central anvil shrine and claim their masterwork plate armor.',
        outroSpeaker: 'Sir Aldric',
        outroText: 'Ignar\'s forge goes cold and Frostguard Plate gleams in our hands — we are ready for Archon Malakor!',
        rewardGold: 270,
        replayGold: 140,
        rewardEquipId: 'frostguard_plate',
        rewardHeroId: null,
        grid: [
            [V, D, L, L, B, B, B, L, L, D, D, V],
            [D, S, S, T, D, M, D, T, S, H, D, D],
            [L, S, T, C, T, D, T, P, T, S, L, D],
            [L, T, S, D, T, D, T, D, S, T, L, D],
            [B, S, S, T, D, R, D, T, S, S, B, H],
            [L, T, S, D, T, D, T, D, S, T, L, D],
            [L, S, T, P, T, D, T, C, T, S, L, D],
            [D, S, S, T, D, M, D, T, S, H, D, D],
            [V, D, L, L, B, B, B, L, L, D, D, V]
        ],
        heights: [
            [0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0],
            [0, 1, 1, 1, 2, 2, 2, 2, 2, 3, 2, 2],
            [0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 0, 2],
            [0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 0, 2],
            [0, 1, 1, 2, 2, 3, 2, 2, 2, 2, 2, 3],
            [0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 0, 2],
            [0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 0, 2],
            [0, 1, 1, 1, 2, 2, 2, 2, 2, 3, 2, 2],
            [0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0]
        ],
        heroSpawns: [[0, 4], [1, 1], [1, 4], [1, 7]],
        objective: {
            kind: 'seize',
            label: 'Seize Anvil Shrine',
            description: 'Claim the central Anvil Shrine within 12 turns. Armory chests grant bonus gold!',
            goalTile: { col: 5, row: 4 },
            goalLabel: 'Anvil Shrine',
            chestTiles: [{ col: 5, row: 1 }, { col: 5, row: 7 }],
            requiredChests: 0,
            turnLimit: 12
        },
        enemies: [
            { id: 'magma_warden', col: 7, row: 4, levelScale: 1.05 },
            { id: 'crypt_knight', col: 8, row: 1, levelScale: 1.18 },
            { id: 'orc_brute', col: 8, row: 7, levelScale: 1.2 },
            { id: 'ember_pyromancer', col: 11, row: 4, levelScale: 1.15 },
            { id: 'ember_pyromancer', col: 9, row: 2, levelScale: 1.15 }
        ]
    },
    {
        id: 'eclipse_throne',
        index: 13,
        region: 'eclipse_dominion',
        landmark: 'throne',
        kind: 'boss',
        difficulty: 5,
        recommendedPower: 1240,
        mapX: 0.70,
        mapY: 0.40,
        requires: ['obsidian_gate'],
        specialTag: 'Act III Boss',
        modifierDesc: '13x9 Grand Cathedral · Boss: Archon Malakor',
        unlocksEndless: true,
        title: 'Eclipse Throne',
        subtitle: 'Boss: Archon Malakor',
        biome: 'throne',
        introSpeaker: 'Archon Malakor',
        introText: 'Fools of Solis! Your fragile vanguard dares challenge the Eclipse? Watch your precious Crown turn to cinders!',
        outroSpeaker: 'Sir Aldric',
        outroText: 'The Sunstone Crown is reforged and the Ashen Rift seals at last! Solis stands free — and Endless Arena skirmishes now await your champions.',
        rewardGold: 360,
        replayGold: 175,
        rewardEquipId: 'solis_crownblade',
        rewardHeroId: 'champion',
        grid: [
            [V, V, S, S, H, H, H, H, S, S, V, V, V],
            [V, S, C, A, T, S, S, P, S, H, H, V, V],
            [D, S, S, S, T, H, M, T, H, S, H, D, V],
            [D, R, S, S, S, T, S, T, H, H, S, D, D],
            [D, S, S, S, S, T, S, T, H, H, H, D, D],
            [D, S, S, S, S, T, S, T, H, H, S, D, D],
            [D, S, S, S, T, H, M, T, H, S, H, D, V],
            [V, S, P, A, T, S, S, C, S, H, H, V, V],
            [V, V, S, S, L, L, L, L, S, S, V, V, V]
        ],
        heights: [
            [0, 0, 1, 1, 2, 2, 2, 2, 2, 2, 0, 0, 0],
            [0, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 0, 0],
            [0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 3, 0],
            [0, 1, 1, 1, 1, 2, 2, 3, 4, 4, 3, 3, 3],
            [0, 0, 1, 1, 1, 2, 2, 3, 4, 4, 4, 3, 3],
            [0, 1, 1, 1, 1, 2, 2, 3, 4, 4, 3, 3, 3],
            [0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 3, 0],
            [0, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 0, 0],
            [0, 0, 1, 1, 0, 0, 0, 0, 2, 2, 0, 0, 0]
        ],
        heroSpawns: [[0, 3], [1, 3], [0, 5], [1, 5]],
        objective: {
            kind: 'assassinate',
            label: 'Slay Archon Malakor',
            description: 'Defeat Archon Malakor to shatter the Eclipse Vanguard!',
            targetEnemyIndex: 0,
            targetEnemyId: 'eclipse_archon',
            targetName: 'Archon Malakor'
        },
        enemies: [
            { id: 'eclipse_archon', col: 10, row: 4 },
            { id: 'crypt_knight', col: 8, row: 3 },
            { id: 'crypt_knight', col: 8, row: 5 },
            { id: 'bone_necromancer', col: 11, row: 2, levelScale: 1.15 },
            { id: 'ember_pyromancer', col: 11, row: 6, levelScale: 1.15 }
        ]
    },
    // =========================================================================
    // ACT I / II EXPANSION LOCATIONS — SOLIS VALE & THE SILVERFEN
    // =========================================================================
    {
        id: 'oakhaven_market',
        index: 14,
        region: 'solis_vale',
        landmark: 'town',
        kind: 'town',
        difficulty: 1,
        recommendedPower: 480,
        mapX: 0.15,
        mapY: 0.24,
        requires: ['border_watch'],
        specialTag: 'Trade Hub',
        modifierDesc: '11x8 Guild Plaza · Seize 2 Stolen Caravan Chests · Unlocks Oakhaven Exchange Discount',
        title: 'Oakhaven City',
        subtitle: 'Free Trade Hub & Guild Hall',
        biome: 'meadow',
        introSpeaker: 'Sir Aldric',
        introText: 'Eclipse brigands have breached Oakhaven\'s Guild Plaza! Smash their market barricades, hold the sanctuary fountain, and reclaim both stolen caravan chests.',
        outroSpeaker: 'Lyra',
        outroText: 'The Guild Plaza is secure! Oakhaven\'s merchant masters now grant us a 20% Guild Patron discount on Dust, Shards, and Relic Caravan crates.',
        rewardGold: 130,
        replayGold: 60,
        rewardEquipId: 'acolyte_robe',
        rewardHeroId: null,
        grid: [
            [V, H, H, T, S, S, S, T, H, H, V],
            [S, S, S, S, K, S, S, K, S, S, H],
            [G, S, S, R, S, S, P, S, S, S, S],
            [G, S, F, S, S, C, S, S, S, T, H],
            [G, S, S, S, K, S, S, K, S, T, H],
            [G, S, F, S, P, S, S, S, S, S, S],
            [S, F, S, S, S, C, S, S, S, S, H],
            [V, G, G, T, H, H, H, T, S, S, V]
        ],
        heights: [
            [0, 2, 2, 1, 1, 1, 1, 1, 2, 2, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 2],
            [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 2],
            [0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 2],
            [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2],
            [0, 0, 0, 1, 2, 2, 2, 1, 1, 1, 0]
        ],
        heroSpawns: [[0, 2], [0, 3], [0, 4], [1, 3]],
        objective: {
            kind: 'seize',
            label: 'Reclaim Caravan Chests',
            description: 'Seize both raided Guild Caravan chests within 12 turns (or rout all raiders).',
            chestTiles: [{ col: 7, row: 2 }, { col: 8, row: 6 }],
            requiredChests: 2,
            turnLimit: 12
        },
        enemies: [
            { id: 'goblin', col: 6, row: 3, name: 'Guild Raider' },
            { id: 'goblin', col: 7, row: 5, name: 'Market Cutthroat' },
            { id: 'bone_archer', col: 8, row: 0, name: 'Balcony Marksman' },
            { id: 'orc_brute', col: 9, row: 3, name: 'Caravan Bruiser' }
        ]
    },
    {
        id: 'galewind_windmill',
        index: 15,
        region: 'solis_vale',
        landmark: 'watchtower',
        kind: 'special',
        difficulty: 2,
        recommendedPower: 560,
        mapX: 0.22,
        mapY: 0.17,
        requires: ['oakhaven_market', 'briar_hollow'],
        unlockMode: 'any',
        specialTag: 'Galewind Ridge',
        modifierDesc: '12x8 Terraced Windmill Cliff · Galewind Gust pushes Height 2+ units 1 tile west every 2 rounds',
        title: 'Galewind Ridge',
        subtitle: 'Vertical Windmill Siege',
        biome: 'meadow',
        introSpeaker: 'Lyra',
        introText: 'Fierce westerly gales howl across the windmill terraces every two rounds! Watch your footing on Height 2+ ledges — or shove Eclipse archers straight into the wind.',
        outroSpeaker: 'Lyra',
        outroText: 'The highland windmills turn under Solis banners once more — and we recovered swift Gale Striders from the ridge keep!',
        rewardGold: 135,
        replayGold: 70,
        rewardEquipId: 'recurved_bow',
        rewardHeroId: null,
        grid: [
            [V, V, G, G, T, H, H, H, T, H, H, V],
            [G, G, G, T, H, P, H, H, H, H, H, H],
            [G, S, S, T, H, H, T, H, C, H, P, H],
            [G, R, S, S, T, H, H, T, H, H, H, H],
            [G, S, S, T, H, H, T, H, H, P, H, H],
            [G, F, S, K, H, P, H, T, H, H, T, H],
            [G, F, G, T, H, H, C, H, H, H, H, H],
            [V, V, G, G, T, H, H, H, V, V, V, V]
        ],
        heights: [
            [0, 0, 0, 0, 1, 2, 2, 2, 2, 3, 3, 0],
            [0, 0, 0, 1, 2, 2, 2, 2, 3, 3, 3, 3],
            [0, 0, 0, 1, 2, 2, 2, 3, 3, 3, 3, 3],
            [0, 0, 0, 1, 1, 2, 2, 2, 3, 3, 3, 3],
            [0, 0, 0, 1, 2, 2, 2, 3, 3, 3, 3, 3],
            [0, 0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3],
            [0, 0, 0, 1, 2, 2, 2, 2, 2, 3, 3, 3],
            [0, 0, 0, 0, 1, 2, 2, 2, 0, 0, 0, 0]
        ],
        heroSpawns: [[0, 2], [0, 3], [0, 4], [1, 3]],
        objective: {
            kind: 'rout',
            label: 'Clear Windmill Ramparts',
            description: 'Rout all Eclipse raiders across the terraced windmill cliff while weathering Galewind Gusts.'
        },
        enemies: [
            { id: 'goblin', col: 6, row: 3 },
            { id: 'orc_brute', col: 7, row: 4 },
            { id: 'goblin', col: 8, row: 1 },
            { id: 'bone_archer', col: 10, row: 0 },
            { id: 'bone_archer', col: 10, row: 5 }
        ]
    },
    {
        id: 'emerald_delta',
        index: 16,
        region: 'silverfen',
        landmark: 'lake',
        kind: 'special',
        difficulty: 3,
        recommendedPower: 720,
        mapX: 0.25,
        mapY: 0.62,
        requires: ['miller_ford', 'sunken_bridge'],
        unlockMode: 'any',
        specialTag: 'Rising Tide',
        modifierDesc: '12x8 Flooded Marsh Islands · Low-tide fords flood every 2 rounds · River Trolls & Shamans',
        title: 'Emerald Delta',
        subtitle: 'Flooded Marsh Raid',
        biome: 'river',
        introSpeaker: 'Vesper',
        introText: 'The Silverfen tide surges every two rounds, swallowing the northern and southern timber fords! Cross cleanly before the waters rise and purge the River Trolls.',
        outroSpeaker: 'Vesper',
        outroText: 'The marsh tide recedes and the delta islets are free — Runed Chainmail recovered from the sunken sluice!',
        rewardGold: 160,
        replayGold: 85,
        rewardEquipId: 'sunweave_robe',
        rewardHeroId: null,
        grid: [
            [V, G, G, W, W, G, H, H, W, G, G, V],
            [G, S, S, B, B, F, T, S, B, S, G, G],
            [G, R, G, W, W, S, H, F, W, F, H, G],
            [G, S, S, B, B, S, T, S, B, S, G, G],
            [G, S, F, B, B, S, T, S, B, S, G, G],
            [G, F, G, W, W, F, P, S, W, S, H, G],
            [G, S, S, B, B, G, S, T, B, S, G, G],
            [V, G, G, W, W, G, H, S, W, G, G, V]
        ],
        heights: [
            [0, 0, 0, 0, 0, 1, 2, 2, 0, 1, 1, 0],
            [0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1],
            [0, 0, 0, 0, 0, 1, 2, 1, 0, 1, 2, 1],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 2, 1],
            [0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1],
            [0, 0, 0, 0, 0, 1, 2, 1, 0, 1, 1, 0]
        ],
        heroSpawns: [[0, 1], [0, 3], [0, 4], [1, 3]],
        objective: {
            kind: 'rout',
            label: 'Purge Emerald Delta',
            description: 'Defeat all River Trolls and Eclipse Shamans across the tidal marsh islands.'
        },
        enemies: [
            { id: 'river_troll', col: 6, row: 2 },
            { id: 'goblin', col: 6, row: 6 },
            { id: 'bog_shaman', col: 7, row: 0 },
            { id: 'river_troll', col: 9, row: 5 },
            { id: 'bog_shaman', col: 10, row: 2 }
        ]
    },
    {
        id: 'sunken_monastery',
        index: 17,
        region: 'silverfen',
        landmark: 'shrine',
        kind: 'elite',
        difficulty: 3,
        recommendedPower: 780,
        mapX: 0.38,
        mapY: 0.41,
        requires: ['sunwell_glade', 'lantern_crypt'],
        unlockMode: 'any',
        specialTag: 'Relic Defense',
        modifierDesc: '12x9 Abbey Courtyard · Defend Relic Altar 6 Turns · Reinforcements on Rounds 2, 4 & 5',
        title: 'Solis Monastery',
        subtitle: 'Wave-Defense Sanctum',
        biome: 'river',
        introSpeaker: 'Sir Aldric',
        introText: 'Eclipse zealots storm the abbey cloisters! Guard the central Relic Altar for 6 turns as fresh reinforcement waves breach the outer gates on rounds 2, 4, and 5.',
        outroSpeaker: 'Sir Aldric',
        outroText: 'The abbey bells ring unbroken across the Silverfen! The monks entrust us with the legendary Aegis of Dawn.',
        rewardGold: 190,
        replayGold: 95,
        rewardEquipId: 'astral_vestments',
        rewardHeroId: null,
        grid: [
            [V, G, S, H, H, T, T, H, H, S, G, V],
            [G, S, P, S, S, S, S, S, S, P, S, G],
            [G, S, S, S, T, S, S, T, S, S, S, G],
            [S, S, S, T, S, S, S, S, T, S, S, S],
            [S, T, S, S, S, S, R, S, S, S, T, S],
            [S, S, S, T, S, S, S, S, T, S, S, S],
            [G, S, S, S, T, S, S, T, S, S, S, G],
            [G, S, P, S, S, K, K, S, S, P, S, G],
            [V, G, S, W, S, S, S, S, W, S, G, V]
        ],
        heights: [
            [0, 0, 1, 2, 2, 1, 1, 2, 2, 1, 0, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
            [0, 0, 1, 1, 1, 2, 2, 1, 1, 1, 0, 0],
            [0, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 0],
            [0, 1, 1, 2, 2, 2, 2, 2, 2, 1, 1, 0],
            [0, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 0],
            [0, 0, 1, 1, 1, 2, 2, 1, 1, 1, 0, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
            [0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0]
        ],
        heroSpawns: [[5, 4], [6, 3], [6, 5], [7, 4]],
        objective: {
            kind: 'defend',
            label: 'Defend Relic Altar',
            description: 'Keep Eclipse waves off the central Relic Altar for 6 turns (or rout all foes).',
            targetTurns: 6,
            protectTile: { col: 6, row: 4 },
            protectLabel: 'Relic Altar'
        },
        enemies: [
            { id: 'crypt_knight', col: 1, row: 4 },
            { id: 'bog_shaman', col: 10, row: 4 },
            { id: 'bone_archer', col: 1, row: 1 },
            { id: 'bone_archer', col: 10, row: 7 }
        ]
    },
    // =========================================================================
    // UPCOMING EXPANSION LOCATIONS ("SOON...") — FUTURE ACTS, RAIDS & FRONTIERS
    // =========================================================================
    {
        id: 'gloomwood_heart',
        index: 18,
        region: 'ashen_catacombs',
        landmark: 'forest',
        kind: 'special',
        difficulty: 3,
        recommendedPower: 810,
        mapX: 0.20,
        mapY: 0.73,
        requires: ['whispering_barrow', 'emerald_delta'],
        unlockMode: 'any',
        specialTag: 'Fog Stalker Hunt',
        modifierDesc: '12x8 Haunted Timberlands · Innate Fog of War · Tall Grass Ambush',
        title: 'Gloomwood',
        subtitle: 'Fog-of-War Stalker Hunt',
        biome: 'crypt',
        introSpeaker: 'Lyra',
        introText: 'Lantern light barely reaches four paces in the Gloomwood! Advance cautiously through the brush, spot the stalkers in the mist, and cut down their Dread Knight captain.',
        outroSpeaker: 'Lyra',
        outroText: 'The stalker captain falls and the mists part! We recovered a gleaming Skyhawk Crest from the cursed grove.',
        rewardGold: 175,
        replayGold: 92,
        rewardEquipId: 'stalker_leathers',
        rewardHeroId: null,
        innateMutators: ['fog_of_war'],
        grid: [
            [V, D, F, H, P, H, F, H, P, F, D, V],
            [S, F, T, S, F, T, S, F, T, S, F, H],
            [S, R, F, P, A, F, S, C, S, D, D, D],
            [S, S, F, S, S, F, P, S, F, S, S, S],
            [S, S, F, S, S, F, S, S, F, P, S, S],
            [S, F, S, P, S, F, A, C, S, F, D, D],
            [S, F, T, S, F, T, S, F, T, S, F, H],
            [V, D, F, H, P, H, F, H, P, F, D, V]
        ],
        heights: [
            [0, 1, 1, 2, 2, 2, 1, 2, 2, 1, 2, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2],
            [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2],
            [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2],
            [0, 1, 1, 2, 2, 2, 1, 2, 2, 1, 2, 0]
        ],
        heroSpawns: [[0, 2], [0, 3], [0, 4], [1, 4]],
        objective: {
            kind: 'assassinate',
            label: 'Hunt Gloom Stalker',
            description: 'Track and slay the Gloom Stalker Captain lurking beyond the Fog of War.',
            targetEnemyIndex: 0,
            targetEnemyId: 'crypt_knight',
            targetName: 'Gloom Stalker Captain'
        },
        enemies: [
            { id: 'crypt_knight', col: 9, row: 3, levelScale: 1.12, name: 'Gloom Stalker Captain' },
            { id: 'bone_archer', col: 8, row: 1, levelScale: 1.08 },
            { id: 'bone_archer', col: 8, row: 6, levelScale: 1.08 },
            { id: 'bone_necromancer', col: 11, row: 4, levelScale: 1.08 }
        ]
    },
    {
        id: 'bone_cathedral',
        index: 19,
        region: 'ashen_catacombs',
        landmark: 'crypt',
        kind: 'boss',
        difficulty: 4,
        recommendedPower: 1020,
        mapX: 0.42,
        mapY: 0.77,
        requires: ['whispering_barrow', 'cursed_vault'],
        unlockMode: 'any',
        specialTag: 'Cathedral Boss',
        modifierDesc: '12x9 Gothic Crypt Nave · Mini-Boss: Lich Vaelen (Necromancy + Soul Nova)',
        title: 'Ash Cathedral',
        subtitle: 'Mini-Boss: Lich Vaelen',
        biome: 'crypt',
        introSpeaker: 'Vesper',
        introText: 'Lich Vaelen presides atop the high altar dais of Ash Cathedral! Break through his Dread Knights and shatter the Lich before his Bone Thralls and Cursed-Soul Nova consume the nave!',
        outroSpeaker: 'Vesper',
        outroText: 'Lich Vaelen\'s phylactery shatters in emerald ash! The cathedral vaults yield a Frostbite Staff and silence at last.',
        rewardGold: 260,
        replayGold: 130,
        rewardEquipId: 'glacier_raiment',
        rewardHeroId: null,
        grid: [
            [V, V, D, S, S, A, S, S, D, D, V, V],
            [V, S, P, S, T, S, S, T, P, D, D, V],
            [S, S, S, T, D, S, T, D, D, D, D, D],
            [S, S, S, S, T, D, D, D, D, H, D, D],
            [S, R, S, S, S, T, D, D, D, H, H, D],
            [S, S, S, S, T, D, D, D, D, H, D, D],
            [S, S, S, T, D, S, T, D, D, D, D, D],
            [V, S, P, S, T, S, S, T, P, D, D, V],
            [V, V, D, S, S, A, S, S, D, D, V, V]
        ],
        heights: [
            [0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 0, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 0],
            [0, 0, 0, 1, 1, 1, 2, 2, 2, 2, 3, 3],
            [0, 0, 0, 0, 1, 2, 2, 2, 2, 3, 3, 3],
            [0, 0, 0, 0, 1, 2, 2, 2, 2, 3, 3, 3],
            [0, 0, 0, 0, 1, 2, 2, 2, 2, 3, 3, 3],
            [0, 0, 0, 1, 1, 1, 2, 2, 2, 2, 3, 3],
            [0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 0],
            [0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 0, 0]
        ],
        heroSpawns: [[0, 3], [0, 4], [0, 5], [1, 3]],
        objective: {
            kind: 'assassinate',
            label: 'Slay Lich Vaelen',
            description: 'Defeat Lich Vaelen atop the elevated cathedral altar dais.',
            targetEnemyIndex: 0,
            targetEnemyId: 'lich_vaelen',
            targetName: 'Lich Vaelen'
        },
        enemies: [
            { id: 'lich_vaelen', col: 10, row: 4, name: 'Lich Vaelen' },
            { id: 'crypt_knight', col: 7, row: 3, levelScale: 1.08 },
            { id: 'crypt_knight', col: 7, row: 5, levelScale: 1.08 },
            { id: 'bone_archer', col: 8, row: 0, levelScale: 1.10 },
            { id: 'bone_archer', col: 8, row: 8, levelScale: 1.10 }
        ]
    },
    {
        id: 'runeforge_peak',
        index: 20,
        region: 'frostspire',
        landmark: 'peak',
        kind: 'treasure',
        difficulty: 4,
        recommendedPower: 1050,
        mapX: 0.46,
        mapY: 0.14,
        requires: ['frozen_lake'],
        specialTag: 'Cryomancer Trial',
        modifierDesc: '12x8 Glacial Runeforge Terraces · Seize Runeforge Anvil · Recruits Cryomancer',
        title: 'Runeforge Peak',
        subtitle: 'Cryomancer Recruitment Trial',
        biome: 'frost',
        introSpeaker: 'Lyra',
        introText: 'Ancient dwarven runeforges hum atop the glacier terraces! Ride the ice sheets past the Frost Golems and Ice Wraiths to seize the Runeforge Anvil — Freya the Cryomancer awaits at the summit!',
        outroSpeaker: 'Lyra',
        outroText: 'The Runeforge Anvil blazes with sapphire frost! Freya the Cryomancer pledges her glacial arts to our vanguard!',
        rewardGold: 245,
        replayGold: 125,
        rewardEquipId: 'solis_archstaff',
        rewardHeroId: 'cryomancer',
        grid: [
            [V, N, T, H, S, S, T, H, H, H, V, V],
            [N, S, I, I, T, S, I, I, T, S, H, H],
            [N, S, N, P, I, T, S, C, I, T, H, H],
            [N, S, I, I, S, T, S, S, S, S, R, H],
            [N, S, I, I, T, S, I, P, I, T, S, H],
            [N, N, T, N, P, S, T, S, N, T, S, N],
            [N, S, I, N, S, S, I, S, S, S, N, N],
            [V, V, N, T, S, S, H, H, S, H, V, V]
        ],
        heights: [
            [0, 0, 1, 2, 2, 2, 2, 3, 3, 3, 0, 0],
            [0, 0, 0, 1, 1, 2, 2, 2, 3, 3, 3, 3],
            [0, 0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3],
            [0, 0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3],
            [0, 0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3],
            [0, 0, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3],
            [0, 0, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3],
            [0, 0, 1, 1, 2, 2, 3, 3, 3, 3, 0, 0]
        ],
        heroSpawns: [[0, 2], [0, 3], [0, 4], [1, 3]],
        objective: {
            kind: 'seize',
            label: 'Seize Runeforge Anvil',
            description: 'Claim the summit Runeforge Anvil within 12 turns (or rout all guardians) to recruit Freya.',
            goalTile: { col: 10, row: 3 },
            goalLabel: 'Runeforge Anvil',
            chestTiles: [{ col: 5, row: 0 }, { col: 6, row: 7 }],
            requiredChests: 0,
            turnLimit: 12
        },
        enemies: [
            { id: 'frost_golem', col: 7, row: 3, levelScale: 1.08 },
            { id: 'frost_golem', col: 8, row: 4, levelScale: 1.08 },
            { id: 'ice_wraith', col: 8, row: 0, levelScale: 1.12 },
            { id: 'ice_wraith', col: 11, row: 3, levelScale: 1.12 },
            { id: 'ice_wraith', col: 8, row: 7, levelScale: 1.10 }
        ]
    },
    {
        id: 'wyrm_eyrie',
        index: 21,
        region: 'frostspire',
        landmark: 'peak',
        kind: 'boss',
        difficulty: 5,
        recommendedPower: 1320,
        mapX: 0.69,
        mapY: 0.13,
        requires: ['glacial_citadel'],
        specialTag: 'Raid Boss (2x2)',
        modifierDesc: '13x9 Summit Eyrie · 2x2 Raid Boss: Rimefang (Glacial Breath & Wing Buffet)',
        title: 'Frostwyrm Eyrie',
        subtitle: 'Raid Boss: Rimefang',
        biome: 'frost',
        introSpeaker: 'Sir Aldric',
        introText: 'Rimefang, the elder Glacial Frostwyrm, spans the summit perch! Strike any part of the dragon\'s massive 2x2 frame, shelter behind stone pillars against Glacial Breath, and brace against Wing Buffet!',
        outroSpeaker: 'Sir Aldric',
        outroText: 'Rimefang crashes into the snowdrifts and the blizzard clears! The Aegis of Dawn shines atop Frostspire\'s crown.',
        rewardGold: 400,
        replayGold: 185,
        rewardEquipId: 'aegis_of_dawn',
        rewardHeroId: null,
        grid: [
            [V, V, N, H, I, H, H, I, H, N, V, V, V],
            [V, N, S, P, T, S, S, S, S, S, N, V, V],
            [N, S, T, I, S, C, T, S, S, S, S, H, V],
            [N, S, S, P, I, S, S, S, S, S, S, S, H],
            [N, R, S, S, I, S, S, S, S, S, S, S, H],
            [N, S, S, P, I, S, S, S, S, S, S, S, H],
            [N, S, T, I, S, C, T, S, S, S, S, H, V],
            [V, N, S, P, T, S, S, S, S, S, N, V, V],
            [V, V, N, H, I, H, H, I, H, N, V, V, V]
        ],
        heights: [
            [0, 0, 1, 2, 1, 2, 2, 2, 2, 2, 0, 0, 0],
            [0, 0, 1, 1, 1, 2, 2, 2, 2, 2, 2, 0, 0],
            [0, 0, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 0],
            [0, 0, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3],
            [0, 0, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3],
            [0, 0, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3],
            [0, 0, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 0],
            [0, 0, 1, 1, 1, 2, 2, 2, 2, 2, 2, 0, 0],
            [0, 0, 1, 2, 1, 2, 2, 2, 2, 2, 0, 0, 0]
        ],
        heroSpawns: [[0, 3], [0, 4], [0, 5], [1, 3]],
        objective: {
            kind: 'assassinate',
            label: 'Slay Rimefang',
            description: 'Defeat Rimefang the 2x2 Glacial Frostwyrm atop Frostwyrm Eyrie.',
            targetEnemyIndex: 0,
            targetEnemyId: 'frostwyrm_rimefang',
            targetName: 'Rimefang, Glacial Frostwyrm'
        },
        enemies: [
            { id: 'frostwyrm_rimefang', col: 8, row: 3, name: 'Rimefang, Glacial Frostwyrm' },
            { id: 'ice_wraith', col: 10, row: 1, levelScale: 1.15 },
            { id: 'ice_wraith', col: 10, row: 7, levelScale: 1.15 },
            { id: 'frost_golem', col: 7, row: 5, levelScale: 1.12 }
        ]
    },
    {
        id: 'cinder_colosseum',
        index: 22,
        region: 'emberwaste',
        landmark: 'arena',
        kind: 'elite',
        difficulty: 4,
        recommendedPower: 1160,
        mapX: 0.54,
        mapY: 0.68,
        requires: ['cursed_vault', 'obsidian_gate'],
        unlockMode: 'any',
        specialTag: '3-Round Pit',
        modifierDesc: '12x9 3-Round Gladiator Gauntlet · +25% HP & +1 AP between waves',
        title: 'Cinder Arena',
        subtitle: 'Gladiator Trial Pit',
        biome: 'volcano',
        introSpeaker: 'Sir Aldric',
        introText: 'Step down into the ember pit—three gladiator waves await before the arena champion emerges.',
        outroSpeaker: 'Sir Aldric',
        outroText: 'The arena roars your name above the coals.',
        rewardGold: 290,
        replayGold: 145,
        rewardEquipId: 'dragonfang_spear',
        rewardHeroId: null,
        grid: [
            [V, H, S, S, S, S, S, S, S, S, H, V],
            [S, T, M, D, D, D, D, D, D, M, T, S],
            [S, T, D, S, C, S, S, C, S, D, T, S],
            [S, T, D, S, S, S, S, S, S, D, T, S],
            [S, T, D, S, S, R, S, S, S, D, T, S],
            [S, T, D, S, S, S, S, S, S, D, T, S],
            [S, T, D, S, C, S, S, C, S, D, T, S],
            [S, T, M, D, D, D, D, D, D, M, T, S],
            [V, H, S, S, S, S, S, S, S, S, H, V]
        ],
        heights: [
            [-1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, -1],
            [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
            [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
            [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
            [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
            [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
            [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
            [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
            [-1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, -1]
        ],
        heroSpawns: [[0, 3], [0, 4], [0, 5], [1, 4]],
        objective: {
            kind: 'rout',
            label: '3-Round Gladiator Gauntlet',
            description: 'Clear all 3 gladiator waves in Cinder Arena. Heroes recover +25% HP and +1 AP between rounds.'
        },
        enemies: [
            { id: 'orc_brute', col: 8, row: 3, levelScale: 1.05, name: 'Pit Bruiser' },
            { id: 'ember_pyromancer', col: 10, row: 4, levelScale: 1.05, name: 'Cinder Pyromancer' },
            { id: 'goblin', col: 8, row: 5, levelScale: 1.15, name: 'Arena Skirmisher' },
            { id: 'crypt_knight', col: 9, row: 2, levelScale: 1.0, name: 'Iron Gladiator' }
        ]
    },
    {
        id: 'molten_core',
        index: 23,
        region: 'emberwaste',
        landmark: 'foundry',
        kind: 'boss',
        difficulty: 5,
        recommendedPower: 1360,
        mapX: 0.72,
        mapY: 0.59,
        requires: ['ashfall_foundry'],
        specialTag: 'Raid Boss',
        modifierDesc: '12x9 Ignis Titan Raid · Cataclysm Slam ignites nearby magma geysers',
        title: 'Brimstone Maw',
        subtitle: 'Raid Boss: Ignis Titan',
        biome: 'volcano',
        introSpeaker: 'Vesper',
        introText: 'The caldera cracks open around the Ignis Titan. Topple the molten colossus before its Cataclysm Slam awakens every vent!',
        outroSpeaker: 'Vesper',
        outroText: 'The molten colossus shatters and the caldera settles.',
        rewardGold: 420,
        replayGold: 195,
        rewardEquipId: 'heart_of_solis',
        rewardHeroId: null,
        grid: [
            [V, L, L, D, D, D, D, D, D, L, L, V],
            [L, D, B, B, D, M, M, D, B, B, D, L],
            [D, D, M, D, T, D, D, T, D, M, D, D],
            [D, S, D, T, D, D, D, D, T, D, S, D],
            [D, B, D, T, D, D, D, D, T, D, B, D],
            [D, S, D, T, D, D, D, D, T, D, S, D],
            [D, D, M, D, T, D, D, T, D, M, D, D],
            [L, D, B, B, D, R, D, D, B, B, D, L],
            [V, L, L, D, D, D, D, D, D, L, L, V]
        ],
        heights: [
            [-1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, -1],
            [0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0],
            [0, 0, 0, 0, 1, 2, 2, 1, 0, 0, 0, 0],
            [0, 0, 1, 1, 2, 2, 2, 2, 1, 1, 0, 0],
            [0, 0, 1, 1, 2, 2, 2, 2, 1, 1, 0, 0],
            [0, 0, 1, 1, 2, 2, 2, 2, 1, 1, 0, 0],
            [0, 0, 0, 0, 1, 2, 2, 1, 0, 0, 0, 0],
            [0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0],
            [-1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, -1]
        ],
        heroSpawns: [[0, 3], [0, 4], [0, 5], [1, 4]],
        objective: {
            kind: 'assassinate',
            targetEnemyId: 'ignis_titan',
            targetName: 'Ignis Titan',
            label: 'Slay Ignis Titan',
            description: 'Defeat the Ignis Titan atop the raised magma dais to claim Brimstone Maw.'
        },
        enemies: [
            { id: 'ignis_titan', col: 6, row: 4, levelScale: 1.0, name: 'Ignis Titan' },
            { id: 'ember_pyromancer', col: 8, row: 1, levelScale: 1.10 },
            { id: 'ember_pyromancer', col: 8, row: 7, levelScale: 1.10 },
            { id: 'crypt_knight', col: 10, row: 4, levelScale: 1.10, name: 'Obsidian Sentinel' }
        ]
    },
    // =========================================================================
    // ACT IV+ OUTER FRONTIER REGIONS (TIERS V–VIII — BEYOND ECLIPSE THRONE)
    // =========================================================================
    {
        id: 'mirage_oasis',
        index: 24,
        region: 'sunbleached_dunes',
        landmark: 'town',
        kind: 'special',
        difficulty: 5,
        recommendedPower: 1420,
        mapX: 0.14,
        mapY: 0.86,
        requires: ['eclipse_throne'],
        seaRoute: true,
        specialTag: 'Sandstorm Frontier',
        modifierDesc: '12x8 Oasis Bridges · Shifting Sandstorm Gusts (Shelter by Pillars)',
        title: 'Mirage Oasis',
        subtitle: 'Desert Strait Landing',
        biome: 'dunes',
        introSpeaker: 'Lyra',
        introText: 'Across the southern strait lie sun-baked ruins older than Solis! Hold beside the sandstone obelisks when the desert gusts howl across the dunes.',
        outroSpeaker: 'Lyra',
        outroText: 'The oasis bridges are secure! Our desert caravan can now push inland toward the Sunken Obelisk.',
        rewardGold: 440,
        replayGold: 205,
        rewardEquipId: 'gale_longbow',
        rewardHeroId: null,
        grid: [
            [V, G, H, H, W, W, W, G, H, H, H, V],
            [G, S, S, T, B, B, B, S, T, S, H, H],
            [G, R, P, G, W, W, W, P, S, G, G, H],
            [G, S, S, T, B, B, B, S, G, P, S, G],
            [G, S, G, G, W, W, W, G, P, S, G, G],
            [G, S, P, G, W, W, W, P, S, G, H, H],
            [G, S, S, T, B, B, B, S, T, H, H, H],
            [V, G, H, H, W, W, W, G, H, G, G, V]
        ],
        heights: [
            [0, 0, 1, 1, 0, 0, 0, 1, 2, 2, 2, 0],
            [0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2, 2],
            [0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 2],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1],
            [0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 2, 2],
            [0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2, 2],
            [0, 0, 1, 1, 0, 0, 0, 1, 2, 1, 1, 0]
        ],
        heroSpawns: [[0, 1], [1, 1], [0, 6], [1, 3]],
        objective: {
            kind: 'rout',
            label: 'Clear Mirage Oasis',
            description: 'Defeat the desert vanguard holding the oasis bridges.'
        },
        enemies: [
            { id: 'crypt_knight', col: 7, row: 1, levelScale: 1.25, name: 'Dune Sentinel' },
            { id: 'ember_pyromancer', col: 9, row: 0, levelScale: 1.25, name: 'Sunfire Magus' },
            { id: 'river_troll', col: 7, row: 6, levelScale: 1.25, name: 'Sandstone Brute' },
            { id: 'bog_shaman', col: 10, row: 3, levelScale: 1.28, name: 'Mirage Mystic' },
            { id: 'bone_archer', col: 11, row: 5, levelScale: 1.28, name: 'Desert Marksman' }
        ]
    },
    {
        id: 'sunken_obelisk',
        index: 25,
        region: 'sunbleached_dunes',
        landmark: 'ruins',
        kind: 'treasure',
        difficulty: 6,
        recommendedPower: 1620,
        mapX: 0.25,
        mapY: 0.90,
        requires: ['mirage_oasis'],
        specialTag: 'Tier VI Vault',
        modifierDesc: '11x8 Sunken Reliquary · Seize Sun-Prism · Obelisk Cover & Cursed Altars',
        title: 'Sunken Obelisk',
        subtitle: 'Mythic Desert Reliquary',
        biome: 'dunes',
        introSpeaker: 'Vesper',
        introText: 'An ancient sun-prism sleeps half-buried beneath golden dunes! Use the obelisk pillars to weather the sandstorm, claim the reliquary chest, and seize the prism.',
        outroSpeaker: 'Vesper',
        outroText: 'The sun-prism awakens and blazes across the sand! Ahead rises the terraced Sunscar Pyramid of the Dune Sovereign.',
        rewardGold: 520,
        replayGold: 230,
        rewardEquipId: 'shadowfang_bow',
        rewardHeroId: null,
        grid: [
            [V, S, H, H, P, H, H, P, H, S, V],
            [G, T, S, S, A, S, S, T, H, H, S],
            [G, S, P, S, S, C, S, P, S, S, S],
            [G, S, S, S, S, A, S, S, T, S, R],
            [G, S, S, P, S, S, S, C, T, S, S],
            [G, S, P, S, S, A, S, P, S, H, S],
            [G, T, S, S, P, S, S, T, H, H, S],
            [V, S, H, H, H, H, H, S, S, S, V]
        ],
        heights: [
            [0, 1, 2, 2, 2, 2, 2, 2, 2, 1, 0],
            [0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2],
            [0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2],
            [0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2],
            [0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2],
            [0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2],
            [0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2],
            [0, 1, 2, 2, 2, 2, 2, 1, 1, 1, 0]
        ],
        heroSpawns: [[0, 2], [0, 3], [0, 4], [0, 5]],
        objective: {
            kind: 'seize',
            label: 'Seize Sun-Prism Shrine',
            description: 'Reach the Sun-Prism Shrine within 13 turns. Reliquary chests grant bonus gold!',
            goalTile: { col: 10, row: 3 },
            goalLabel: 'Sun-Prism Shrine',
            chestTiles: [{ col: 4, row: 1 }, { col: 8, row: 6 }],
            requiredChests: 0,
            turnLimit: 13
        },
        enemies: [
            { id: 'crypt_knight', col: 6, row: 3, levelScale: 1.32, name: 'Obelisk Guard' },
            { id: 'frost_golem', col: 6, row: 4, levelScale: 1.30, name: 'Sandstone Construct' },
            { id: 'ember_pyromancer', col: 9, row: 1, levelScale: 1.32, name: 'Solar Magus' },
            { id: 'bone_necromancer', col: 10, row: 6, levelScale: 1.30, name: 'Tomb Acolyte' },
            { id: 'ice_wraith', col: 9, row: 3, levelScale: 1.30, name: 'Mirage Wraith' }
        ]
    },
    {
        id: 'dune_sovereign',
        index: 26,
        region: 'sunbleached_dunes',
        landmark: 'citadel',
        kind: 'boss',
        difficulty: 6,
        recommendedPower: 1780,
        mapX: 0.37,
        mapY: 0.91,
        requires: ['sunken_obelisk'],
        specialTag: 'Tier VI Boss',
        modifierDesc: '12x9 Sunscar Pyramid · Boss: Dune Sovereign · Sandstorm Vortex',
        title: 'Sunscar Pyramid',
        subtitle: 'Mythic Boss: Dune Sovereign',
        biome: 'dunes',
        introSpeaker: 'Dune Sovereign',
        introText: 'Mortals of the green valley, you trespass upon the Eternal Sands! Bow before the Sandstorm Vortex or be buried beneath the Sunscar!',
        outroSpeaker: 'Sir Aldric',
        outroText: 'The gilded pharaoh-construct shatters! Its astral compass points skyward — the way to Tempest Spire in the Aether Isles is open!',
        rewardGold: 620,
        replayGold: 260,
        rewardEquipId: 'windrunner_bow',
        rewardHeroId: null,
        grid: [
            [V, V, S, S, H, H, H, H, S, S, V, V],
            [V, S, T, S, P, S, S, P, T, H, H, V],
            [G, S, S, T, H, S, T, H, H, H, S, S],
            [G, S, S, S, T, H, T, H, H, H, H, S],
            [G, R, S, S, A, S, T, H, H, H, H, H],
            [G, S, S, S, T, H, T, H, H, H, H, S],
            [G, S, S, T, H, S, T, H, H, H, S, S],
            [V, S, T, S, P, S, S, P, T, H, H, V],
            [V, V, S, S, H, H, H, H, S, S, V, V]
        ],
        heights: [
            [0, 0, 1, 1, 2, 2, 2, 2, 2, 2, 0, 0],
            [0, 0, 1, 2, 2, 2, 2, 2, 3, 3, 3, 0],
            [0, 0, 1, 2, 3, 3, 3, 3, 4, 4, 3, 3],
            [0, 0, 1, 2, 2, 3, 3, 3, 4, 4, 4, 3],
            [0, 0, 1, 2, 2, 3, 3, 3, 4, 4, 4, 4],
            [0, 0, 1, 2, 2, 3, 3, 3, 4, 4, 4, 3],
            [0, 0, 1, 2, 3, 3, 3, 3, 4, 4, 3, 3],
            [0, 0, 1, 2, 2, 2, 2, 2, 3, 3, 3, 0],
            [0, 0, 1, 1, 2, 2, 2, 2, 2, 2, 0, 0]
        ],
        heroSpawns: [[0, 3], [0, 4], [0, 5], [1, 3]],
        objective: {
            kind: 'assassinate',
            label: 'Slay Dune Sovereign',
            description: 'Defeat the Dune Sovereign atop the Sunscar Pyramid.',
            targetEnemyIndex: 0,
            targetEnemyId: 'dune_sovereign_boss',
            targetName: 'Dune Sovereign'
        },
        enemies: [
            { id: 'dune_sovereign_boss', col: 10, row: 4 },
            { id: 'crypt_knight', col: 7, row: 3, levelScale: 1.32, name: 'Pyramid Guard' },
            { id: 'crypt_knight', col: 7, row: 5, levelScale: 1.32, name: 'Pyramid Guard' },
            { id: 'ember_pyromancer', col: 9, row: 1, levelScale: 1.30, name: 'Solar Magus' },
            { id: 'bone_necromancer', col: 9, row: 7, levelScale: 1.30, name: 'Tomb Priest' }
        ]
    },
    {
        id: 'starfall_atoll',
        index: 27,
        region: 'aether_isles',
        landmark: 'atoll',
        kind: 'special',
        difficulty: 6,
        recommendedPower: 1680,
        mapX: 0.81,
        mapY: 0.28,
        requires: ['eclipse_throne', 'glacial_citadel'],
        unlockMode: 'any',
        seaRoute: true,
        specialTag: 'Mythic Atoll',
        modifierDesc: '13x9 Outer-Sea Relic Island · Claim 2 Mythic Chests & Seize Starfall Altar',
        title: 'Starfall Atoll',
        subtitle: 'Mythic Sea Expedition',
        biome: 'throne',
        introSpeaker: 'Vesper',
        introText: 'A fallen star shattered this outer island into terraced crystal reefs. Cross the sea-bridges, claim both mythic chests, and seize the Starfall Altar.',
        outroSpeaker: 'Vesper',
        outroText: 'Starlight relics and rare dust recovered from the outer reef.',
        rewardGold: 560,
        replayGold: 245,
        rewardEquipId: 'heart_of_solis',
        rewardHeroId: null,
        grid: [
            [V, W, W, W, W, S, H, H, S, W, W, W, V],
            [W, G, S, S, B, T, H, S, S, W, S, S, S],
            [G, G, S, W, W, S, D, D, T, W, T, H, H],
            [G, S, S, W, W, S, D, S, T, W, T, H, H],
            [G, S, S, B, B, S, D, S, S, B, B, T, R],
            [G, S, S, W, W, S, D, S, T, W, T, H, H],
            [G, G, S, W, W, S, D, D, T, W, T, H, H],
            [W, G, S, S, B, T, H, S, S, W, S, S, S],
            [V, W, W, W, W, S, H, H, S, W, W, W, V]
        ],
        heights: [
            [-1, 0, 0, 0, 0, 1, 2, 2, 1, 0, 0, 0, -1],
            [0, 0, 0, 0, 0, 1, 2, 1, 1, 0, 1, 2, 2],
            [0, 0, 0, 0, 0, 1, 2, 2, 1, 0, 2, 2, 2],
            [0, 0, 0, 0, 0, 1, 2, 2, 1, 0, 2, 2, 2],
            [0, 0, 0, 0, 0, 1, 2, 2, 1, 1, 1, 2, 3],
            [0, 0, 0, 0, 0, 1, 2, 2, 1, 0, 2, 2, 2],
            [0, 0, 0, 0, 0, 1, 2, 2, 1, 0, 2, 2, 2],
            [0, 0, 0, 0, 0, 1, 2, 1, 1, 0, 1, 2, 2],
            [-1, 0, 0, 0, 0, 1, 2, 2, 1, 0, 0, 0, -1]
        ],
        heroSpawns: [[0, 3], [0, 4], [0, 5], [1, 4]],
        objective: {
            kind: 'seize',
            label: 'Seize Starfall Altar',
            description: 'Claim both Mythic Relic Chests on the central ridges and seize the summit Starfall Altar.',
            goalTile: { col: 12, row: 4 },
            goalLabel: 'Starfall Altar',
            chestTiles: [{ col: 6, row: 0 }, { col: 6, row: 8 }],
            requiredChests: 2
        },
        enemies: [
            { id: 'frost_jarl', col: 11, row: 4, levelScale: 1.05, name: 'Astral Warden' },
            { id: 'ice_wraith', col: 7, row: 1, levelScale: 1.25, name: 'Starlight Wraith' },
            { id: 'ember_pyromancer', col: 7, row: 7, levelScale: 1.25, name: 'Comet Pyromancer' },
            { id: 'crypt_knight', col: 8, row: 4, levelScale: 1.22, name: 'Reef Vanguard' },
            { id: 'abyssal_sentinel', col: 12, row: 2, levelScale: 1.08, name: 'Starfall Sentinel' }
        ]
    },
    {
        id: 'tempest_spire',
        index: 28,
        region: 'aether_isles',
        landmark: 'peak',
        kind: 'elite',
        difficulty: 7,
        recommendedPower: 1960,
        mapX: 0.88,
        mapY: 0.16,
        requires: ['dune_sovereign'],
        seaRoute: true,
        specialTag: 'Tier VII Spire',
        modifierDesc: '13x8 Sky-Bridge Terraces (H0–H4) · Lightning Conduit Strikes Every 2 Rounds',
        title: 'Tempest Spire',
        subtitle: 'Cataclysm Storm Tower',
        biome: 'aether',
        introSpeaker: 'Lyra',
        introText: 'Eternal thunder arcs between floating alabaster sky-bridges! Watch the lightning conduits on even rounds as we climb four tiers toward the storm crest.',
        outroSpeaker: 'Lyra',
        outroText: 'The storm spire falls quiet! Ahead across the cloud chasm looms Skybreak Bastion and the Astral Warden.',
        rewardGold: 680,
        replayGold: 290,
        rewardEquipId: 'starweaver_mantle',
        rewardHeroId: null,
        grid: [
            [V, V, S, S, T, V, V, V, S, T, H, H, V],
            [S, T, S, S, B, B, B, S, P, H, H, H, H],
            [S, R, P, S, V, V, V, S, T, H, S, H, H],
            [S, S, S, S, B, B, B, S, T, H, P, H, H],
            [S, S, S, S, V, V, V, S, T, H, P, H, H],
            [S, T, S, S, B, B, B, S, S, H, H, H, H],
            [S, S, P, S, V, V, V, S, T, H, S, H, H],
            [V, V, S, S, T, V, V, V, S, T, H, H, V]
        ],
        heights: [
            [0, 0, 1, 1, 2, 0, 0, 0, 3, 3, 4, 4, 0],
            [0, 1, 1, 1, 2, 2, 2, 2, 3, 3, 4, 4, 4],
            [0, 0, 1, 1, 0, 0, 0, 2, 3, 3, 3, 4, 4],
            [0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 4, 4],
            [0, 0, 1, 1, 0, 0, 0, 2, 3, 3, 3, 4, 4],
            [0, 1, 1, 1, 2, 2, 2, 2, 3, 3, 4, 4, 4],
            [0, 0, 1, 1, 0, 0, 0, 2, 3, 3, 3, 4, 4],
            [0, 0, 1, 1, 2, 0, 0, 0, 3, 3, 4, 4, 0]
        ],
        heroSpawns: [[0, 1], [0, 3], [0, 4], [0, 5]],
        objective: {
            kind: 'rout',
            label: 'Conquer Tempest Spire',
            description: 'Defeat the storm garrison across the vertical sky-bridge terraces.'
        },
        enemies: [
            { id: 'frost_golem', col: 7, row: 1, levelScale: 1.38, name: 'Storm Colossus' },
            { id: 'crypt_knight', col: 7, row: 5, levelScale: 1.38, name: 'Tempest Knight' },
            { id: 'ice_wraith', col: 9, row: 2, levelScale: 1.40, name: 'Aether Wraith' },
            { id: 'ember_pyromancer', col: 11, row: 0, levelScale: 1.40, name: 'Lightning Savant' },
            { id: 'ember_pyromancer', col: 11, row: 7, levelScale: 1.40, name: 'Lightning Savant' }
        ]
    },
    {
        id: 'skybreak_bastion',
        index: 29,
        region: 'aether_isles',
        landmark: 'citadel',
        kind: 'boss',
        difficulty: 7,
        recommendedPower: 2150,
        mapX: 0.93,
        mapY: 0.32,
        requires: ['tempest_spire'],
        specialTag: 'Tier VII Boss',
        modifierDesc: '13x9 Floating Citadel · Boss: Astral Warden · Starlight Lance & Tempest Surge',
        title: 'Skybreak Bastion',
        subtitle: 'Cataclysm Boss: Astral Warden',
        biome: 'aether',
        introSpeaker: 'Astral Warden',
        introText: 'You dare ascend the Skybreak Bastion? Let Starlight Lance and Tempest Surge cast your vanguard back into the cloud chasm!',
        outroSpeaker: 'Sir Aldric',
        outroText: 'The Astral Warden salutes and lowers its wings — the outer chart to Obsidian Rift in the Shattered Expanse is ours!',
        rewardGold: 780,
        replayGold: 320,
        rewardEquipId: 'shadowsilk_vest',
        rewardHeroId: 'champion',
        grid: [
            [V, V, V, S, S, H, H, H, S, S, V, V, V],
            [V, S, T, B, B, S, P, T, H, H, S, V, V],
            [S, S, P, V, V, S, T, H, H, H, H, S, V],
            [S, S, S, B, B, S, T, H, H, H, H, H, S],
            [S, R, T, B, B, S, S, T, H, H, H, H, H],
            [S, S, S, B, B, S, T, H, H, H, H, H, S],
            [S, S, P, V, V, S, T, H, H, H, H, S, V],
            [V, S, T, B, B, S, P, T, H, H, S, V, V],
            [V, V, V, S, S, H, H, H, S, S, V, V, V]
        ],
        heights: [
            [0, 0, 0, 2, 2, 2, 3, 3, 3, 3, 0, 0, 0],
            [0, 1, 1, 2, 2, 2, 3, 3, 4, 4, 3, 0, 0],
            [0, 1, 1, 0, 0, 2, 3, 3, 4, 4, 4, 3, 0],
            [0, 0, 1, 2, 2, 2, 3, 3, 4, 4, 4, 4, 3],
            [0, 0, 1, 2, 2, 2, 2, 3, 4, 4, 4, 4, 4],
            [0, 0, 1, 2, 2, 2, 3, 3, 4, 4, 4, 4, 3],
            [0, 1, 1, 0, 0, 2, 3, 3, 4, 4, 4, 3, 0],
            [0, 1, 1, 2, 2, 2, 3, 3, 4, 4, 3, 0, 0],
            [0, 0, 0, 2, 2, 2, 3, 3, 3, 3, 0, 0, 0]
        ],
        heroSpawns: [[0, 3], [0, 4], [0, 5], [1, 4]],
        objective: {
            kind: 'assassinate',
            label: 'Slay Astral Warden',
            description: 'Defeat the Astral Warden commanding Skybreak Bastion.',
            targetEnemyIndex: 0,
            targetEnemyId: 'astral_warden_boss',
            targetName: 'Astral Warden'
        },
        enemies: [
            { id: 'astral_warden_boss', col: 11, row: 4 },
            { id: 'crypt_knight', col: 7, row: 3, levelScale: 1.42, name: 'Starlight Sentinel' },
            { id: 'crypt_knight', col: 7, row: 5, levelScale: 1.42, name: 'Starlight Sentinel' },
            { id: 'ice_wraith', col: 9, row: 1, levelScale: 1.42, name: 'Skybreak Wraith' },
            { id: 'ember_pyromancer', col: 9, row: 7, levelScale: 1.42, name: 'Astral Conduit' }
        ]
    },
    {
        id: 'abyssal_deep',
        index: 30,
        region: 'shattered_expanse',
        landmark: 'abyss',
        kind: 'boss',
        difficulty: 6,
        recommendedPower: 1850,
        mapX: 0.65,
        mapY: 0.86,
        requires: ['bone_cathedral', 'cinder_colosseum'],
        unlockMode: 'any',
        seaRoute: true,
        specialTag: '10-Floor Abyss',
        modifierDesc: '12x9 Secret 10-Floor Pitch-Black Dungeon · Tiers VI–VIII & Abyssal Sovereign',
        title: 'Crownless Deep',
        subtitle: 'Secret 10-Floor Abyss',
        biome: 'throne',
        introSpeaker: 'Archon Malakor',
        introText: 'Ten sunken vaults lie beneath the sea-trench where forgotten crowns sleep. Descend floor by floor toward the Abyssal Sovereign.',
        outroSpeaker: 'Sir Aldric',
        outroText: 'Torchlight claims another vault of the Crownless Deep.',
        rewardGold: 640,
        replayGold: 270,
        rewardEquipId: 'nightwind_garb',
        rewardHeroId: 'champion',
        grid: [
            [V, D, D, P, D, D, D, D, P, D, D, V],
            [D, D, T, D, D, S, S, D, D, T, D, D],
            [D, S, D, D, A, D, D, A, D, D, S, D],
            [D, S, T, D, D, D, D, D, D, T, S, D],
            [D, S, D, D, D, R, D, D, D, D, S, D],
            [D, S, T, D, D, D, D, D, D, T, S, D],
            [D, S, D, D, A, D, D, A, D, D, S, D],
            [D, D, T, D, D, S, S, D, D, T, D, D],
            [V, D, D, P, D, D, D, D, P, D, D, V]
        ],
        heights: [
            [-1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1],
            [1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1],
            [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
            [1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1],
            [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
            [1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1],
            [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
            [1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1],
            [-1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1]
        ],
        heroSpawns: [[0, 3], [0, 4], [0, 5], [1, 4]],
        objective: {
            kind: 'rout',
            label: 'Clear Abyss Floor',
            description: 'Defeat the abyssal guardians to unlock the next floor of Crownless Deep.'
        },
        enemies: [
            { id: 'abyssal_sentinel', col: 9, row: 4, levelScale: 1.0 },
            { id: 'crypt_knight', col: 8, row: 1, levelScale: 1.15 },
            { id: 'bone_necromancer', col: 9, row: 7, levelScale: 1.15 },
            { id: 'bone_archer', col: 11, row: 3, levelScale: 1.15 }
        ]
    },
    {
        id: 'obsidian_rift',
        index: 31,
        region: 'shattered_expanse',
        landmark: 'gate',
        kind: 'elite',
        difficulty: 7,
        recommendedPower: 2240,
        mapX: 0.81,
        mapY: 0.74,
        requires: ['skybreak_bastion'],
        seaRoute: true,
        specialTag: 'Tier VII Rift',
        modifierDesc: '13x8 Fractured Void Isles · Narrow Obsidian Spans · Astral Rift Pulses',
        title: 'Obsidian Rift',
        subtitle: 'Outer Void Crossing',
        biome: 'expanse',
        introSpeaker: 'Vesper',
        introText: 'Where the ocean ends, fractured obsidian shards float above an endless eclipse! Cross the narrow void spans and break the elite Rift Vanguard.',
        outroSpeaker: 'Vesper',
        outroText: 'The outer rift stabilizes! Beyond the last shattered monolith stands the First Sun Sanctum — the throne of The Unbroken Crown.',
        rewardGold: 820,
        replayGold: 340,
        rewardEquipId: 'celestial_staff',
        rewardHeroId: null,
        grid: [
            [V, D, S, S, V, V, D, H, H, V, V, V, V],
            [D, S, T, B, B, D, T, A, D, B, B, D, H],
            [D, R, D, V, V, D, P, D, D, V, T, H, H],
            [D, S, D, B, B, D, S, D, D, B, B, H, H],
            [D, S, D, V, V, D, S, D, D, V, T, H, H],
            [D, S, D, V, V, D, P, D, D, V, T, H, H],
            [D, S, T, B, B, D, T, A, D, B, B, D, H],
            [V, D, S, S, V, V, D, H, H, V, V, V, V]
        ],
        heights: [
            [0, 1, 1, 1, 0, 0, 2, 2, 2, 0, 0, 0, 0],
            [0, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3],
            [0, 0, 1, 0, 0, 2, 2, 2, 2, 0, 3, 4, 4],
            [0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 4, 4],
            [0, 0, 1, 0, 0, 2, 2, 2, 2, 0, 3, 4, 4],
            [0, 0, 1, 0, 0, 2, 2, 2, 2, 0, 3, 4, 4],
            [0, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3],
            [0, 1, 1, 1, 0, 0, 2, 2, 2, 0, 0, 0, 0]
        ],
        heroSpawns: [[0, 1], [0, 3], [0, 4], [0, 6]],
        objective: {
            kind: 'rout',
            label: 'Breach Obsidian Rift',
            description: 'Defeat the elite Rift Vanguard across the fractured obsidian islands.'
        },
        enemies: [
            { id: 'crypt_knight', col: 5, row: 2, levelScale: 1.48, name: 'Rift Vanguard' },
            { id: 'crypt_knight', col: 5, row: 5, levelScale: 1.48, name: 'Rift Vanguard' },
            { id: 'frost_golem', col: 8, row: 3, levelScale: 1.45, name: 'Obsidian Colossus' },
            { id: 'bone_necromancer', col: 11, row: 1, levelScale: 1.48, name: 'Void Necromancer' },
            { id: 'ember_pyromancer', col: 12, row: 4, levelScale: 1.50, name: 'Eclipse Savant' }
        ]
    },
    {
        id: 'first_sun_sanctum',
        index: 32,
        region: 'shattered_expanse',
        landmark: 'throne',
        kind: 'boss',
        difficulty: 8,
        recommendedPower: 2600,
        mapX: 0.91,
        mapY: 0.86,
        requires: ['obsidian_rift'],
        seaRoute: true,
        specialTag: 'Tier VIII Apex',
        modifierDesc: '13x9 Primordial Sanctum · 2-Phase Apex Raid Boss: The Unbroken Crown',
        title: 'First Sun Sanctum',
        subtitle: 'Apex Raid: The Unbroken Crown',
        biome: 'expanse',
        introSpeaker: 'The Unbroken Crown',
        introText: 'Before Solis, before the Eclipse, I burned eternal! Strike me down if you can — at half strength the Solar Eclipse awakens!',
        outroSpeaker: 'Sir Aldric',
        outroText: 'The Unbroken Crown yields to a new dawn! From Sunbleached Dunes to the Shattered Expanse, the Outer Frontier belongs to Solis!',
        rewardGold: 1200,
        replayGold: 450,
        rewardEquipId: 'solis_crownblade',
        rewardHeroId: 'champion',
        grid: [
            [V, V, V, D, D, H, H, H, D, D, V, V, V],
            [V, D, T, B, B, A, P, T, H, H, D, V, V],
            [D, S, D, V, V, D, T, H, H, H, H, D, V],
            [D, S, D, B, B, D, T, H, H, H, H, H, D],
            [D, R, T, B, B, D, S, T, H, H, H, H, H],
            [D, S, D, B, B, D, T, H, H, H, H, H, D],
            [D, S, D, V, V, D, T, H, H, H, H, D, V],
            [V, D, T, B, B, A, P, T, H, H, D, V, V],
            [V, V, V, D, D, H, H, H, D, D, V, V, V]
        ],
        heights: [
            [0, 0, 0, 2, 2, 2, 3, 3, 3, 3, 0, 0, 0],
            [0, 1, 1, 2, 2, 2, 3, 3, 4, 4, 3, 0, 0],
            [0, 1, 1, 0, 0, 2, 3, 3, 4, 4, 4, 3, 0],
            [0, 0, 1, 2, 2, 2, 3, 3, 4, 4, 4, 4, 3],
            [0, 0, 1, 2, 2, 2, 2, 3, 4, 4, 4, 4, 4],
            [0, 0, 1, 2, 2, 2, 3, 3, 4, 4, 4, 4, 3],
            [0, 1, 1, 0, 0, 2, 3, 3, 4, 4, 4, 3, 0],
            [0, 1, 1, 2, 2, 2, 3, 3, 4, 4, 3, 0, 0],
            [0, 0, 0, 2, 2, 2, 3, 3, 3, 3, 0, 0, 0]
        ],
        heroSpawns: [[0, 3], [0, 4], [0, 5], [1, 4]],
        objective: {
            kind: 'assassinate',
            label: 'Shatter The Unbroken Crown',
            description: 'Defeat The Unbroken Crown across both raid phases to claim the First Sun Sanctum.',
            targetEnemyIndex: 0,
            targetEnemyId: 'unbroken_crown_boss',
            targetName: 'The Unbroken Crown'
        },
        enemies: [
            { id: 'unbroken_crown_boss', col: 11, row: 4 },
            { id: 'crypt_knight', col: 7, row: 3, levelScale: 1.50, name: 'Crownblade Warden' },
            { id: 'crypt_knight', col: 7, row: 5, levelScale: 1.50, name: 'Crownblade Warden' },
            { id: 'bone_necromancer', col: 9, row: 1, levelScale: 1.50, name: 'Solar Archivist' },
            { id: 'ember_pyromancer', col: 9, row: 7, levelScale: 1.50, name: 'Eclipse Hierophant' }
        ]
    }
];
export const PLAYABLE_CHAPTERS = CHAPTERS.filter(ch => !ch.comingSoon);
export const CHAPTER_BY_ID = Object.fromEntries(CHAPTERS.map(ch => [ch.id, ch]));
