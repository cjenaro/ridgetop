export const GRID_COLS = 11;
export const GRID_ROWS = 8;
export const TILE_SIZE = 1.65;
export const HEIGHT_STEP = 0.45;
export const MAX_HEIGHT_LEVEL = 4;
export const MAX_POISON_STACKS = 5;
export const TAUNT_RADIUS = 4;
export const KO_COUNTDOWN_TURNS = 3;
export const BARRICADE_DEFAULT_HP = 25;
export const CRACKED_PILLAR_DEFAULT_HP = 35;
export const LAVA_GEYSER_DAMAGE = 12;
export const LAVA_GEYSER_PERIOD = 2;
export const CURSED_ALTAR_HP_COST = 10;
export const TALL_GRASS_RANGED_COVER = 3;
export const TALL_GRASS_RANGED_CRIT_REDUCTION = 0.12;
export const OPPORTUNITY_ATTACK_DAMAGE_MUL = 0.75;
export const COLLISION_IMPACT_DAMAGE = 10;
export const LEDGE_STOP_DAMAGE = 12;
export const FALL_DAMAGE_PER_LEVEL = 7;
export const FALL_MIN_DROP_LEVELS = 2;
export const FACING_DIRS = ['n', 'e', 's', 'w'];
export function gridToWorld(col, row, elevation = 0, cols = GRID_COLS, rows = GRID_ROWS) {
    const x = (col - (cols - 1) * 0.5) * TILE_SIZE;
    const z = (row - (rows - 1) * 0.5) * TILE_SIZE;
    return [x, elevation, z];
}
export function worldToGrid(x, z, cols = GRID_COLS, rows = GRID_ROWS) {
    const col = Math.round(x / TILE_SIZE + (cols - 1) * 0.5);
    const row = Math.round(z / TILE_SIZE + (rows - 1) * 0.5);
    if (col < 0 || col >= cols || row < 0 || row >= rows)
        return null;
    return { col, row };
}
export function defaultTerrainHeightLevel(t) {
    if (t === 'void')
        return -1;
    if (t === 'hill')
        return 1;
    return 0;
}
export function terrainElevation(t, heightLevel) {
    if (t === 'void')
        return -1.2;
    const level = heightLevel !== undefined
        ? Math.max(0, Math.min(MAX_HEIGHT_LEVEL, Math.round(heightLevel)))
        : defaultTerrainHeightLevel(t);
    const base = level * HEIGHT_STEP;
    if (t === 'pillar')
        return base + 1.15;
    if (t === 'water' || t === 'lava')
        return base - 0.22;
    if (t === 'bridge')
        return base + 0.08;
    if (t === 'shrine')
        return base + 0.16;
    if (t === 'cursed_altar')
        return base + 0.12;
    return base;
}
export function terrainWalkable(t) {
    return t !== 'water' && t !== 'lava' && t !== 'pillar' && t !== 'cracked_pillar' && t !== 'void' && t !== 'barricade';
}
export function terrainMoveCost(t) {
    if (!terrainWalkable(t))
        return 99;
    if (t === 'snow')
        return 2;
    return 1;
}
export function terrainDefBonus(t) {
    if (t === 'darkstone')
        return 2;
    if (t === 'stone' || t === 'shrine')
        return 1;
    if (t === 'bridge')
        return -1;
    return 0;
}
export function cellHeightLevel(cell) {
    if (cell.heightLevel !== undefined)
        return cell.heightLevel;
    if (cell.terrain === 'void')
        return -1;
    if (cell.terrain === 'water' || cell.terrain === 'lava') {
        return Math.max(0, Math.round((cell.elevation + 0.22) / HEIGHT_STEP));
    }
    if (cell.terrain === 'pillar') {
        return Math.max(0, Math.round((cell.elevation - 1.15) / HEIGHT_STEP));
    }
    if (cell.terrain === 'bridge') {
        return Math.max(0, Math.round((cell.elevation - 0.08) / HEIGHT_STEP));
    }
    if (cell.terrain === 'shrine') {
        return Math.max(0, Math.round((cell.elevation - 0.16) / HEIGHT_STEP));
    }
    if (cell.terrain === 'cursed_altar') {
        return Math.max(0, Math.round((cell.elevation - 0.12) / HEIGHT_STEP));
    }
    return Math.max(0, Math.round(cell.elevation / HEIGHT_STEP));
}
export function cellElevation(state, col, row) {
    if (row < 0 || row >= state.rows || col < 0 || col >= state.cols)
        return 0;
    return state.cells[row]?.[col]?.elevation ?? 0;
}
export function cellHeightAt(state, col, row) {
    if (row < 0 || row >= state.rows || col < 0 || col >= state.cols)
        return 0;
    const cell = state.cells[row]?.[col];
    return cell ? cellHeightLevel(cell) : 0;
}
export function facingVector(dir) {
    if (dir === 'e')
        return [1, 0];
    if (dir === 'w')
        return [-1, 0];
    if (dir === 's')
        return [0, 1];
    return [0, -1];
}
export function facingToYaw(dir) {
    if (dir === 'e')
        return Math.PI / 2;
    if (dir === 'w')
        return -Math.PI / 2;
    if (dir === 's')
        return 0;
    return Math.PI;
}
export function vectorToFacing(dc, dr, fallback = 'e') {
    if (dc === 0 && dr === 0)
        return fallback;
    if (Math.abs(dc) >= Math.abs(dr))
        return dc > 0 ? 'e' : 'w';
    return dr > 0 ? 's' : 'n';
}
export function isUnitDowned(unit) {
    return !unit.alive && unit.downed && unit.koCountdown > 0;
}
export function isUnitActive(unit) {
    return unit.alive;
}
