import { computeEndlessAttackerDamageMultiplier } from "./endless-roguelite.js";
import { closestFootprintCell, getUnitFootprintSize } from "./expansion-act2.js";
import { mutatorDamageMultiplier } from "./mutators.js";
import { cellHeightAt, terrainDefBonus } from "./types.js";
export const PINCER_DAMAGE_RATIO = 0.5;
export const PINCER_MIN_DAMAGE = 4;
function manhattan(c1, r1, c2, r2) {
    return Math.abs(c1 - c2) + Math.abs(r1 - r2);
}
function pincerElevationMultiplier(attackerLevel, defenderLevel) {
    const diff = attackerLevel - defenderLevel;
    if (diff >= 3)
        return 1.35;
    if (diff === 2)
        return 1.28;
    if (diff === 1)
        return 1.2;
    if (diff === -1)
        return 0.92;
    if (diff <= -2)
        return 0.85;
    return 1.0;
}
/**
 * Single-target adjacent melee skills (e.g. Shield Bash, Radiant Smite) qualify
 * to trigger a Pincer / Follow-Up assist strike alongside basic adjacent attacks.
 */
export function isPincerMeleeSkill(skill) {
    return skill.target === 'enemy' && skill.pattern === 'single' && skill.powerMul > 0 && skill.range <= 1;
}
/**
 * Find qualifying Pincer / Follow-Up assisters for an attack originating at
 * `(attackerCol, attackerRow)` against `target`.
 *
 * Rules:
 * - Attack must be an adjacent melee strike (`manhattan === 1`) against an opposing team unit.
 * - Opposite tile directly across `target` is `(target.col + (target.col - attackerCol), target.row + (target.row - attackerRow))`.
 * - Any living, non-stunned teammate of `attacker` standing on that opposite tile whose
 *   elevation difference to `target` is within `Math.max(1, u.jump)` qualifies as a Pincer Assister.
 * - Symmetrical: works both for player heroes flanking an enemy and enemies pincering a hero.
 */
export function findPincerAssisters(battle, attacker, attackerCol, attackerRow, target) {
    if (!attacker.alive || !target.alive)
        return [];
    if (attacker.team === target.team)
        return [];
    const hitCell = closestFootprintCell(attackerCol, attackerRow, target);
    if (manhattan(attackerCol, attackerRow, hitCell.col, hitCell.row) !== 1)
        return [];
    const fpSize = getUnitFootprintSize(target);
    const stepCol = hitCell.col - attackerCol;
    const stepRow = hitCell.row - attackerRow;
    const oppCol = hitCell.col + stepCol * fpSize;
    const oppRow = hitCell.row + stepRow * fpSize;
    if (oppCol < 0 || oppCol >= battle.cols || oppRow < 0 || oppRow >= battle.rows)
        return [];
    const targetHeight = cellHeightAt(battle, hitCell.col, hitCell.row);
    const assisters = [];
    for (const u of battle.units) {
        if (u.team !== attacker.team || u.uid === attacker.uid || !u.alive || u.stunTurns > 0)
            continue;
        if (u.col !== oppCol || u.row !== oppRow)
            continue;
        const assisterHeight = cellHeightAt(battle, u.col, u.row);
        if (Math.abs(assisterHeight - targetHeight) > Math.max(1, u.jump))
            continue;
        assisters.push(u);
    }
    return assisters;
}
/**
 * Compute bonus Pincer Follow-Up strike damage: 50% of the assister's basic attack
 * damage accounting for elevation, empower, and target DEF + terrain DEF (minimum 4 DMG).
 */
export function computePincerAssistDamage(battle, assister, target) {
    let dmg = assister.atk;
    const aLvl = cellHeightAt(battle, assister.col, assister.row);
    const dLvl = cellHeightAt(battle, target.col, target.row);
    dmg *= pincerElevationMultiplier(aLvl, dLvl);
    if (assister.empowerTurns > 0)
        dmg *= 1.35;
    dmg *= computeEndlessAttackerDamageMultiplier(battle.endlessBlessings, { team: assister.team ?? 'enemy' }, { slowTurns: target.slowTurns ?? 0, stunTurns: target.stunTurns ?? 0 });
    dmg *= mutatorDamageMultiplier(battle);
    const cell = battle.cells[target.row]?.[target.col];
    const terrainDef = cell ? terrainDefBonus(cell.terrain) : 0;
    const effDef = Math.max(0, target.def + terrainDef);
    const basicDmg = Math.max(PINCER_MIN_DAMAGE, Math.round(dmg - effDef * 0.72));
    return Math.max(PINCER_MIN_DAMAGE, Math.round(basicDmg * PINCER_DAMAGE_RATIO));
}
