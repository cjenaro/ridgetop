function getBridge() {
    return globalThis.__ridgetopPlatform;
}
function createBridgeStorage(native) {
    const entries = new Map();
    const mutated = new Set();
    let cleared = false;
    try {
        const initial = native.loadAll?.();
        if (initial && typeof initial === 'object') {
            for (const [key, value] of Object.entries(initial)) {
                if (typeof value === 'string')
                    entries.set(key, value);
            }
        }
    }
    catch { /* Start with an empty in-memory cache if native loading fails. */ }
    try {
        native.onHydrate?.((key, value) => {
            if (!cleared && !mutated.has(key) && !entries.has(key) && typeof value === 'string') {
                entries.set(key, value);
            }
        });
    }
    catch { /* Ignore optional hydration subscription failures. */ }
    return {
        get length() { return entries.size; },
        key(index) {
            if (index < 0 || index >= entries.size)
                return null;
            return Array.from(entries.keys())[index] ?? null;
        },
        getItem(key) {
            return entries.get(key) ?? null;
        },
        setItem(key, value) {
            const text = String(value);
            mutated.add(key);
            entries.set(key, text);
            try {
                native.set?.(key, text);
            }
            catch { /* Keep the in-memory copy if persistence fails. */ }
        },
        removeItem(key) {
            mutated.add(key);
            entries.delete(key);
            try {
                native.remove?.(key);
            }
            catch { /* Ignore native removal errors. */ }
        },
        clear() {
            cleared = true;
            mutated.clear();
            entries.clear();
            try {
                native.clear?.();
            }
            catch { /* Ignore native clear errors. */ }
        }
    };
}
const bridgeStorageCache = new WeakMap();
/** Return the native host save store when packaged, or browser localStorage on the web. */
export function resolveStorage() {
    const native = getBridge()?.storage;
    if (native) {
        let cached = bridgeStorageCache.get(native);
        if (!cached) {
            cached = createBridgeStorage(native);
            bridgeStorageCache.set(native, cached);
        }
        return cached;
    }
    try {
        return globalThis.localStorage;
    }
    catch {
        return undefined;
    }
}
/** Expose native desktop/mobile capabilities with safe browser fallbacks. */
export function createPlatform() {
    const bridge = getBridge();
    const kind = bridge?.platform ?? 'web';
    const vibrateMs = { light: 12, medium: 24, heavy: 42 };
    return {
        kind,
        isNative: kind !== 'web',
        canQuit: typeof bridge?.quit === 'function',
        async quit() {
            await bridge?.quit?.();
        },
        isFullscreen() {
            if (bridge?.fullscreen?.isFullscreen)
                return Boolean(bridge.fullscreen.isFullscreen());
            return Boolean(globalThis.document?.fullscreenElement);
        },
        async setFullscreen(enabled) {
            if (bridge?.fullscreen?.set) {
                await bridge.fullscreen.set(enabled);
                return;
            }
            const doc = globalThis.document;
            if (!doc)
                return;
            try {
                if (enabled && !doc.fullscreenElement)
                    await doc.documentElement?.requestFullscreen?.();
                else if (!enabled && doc.fullscreenElement)
                    await doc.exitFullscreen?.();
            }
            catch { /* Fullscreen requests require a gesture or host permission. */ }
        },
        async toggleFullscreen() {
            if (bridge?.fullscreen?.toggle) {
                await bridge.fullscreen.toggle();
                return;
            }
            await this.setFullscreen(!this.isFullscreen());
        },
        haptic(style = 'light') {
            if (bridge?.haptics?.impact) {
                try {
                    bridge.haptics.impact(style);
                }
                catch { /* Haptics are optional. */ }
                return;
            }
            try {
                if (globalThis.navigator?.userActivation?.hasBeenActive) {
                    globalThis.navigator.vibrate?.(vibrateMs[style]);
                }
            }
            catch { /* Ignore unsupported vibration. */ }
        },
        onLifecycle({ pause, resume, dispose }) {
            const controller = new AbortController();
            const options = { signal: controller.signal };
            let disposed = false;
            let unsubscribeNative;
            function stop() {
                controller.abort();
                const unsub = unsubscribeNative;
                unsubscribeNative = undefined;
                if (typeof unsub === 'function')
                    unsub();
            }
            function runDispose() {
                if (disposed)
                    return;
                disposed = true;
                stop();
                dispose?.();
            }
            if (globalThis.document) {
                globalThis.document.addEventListener('visibilitychange', () => {
                    if (disposed)
                        return;
                    if (globalThis.document.hidden)
                        pause?.('visibility');
                    else
                        resume?.('visibility');
                }, options);
            }
            if (globalThis.window) {
                globalThis.window.addEventListener('pagehide', event => {
                    if (disposed)
                        return;
                    if (event.persisted)
                        pause?.('page');
                    else if (dispose)
                        runDispose();
                    else
                        pause?.('page');
                }, options);
                globalThis.window.addEventListener('pageshow', event => {
                    if (disposed)
                        return;
                    if (event.persisted)
                        resume?.('page');
                }, options);
            }
            unsubscribeNative = bridge?.lifecycle?.subscribe?.({
                pause: pause ? () => { if (!disposed)
                    pause('native'); } : undefined,
                resume: resume ? () => { if (!disposed)
                    resume('native'); } : undefined
            });
            return stop;
        },
        steam: {
            get available() {
                return Boolean(bridge?.steam?.available?.());
            },
            async unlockAchievement(id) {
                if (!bridge?.steam?.unlockAchievement)
                    return false;
                try {
                    return Boolean(await bridge.steam.unlockAchievement(id));
                }
                catch {
                    return false;
                }
            },
            setRichPresence(key, value) {
                try {
                    bridge?.steam?.setRichPresence?.(key, value);
                }
                catch { /* Optional Steam presence. */ }
            },
            activateOverlay(dialog = 'Achievements') {
                try {
                    bridge?.steam?.activateOverlay?.(dialog);
                }
                catch { /* Optional Steam overlay. */ }
            }
        },
        ota: {
            get available() {
                return Boolean(bridge?.ota?.available?.());
            },
            get channel() {
                return bridge?.ota?.getChannel?.() ?? 'prod';
            },
            get baseUrl() {
                return bridge?.ota?.getBaseUrl?.() ?? '';
            },
            async getStatus() {
                if (bridge?.ota?.getStatus)
                    return bridge.ota.getStatus();
                return {
                    appId: '',
                    channel: 'prod',
                    baseUrl: '',
                    nativeVersion: '0.0.0',
                    nativeBuild: '0',
                    activeVersion: null,
                    stagedVersion: null,
                    lastGoodVersion: null,
                    failedVersion: null,
                    isOtaActive: false,
                    signatureRequired: false
                };
            },
            async checkForUpdate() {
                if (!bridge?.ota?.checkForUpdate) {
                    return { available: false, staged: false, version: null, reason: 'unsupported' };
                }
                try {
                    return await bridge.ota.checkForUpdate();
                }
                catch (error) {
                    return {
                        available: false,
                        staged: false,
                        version: null,
                        reason: error instanceof Error ? error.message : String(error)
                    };
                }
            },
            async applyUpdate(options) {
                if (!bridge?.ota?.applyUpdate)
                    return false;
                try {
                    return Boolean(await bridge.ota.applyUpdate(options));
                }
                catch {
                    return false;
                }
            },
            async confirmReady() {
                if (!bridge?.ota?.confirmReady)
                    return false;
                try {
                    return Boolean(await bridge.ota.confirmReady());
                }
                catch {
                    return false;
                }
            },
            async setChannel(channel, customBaseUrl) {
                if (!bridge?.ota?.setChannel)
                    return;
                await bridge.ota.setChannel(channel, customBaseUrl);
            },
            async reset() {
                if (!bridge?.ota?.reset)
                    return;
                await bridge.ota.reset();
            },
            onUpdateReady(listener) {
                const unsub = bridge?.ota?.onUpdateReady?.(listener);
                return typeof unsub === 'function' ? unsub : () => { };
            }
        }
    };
}
