function isAudioEntryIterable(entries) {
    return Symbol.iterator in Object(entries);
}
function asciiAt(u8, offset, length) {
    let out = '';
    for (let i = 0; i < length; i++)
        out += String.fromCharCode(u8[offset + i]);
    return out;
}
function toUint8Array(input) {
    if (input instanceof Uint8Array)
        return input;
    if (input instanceof ArrayBuffer)
        return new Uint8Array(input);
    throw new TypeError('Expected a Uint8Array or ArrayBuffer');
}
/**
 * Parse a standard RIFF WAVE (`.wav`) buffer containing integer PCM (8/16/24/32-bit)
 * or IEEE float (32/64-bit) samples. Round-trips cleanly with Ridgetop's `encodeWav`.
 */
export function parseWav(bytes) {
    const u8 = toUint8Array(bytes);
    if (u8.byteLength < 12) {
        throw new RangeError('WAV buffer is too short to contain a valid RIFF header');
    }
    if (asciiAt(u8, 0, 4) !== 'RIFF' || asciiAt(u8, 8, 4) !== 'WAVE') {
        throw new RangeError('Invalid WAV header (expected RIFF/WAVE)');
    }
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    let formatTag = 0;
    let channels = 0;
    let sampleRate = 0;
    let bitsPerSample = 0;
    let hasFmt = false;
    let dataStart = -1;
    let dataSize = 0;
    let offset = 12;
    while (offset + 8 <= u8.byteLength) {
        const id = asciiAt(u8, offset, 4);
        const size = dv.getUint32(offset + 4, true);
        const bodyStart = offset + 8;
        if (bodyStart + size > u8.byteLength) {
            throw new RangeError(`WAV chunk "${id}" exceeds buffer length`);
        }
        if (id === 'fmt ') {
            if (size < 16)
                throw new RangeError('WAV fmt chunk is truncated');
            formatTag = dv.getUint16(bodyStart, true);
            channels = dv.getUint16(bodyStart + 2, true);
            sampleRate = dv.getUint32(bodyStart + 4, true);
            bitsPerSample = dv.getUint16(bodyStart + 14, true);
            if (formatTag === 0xfffe && size >= 40) {
                formatTag = dv.getUint16(bodyStart + 24, true);
            }
            hasFmt = true;
        }
        else if (id === 'data') {
            dataStart = bodyStart;
            dataSize = size;
        }
        offset = bodyStart + size + (size % 2);
    }
    if (!hasFmt)
        throw new RangeError('WAV file is missing a fmt chunk');
    if (dataStart < 0)
        throw new RangeError('WAV file is missing a data chunk');
    if (channels < 1 || sampleRate < 1) {
        throw new RangeError(`Invalid WAV format parameters (channels=${channels}, sampleRate=${sampleRate})`);
    }
    if (formatTag !== 1 && formatTag !== 3) {
        throw new RangeError(`Unsupported WAV audio format tag ${formatTag} (expected PCM=1 or IEEE float=3)`);
    }
    const bytesPerSample = bitsPerSample / 8;
    const validPcm = formatTag === 1 && (bitsPerSample === 8 || bitsPerSample === 16 || bitsPerSample === 24 || bitsPerSample === 32);
    const validFloat = formatTag === 3 && (bitsPerSample === 32 || bitsPerSample === 64);
    if (!validPcm && !validFloat) {
        throw new RangeError(`Unsupported WAV bit depth ${bitsPerSample} for format ${formatTag}`);
    }
    const frameStride = channels * bytesPerSample;
    if (dataSize % frameStride !== 0) {
        throw new RangeError('WAV data chunk length is not aligned to sample frames');
    }
    const frameCount = dataSize / frameStride;
    const channelData = Array.from({ length: channels }, () => new Float32Array(frameCount));
    for (let frame = 0; frame < frameCount; frame++) {
        const frameOffset = dataStart + frame * frameStride;
        for (let ch = 0; ch < channels; ch++) {
            const sampleOffset = frameOffset + ch * bytesPerSample;
            let sample = 0;
            if (formatTag === 1) {
                if (bitsPerSample === 8) {
                    sample = (dv.getUint8(sampleOffset) - 128) / 128;
                }
                else if (bitsPerSample === 16) {
                    const raw = dv.getInt16(sampleOffset, true);
                    sample = Math.max(-1, raw / 32767);
                }
                else if (bitsPerSample === 24) {
                    const b0 = u8[sampleOffset];
                    const b1 = u8[sampleOffset + 1];
                    const b2 = u8[sampleOffset + 2];
                    const raw = (b0 | (b1 << 8) | (b2 << 16));
                    const signed = raw & 0x800000 ? raw | ~0xffffff : raw;
                    sample = Math.max(-1, signed / 8388607);
                }
                else {
                    const raw = dv.getInt32(sampleOffset, true);
                    sample = Math.max(-1, raw / 2147483647);
                }
            }
            else {
                sample = bitsPerSample === 32
                    ? dv.getFloat32(sampleOffset, true)
                    : dv.getFloat64(sampleOffset, true);
            }
            channelData[ch][frame] = sample;
        }
    }
    let samples;
    if (channels === 1) {
        samples = channelData[0];
    }
    else {
        samples = new Float32Array(frameCount);
        const inv = 1 / channels;
        for (let i = 0; i < frameCount; i++) {
            let sum = 0;
            for (let ch = 0; ch < channels; ch++)
                sum += channelData[ch][i];
            samples[i] = sum * inv;
        }
    }
    return {
        sampleRate,
        channels,
        bitsPerSample,
        format: formatTag === 3 ? 'float' : 'pcm',
        duration: frameCount / sampleRate,
        samples,
        channelData
    };
}
export const NOOP_PLAY_HANDLE = {
    stop() { },
    get playing() { return false; }
};
function copyToArrayBuffer(input) {
    if (input instanceof Uint8Array) {
        const copy = new Uint8Array(input.byteLength);
        copy.set(input);
        return copy.buffer;
    }
    return input.slice(0);
}
function decodeAudio(ctx, arrayBuffer) {
    return new Promise((resolve, reject) => {
        if (typeof ctx.decodeAudioData !== 'function') {
            reject(new Error('AudioContext does not support decodeAudioData'));
            return;
        }
        let settled = false;
        const onResolve = (buf) => {
            if (!settled) {
                settled = true;
                resolve(buf);
            }
        };
        const onReject = (err) => {
            if (!settled) {
                settled = true;
                reject(err);
            }
        };
        try {
            const maybePromise = ctx.decodeAudioData(arrayBuffer, onResolve, onReject);
            if (maybePromise && typeof maybePromise.then === 'function') {
                maybePromise.then(onResolve, onReject);
            }
        }
        catch (error) {
            onReject(error);
        }
    });
}
function isAudioNodeLike(value) {
    return typeof value === 'object' && value !== null && 'connect' in value;
}
/**
 * External `.wav`/`.ogg`/`.mp3` audio bank with Web Audio decoding, caching,
 * bus routing, looping, pitch/detune controls, and headless-safe fallbacks.
 */
export function createAudioBank(options = {}) {
    let ctx = options.context ?? null;
    const ownsContext = !options.context && !options.getContext;
    let masterGain = null;
    let masterVolume = 1;
    let muted = false;
    let disposed = false;
    const buffers = new Map();
    const pending = new Map();
    const active = new Set();
    const staticBuses = options.buses ?? {};
    function ensureContext() {
        if (disposed)
            return null;
        if (options.getContext) {
            const provided = options.getContext();
            if (provided !== ctx) {
                if (ctx) {
                    stopAll();
                    buffers.clear();
                    pending.clear();
                    try {
                        masterGain?.disconnect?.();
                    }
                    catch { /* ignore */ }
                    masterGain = null;
                }
                ctx = provided;
            }
        }
        else if (!ctx) {
            const AudioCtor = globalThis.AudioContext ?? globalThis.webkitAudioContext;
            if (!AudioCtor)
                return null;
            try {
                ctx = new AudioCtor();
            }
            catch {
                return null;
            }
        }
        if (!ctx)
            return null;
        if (!masterGain && typeof ctx.createGain === 'function') {
            try {
                masterGain = ctx.createGain();
                masterGain.gain.value = muted ? 0 : masterVolume;
                const target = options.getDestination?.() ?? options.destination ?? ctx.destination;
                if (target)
                    masterGain.connect(target);
            }
            catch {
                masterGain = null;
            }
        }
        return ctx;
    }
    async function load(name, source) {
        if (disposed)
            return false;
        const audioCtx = ensureContext();
        if (!audioCtx || typeof audioCtx.decodeAudioData !== 'function')
            return false;
        if (buffers.has(name))
            return true;
        const inFlight = pending.get(name);
        if (inFlight)
            return inFlight;
        const targetCtx = audioCtx;
        const task = (async () => {
            try {
                let rawBuffer;
                if (typeof source === 'string' || source instanceof URL) {
                    const fetcher = options.fetch ?? globalThis.fetch;
                    if (typeof fetcher !== 'function')
                        return false;
                    const response = await fetcher(source);
                    if (!response.ok)
                        return false;
                    rawBuffer = await response.arrayBuffer();
                }
                else {
                    rawBuffer = copyToArrayBuffer(source);
                }
                if (disposed || ctx !== targetCtx)
                    return false;
                const decoded = await decodeAudio(targetCtx, copyToArrayBuffer(rawBuffer));
                if (disposed || !decoded || ctx !== targetCtx)
                    return false;
                buffers.set(name, decoded);
                return true;
            }
            catch {
                return false;
            }
            finally {
                pending.delete(name);
            }
        })();
        pending.set(name, task);
        return task;
    }
    async function loadAll(entries) {
        const pairs = isAudioEntryIterable(entries)
            ? Array.from(entries, ([k, v]) => [k, v])
            : Object.entries(entries);
        const results = {};
        await Promise.all(pairs.map(async ([name, source]) => {
            results[name] = await load(name, source);
        }));
        return results;
    }
    function play(name, playOptions = {}) {
        if (disposed)
            return NOOP_PLAY_HANDLE;
        const audioCtx = ensureContext();
        const buffer = buffers.get(name);
        if (!buffer || !audioCtx || typeof audioCtx.createBufferSource !== 'function') {
            return NOOP_PLAY_HANDLE;
        }
        try {
            if (audioCtx.state === 'suspended' && typeof audioCtx.resume === 'function') {
                audioCtx.resume().catch(() => { });
            }
            const source = audioCtx.createBufferSource();
            source.buffer = buffer;
            source.loop = Boolean(playOptions.loop);
            const rate = playOptions.rate ?? 1;
            if (source.playbackRate && Number.isFinite(rate) && rate > 0) {
                source.playbackRate.value = rate;
            }
            const detune = playOptions.detune ?? 0;
            if (source.detune && Number.isFinite(detune) && detune !== 0) {
                source.detune.value = detune;
            }
            const volume = playOptions.volume ?? 1;
            const gain = typeof audioCtx.createGain === 'function' ? audioCtx.createGain() : null;
            if (gain) {
                gain.gain.value = Number.isFinite(volume) ? Math.max(0, volume) : 1;
            }
            const activeBuses = options.getBuses?.() ?? staticBuses;
            let dest = null;
            if (isAudioNodeLike(playOptions.bus)) {
                dest = playOptions.bus;
            }
            else if (typeof playOptions.bus === 'string' && activeBuses[playOptions.bus]) {
                dest = activeBuses[playOptions.bus] ?? null;
            }
            else {
                dest = masterGain ?? options.getDestination?.() ?? options.destination ?? audioCtx.destination ?? null;
            }
            if (gain && dest) {
                source.connect(gain);
                gain.connect(dest);
            }
            else if (dest) {
                source.connect(dest);
            }
            let isPlaying = true;
            const cleanup = () => {
                if (!isPlaying)
                    return;
                isPlaying = false;
                active.delete(handle);
                try {
                    source.disconnect?.();
                }
                catch { /* ignore */ }
                try {
                    gain?.disconnect?.();
                }
                catch { /* ignore */ }
            };
            const handle = {
                stop() {
                    if (!isPlaying)
                        return;
                    cleanup();
                    try {
                        source.stop?.();
                    }
                    catch { /* already stopped */ }
                },
                get playing() { return isPlaying; }
            };
            source.onended = cleanup;
            active.add(handle);
            const offset = playOptions.offset !== undefined && Number.isFinite(playOptions.offset)
                ? Math.max(0, playOptions.offset)
                : 0;
            try {
                if (playOptions.duration !== undefined && Number.isFinite(playOptions.duration) && playOptions.duration >= 0) {
                    source.start(0, offset, playOptions.duration);
                }
                else if (offset > 0) {
                    source.start(0, offset);
                }
                else {
                    source.start(0);
                }
            }
            catch {
                cleanup();
                return NOOP_PLAY_HANDLE;
            }
            return handle;
        }
        catch {
            return NOOP_PLAY_HANDLE;
        }
    }
    function stopAll() {
        for (const handle of Array.from(active)) {
            handle.stop();
        }
        active.clear();
    }
    function setVolume(volume) {
        masterVolume = Number.isFinite(volume) ? Math.max(0, volume) : 1;
        if (masterGain)
            masterGain.gain.value = muted ? 0 : masterVolume;
    }
    function setMuted(value) {
        muted = Boolean(value);
        if (masterGain)
            masterGain.gain.value = muted ? 0 : masterVolume;
    }
    function dispose() {
        if (disposed)
            return;
        disposed = true;
        stopAll();
        buffers.clear();
        pending.clear();
        try {
            masterGain?.disconnect?.();
        }
        catch { /* ignore */ }
        masterGain = null;
        if (ownsContext && ctx && typeof ctx.close === 'function') {
            try {
                const res = ctx.close();
                if (res && typeof res.catch === 'function')
                    res.catch(() => { });
            }
            catch { /* ignore */ }
        }
        ctx = null;
    }
    return {
        load,
        loadAll,
        play,
        stopAll,
        has(name) { return buffers.has(name); },
        names() { return [...buffers.keys()]; },
        setVolume,
        setMuted,
        dispose
    };
}
