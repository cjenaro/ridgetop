import { createPlatform, resolveStorage } from "./platform.js";
function isMediaQueryList(value) {
    return 'onchange' in value && 'dispatchEvent' in value && typeof value.dispatchEvent === 'function';
}
function toMediaQueryList(query, source) {
    if (source && isMediaQueryList(source))
        return source;
    const target = new EventTarget();
    const wrapped = new WeakMap();
    const mql = {
        get matches() { return Boolean(source?.matches); },
        get media() { return source?.media ?? query; },
        onchange: null,
        addListener(callback) {
            if (!callback)
                return;
            mql.addEventListener('change', callback);
        },
        removeListener(callback) {
            if (!callback)
                return;
            mql.removeEventListener('change', callback);
        },
        addEventListener(type, listener, options) {
            if (type === 'change' && listener && source?.addEventListener) {
                let handler = wrapped.get(listener);
                if (!handler) {
                    handler = event => {
                        const mqlEvent = Object.assign(new Event('change'), { matches: event.matches, media: mql.media });
                        if (typeof listener === 'function')
                            listener.call(mql, mqlEvent);
                        else
                            listener.handleEvent(mqlEvent);
                    };
                    wrapped.set(listener, handler);
                }
                source.addEventListener('change', handler);
                return;
            }
            target.addEventListener(type, listener, options);
        },
        removeEventListener(type, listener, options) {
            if (type === 'change' && listener && source?.removeEventListener) {
                const handler = wrapped.get(listener);
                if (handler) {
                    source.removeEventListener('change', handler);
                    wrapped.delete(listener);
                }
                return;
            }
            target.removeEventListener(type, listener, options);
        },
        dispatchEvent(event) {
            return target.dispatchEvent(event);
        }
    };
    return mql;
}
export function createGamePage(options = {}) {
    const doc = options.document ?? globalThis.document;
    const href = options.location?.href ?? globalThis.window?.location?.href ?? globalThis.location?.href ?? 'http://localhost/';
    const url = new URL(href);
    const hist = options.history ?? globalThis.window?.history;
    const matchMediaFn = options.matchMedia ?? (query => globalThis.window?.matchMedia?.(query));
    const storage = 'storage' in options ? options.storage : resolveStorage();
    const platform = options.platform ?? createPlatform();
    const clipboard = options.clipboard ?? globalThis.navigator?.clipboard;
    const fetchFn = options.fetch ?? globalThis.fetch;
    const cryptoObj = options.crypto ?? globalThis.crypto;
    const reducedMotion = toMediaQueryList('(prefers-reduced-motion: reduce)', matchMediaFn('(prefers-reduced-motion: reduce)'));
    const touchSource = matchMediaFn('(any-pointer: coarse)');
    const touch = toMediaQueryList('(any-pointer: coarse)', touchSource);
    const disposers = new Set();
    let disposed = false;
    function onDispose(fn) {
        if (disposed) {
            fn();
            return () => { };
        }
        disposers.add(fn);
        return () => { disposers.delete(fn); };
    }
    function dispose() {
        if (disposed)
            return;
        disposed = true;
        const list = Array.from(disposers).reverse();
        disposers.clear();
        let firstError;
        for (const fn of list) {
            try {
                fn();
            }
            catch (error) {
                if (firstError === undefined)
                    firstError = error;
            }
        }
        if (firstError !== undefined)
            throw firstError;
    }
    function element(id) {
        const selector = typeof CSS !== 'undefined' && typeof CSS.escape === 'function'
            ? '#' + CSS.escape(id)
            : `[id="${id.replace(/["\\]/g, '\\$&')}"]`;
        const node = doc?.querySelector(selector);
        if (!node)
            throw new Error('Game page is missing #' + id);
        return node;
    }
    function query(name) {
        return url.searchParams.get(name);
    }
    function requestedBackend(fallback = 'auto') {
        const canvasParam = url.searchParams.get('canvas');
        if (canvasParam !== null && canvasParam !== '0' && canvasParam.toLowerCase() !== 'false') {
            return 'canvas';
        }
        const renderer = url.searchParams.get('renderer')?.toLowerCase();
        if (renderer === 'webgpu' || renderer === 'webgl2' || renderer === 'canvas' || renderer === 'auto') {
            return renderer;
        }
        return fallback;
    }
    function onTouchChange(listener) {
        const handler = (event) => {
            listener(Boolean(event?.matches ?? touch.matches));
        };
        if (touchSource?.addEventListener)
            touchSource.addEventListener('change', handler);
        let active = true;
        const unsubscribe = () => {
            if (!active)
                return;
            active = false;
            if (touchSource?.removeEventListener)
                touchSource.removeEventListener('change', handler);
            disposers.delete(unsubscribe);
        };
        onDispose(unsubscribe);
        return unsubscribe;
    }
    return {
        element,
        url,
        query,
        requestedBackend,
        storage,
        platform,
        reducedMotion,
        touch,
        onTouchChange,
        onDispose,
        dispose,
        replaceUrl(nextUrl) { hist?.replaceState(null, '', nextUrl); },
        roomCode() {
            return Array.from(cryptoObj.getRandomValues(new Uint32Array(2)), value => value.toString(36)).join('-');
        },
        async copy(text) {
            if (!clipboard?.writeText)
                throw new Error('Clipboard is unavailable');
            await clipboard.writeText(text);
        },
        async requestJson(path, init, errorMessage = 'Request failed') {
            const response = await fetchFn(path, init);
            if (!response.ok)
                throw new Error(errorMessage);
            return response.json();
        }
    };
}
